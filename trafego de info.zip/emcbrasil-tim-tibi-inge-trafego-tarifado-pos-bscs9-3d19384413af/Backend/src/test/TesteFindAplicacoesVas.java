import br.com.tim.mapreduce.finders.AplicacoesVasFinder;
import org.apache.hadoop.conf.Configuration;
import org.junit.Test;

public class TesteFindAplicacoesVas {


    public void teste1(){
        Configuration c = new Configuration();
        c.set("cached.file.aplicacoes-vas-dir","/apps/hive/warehouse/fact.db/dw_f_revtrib_app_vas/");
        AplicacoesVasFinder a = new AplicacoesVasFinder(c);
        a.findBySpId("784");

    }
}
