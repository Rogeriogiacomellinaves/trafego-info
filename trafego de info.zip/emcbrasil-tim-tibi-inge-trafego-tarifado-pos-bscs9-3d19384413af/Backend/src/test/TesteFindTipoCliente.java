import br.com.tim.mapreduce.finders.AplicacoesVasFinder;
import br.com.tim.mapreduce.finders.TipoClienteFinder;
import org.apache.hadoop.conf.Configuration;
import org.junit.Test;

public class TesteFindTipoCliente {

    public void teste1(){
        Configuration c = new Configuration();
        c.set("cached.file.tipo-cliente-dir","/silver/auxiliary/cac/er_tipo_cliente/");
        TipoClienteFinder a = new TipoClienteFinder(c);
        a.find("15");

    }
}
