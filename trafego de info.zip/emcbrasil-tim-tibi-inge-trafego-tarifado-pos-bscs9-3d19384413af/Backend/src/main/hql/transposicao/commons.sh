#!/bin/bash

#- HOME
INSTALL_HOME=/data/apps/inge/tim-tibi-inge-trafego-tarifado-pos-bscs9
#-==============================================================================
#- Functions
#-==============================================================================
function initializeLog {
	log_path=$log_filename

    numero_arquivos_log=$(ls | grep "$log_filename$" | wc -l)
    if [ $numero_arquivos_log -gt 0 ]
    then
        data_ultima_alteracao_log=$(date -r $log_path "+%Y%m%d")
        data_ultima_alteracao_formatada=$(date -r $log_path "+%Y-%m-%d")
        if [ $(getDateAsNumber) -gt $data_ultima_alteracao_log ]
        then
            mv $log_path $log_path.$data_ultima_alteracao_formatada
        fi
    fi
    exec &> >(tee -a $log_path)
}

function getTimestamp {
    date +"%d/%m/%Y %H:%M:%S"
}

function logInfo {
    echo "$(getTimestamp) INFO: $1"
    #echo "INFO: $1"
}





