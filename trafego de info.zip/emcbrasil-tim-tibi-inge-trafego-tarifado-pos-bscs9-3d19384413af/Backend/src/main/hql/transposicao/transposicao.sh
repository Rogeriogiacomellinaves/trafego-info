#!/bin/bash

HOME=`pwd -P`

. $HOME/commons.sh

log_dir=$HOME/logs/
log_filename="${log_dir}transposicao.log"

initializeLog

function executeHive {

    dir_dml="${HOME}/dml/"
	table=$1
	dml=${dir_dml}${table}
	param_data=$2

	if [ ${table} != '' ]; then
		logInfo "Instalação no HIVE ${dml}.hql"
		hive -hiveconf PARAM_DATA="$param_data" -f ${dml}.hql
	fi

	if [ $? -ne 0 ]
		then
		    logInfo "ERROR AO EXECUTAR  ${dml}.hql "
			exit 1;
		fi
}

logInfo "###############################################"
logInfo "Executando a data de: $1"
logInfo "###############################################"

executeHive "dw_f_traftar_pos_pago_bscs9_enriq" $1