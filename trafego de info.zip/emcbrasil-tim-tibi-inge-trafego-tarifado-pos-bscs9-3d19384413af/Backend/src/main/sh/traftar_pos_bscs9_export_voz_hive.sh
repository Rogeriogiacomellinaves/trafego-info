#!/bin/bash

source /data/apps/env/setup.sh

for file in `ls ${HOME}/jars/`
do
PATH_JAR="${HOME}/jars/$file"
done

CONFIG="$HOME/resources/export_voz_hive_configuration.xml"
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dlog4j= -Dlog4j.configuration=$NADA -Dconfiguration=$CONFIG -Dpath.jar=$PATH_JAR"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.hive.query.HiveQueryDriver $1

exit_cod=$?

if [ "$exit_cod" == "1" ]
then
	exit 1;
fi

CONFIG="$HOME/resources/export_voz_tar_configuration.xml"
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dlog4j= -Dlog4j.configuration=$NADA -Dconfiguration=$CONFIG -DhomePath=$HOME"
java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.hive.CompactFilesDriver $1

exit_cod=$?

if [ "$exit_cod" == "1" ]
then
	exit 1;
fi
