#!/bin/bash
################################################################################
# This Script is responsible for Trafego Tarifado Pos Bscs9 execution
#
# Andrey Luiz
# 1.0.0
################################################################################

source /data/apps/env/setup.sh
project_configuration=$HOME/resources/traftar_pos_bscs9_bdo_b_enrichment_configuration.xml
logging_configuration=$HOME/resources/traftar_pos_bscs9_log4j.properties

proc_conf=" -Dlog4j=$logging_configuration -Dconfiguration=$project_configuration " 
java $JAVA_OPTS $SYSTEM_PROPERTIES $proc_conf -cp $CM_CLASSPATH br.com.tim.mapreduce.joinbdo_b.TraftarPosBscs9JoinBdoBDriver $@

. ${LIBSH}/sh/exit-if-ne-0.sh