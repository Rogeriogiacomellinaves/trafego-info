--==============================================================================
-- Projeto       : Trafego Tarifado Pos BSCS9
-- Responsavel   : Fernando Melo
-- Funcao        : Script de desinstalação da estrutura das tabelas no GPDB
-- Criacao       : 31/05/2019
--==============================================================================

DROP TABLE fact.dw_f_traftar_pos_pago_bscs9_enriq;

DROP EXTERNAL TABLE ext.dw_f_traftar_pos_pago_bscs9_enriq;