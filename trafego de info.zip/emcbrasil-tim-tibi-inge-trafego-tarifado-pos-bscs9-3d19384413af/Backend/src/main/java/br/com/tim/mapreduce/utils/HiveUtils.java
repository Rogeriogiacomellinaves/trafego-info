package br.com.tim.utils;

import br.com.tim.utils.CommonsConstants;
import org.apache.commons.dbutils.DbUtils;
import org.apache.hive.jdbc.HiveStatement;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HiveUtils {

    private static String lastPartition = "select max(${partition}) from ${table}\n" +
            "where unix_timestamp(${partition}, '${partition-format}') <= unix_timestamp(DATE_SUB(current_date,${minus-day}),'yyyy-MM-dd');";

    public static String getLastPartition(Connection connection , String table, String partitionName, String partitionFormat ) throws SQLException {
        return getLastPartition(connection,table,partitionName,partitionFormat,0);
    }

    public static String getLastPartition(Connection connection , String table, String partitionName, String partitionFormat , int minusDays) throws SQLException {
        HiveStatement stmt = null;
        ResultSet rs = null;
        String dataPartition = null;
        try{
            stmt =(HiveStatement) connection.createStatement();
            if (null != rs){
                dataPartition = rs.getString(1);
            }
        }finally {
            DbUtils.close(rs);
            DbUtils.close(stmt);
        }
        return dataPartition;
    }

}
