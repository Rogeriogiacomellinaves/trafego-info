package br.com.tim.mapreduce.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import br.com.tim.utils.CommonsConstants;

public class TraftarPosBscs9Utils {

	public static StringBuilder strBuilder;
	
	public static synchronized StringBuilder getStrBuilder() {
		if ( null == strBuilder )
			return new StringBuilder();
		strBuilder.setLength(0);
		return strBuilder;
	}
	
	private static Date nullDate = new Date(0L);
	public static Date parseDate(String text, SimpleDateFormat sdf) {
		try {
			return sdf.parse(text);
		} catch (ParseException e) {
			return nullDate;
		}
	}
	
	public static String removeLastChar(String text) {
		if ( StringUtils.isBlank(text) ) return CommonsConstants.EMPTY;
		return text.substring(0, text.length() - 1);
	}
	
}
