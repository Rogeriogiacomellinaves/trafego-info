package br.com.tim.mapreduce.joinbdo_a;

import org.apache.hadoop.mapreduce.Partitioner;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAValue;

public class TraftarPosBscs9JoinBdoAPartitioner extends Partitioner<TraftarPosBscs9JoinBdoAKey, TraftarPosBscs9JoinBdoAValue> {
	
	@Override
	public int getPartition(TraftarPosBscs9JoinBdoAKey key, TraftarPosBscs9JoinBdoAValue value, int numParts) {
		int hash = key.hashCode();
        int partition = Math.abs(hash % numParts);
        return partition;
	}

}
