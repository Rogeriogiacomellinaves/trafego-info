package br.com.tim.mapreduce.joinbdo.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.WritableComparable;

import com.google.common.base.Strings;

import br.com.tim.mapreduce.model.Bdo;
import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Regras;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.GenericParserUtility;

public class TraftarPosBscs9JoinBdoBKey implements WritableComparable<TraftarPosBscs9JoinBdoBKey> {

	private String numTelefoneB;
	private int ordem;
	
	public TraftarPosBscs9JoinBdoBKey() {
		this.clean();
	}
	
	public void clean() {
		this.numTelefoneB = CommonsConstants.EMPTY;
		this.ordem = 0;
	}
	
	public void set(Bdo bdo) {
		this.numTelefoneB = bdo.getNumeroTelefone();
		this.ordem = 1;
	}
	
	public void set(TraftarPosBscs9 traftar) {
		if ( StringUtils.isBlank(traftar.getOPNormedNumAddress()) ) {
			this.numTelefoneB = "DADOS" + (int) (Math.random() * 100000000);
		} else {
			this.numTelefoneB = TraftarPosBscs9Regras.getNumeroBNormalizado(traftar);
		}
		this.ordem = 2;
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.numTelefoneB);
		out.writeInt(this.ordem);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.numTelefoneB = in.readUTF();
		this.ordem = in.readInt();
	}

	@Override
	public int compareTo(TraftarPosBscs9JoinBdoBKey o) {
		return GenericParserUtility.compare(this.numTelefoneB, o.numTelefoneB);
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numTelefoneB == null) ? 0 : numTelefoneB.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TraftarPosBscs9JoinBdoBKey other = (TraftarPosBscs9JoinBdoBKey) obj;
		if (numTelefoneB == null) {
			if (other.numTelefoneB != null)
				return false;
		} else if (!numTelefoneB.equals(other.numTelefoneB))
			return false;
		return true;
	}

	public String getNumTelefoneB() {
		return numTelefoneB;
	}

	public int getOrdem() {
		return ordem;
	}

}
