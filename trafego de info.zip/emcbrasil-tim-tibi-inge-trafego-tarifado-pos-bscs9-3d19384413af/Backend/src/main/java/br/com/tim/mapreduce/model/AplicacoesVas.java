package br.com.tim.mapreduce.model;

import org.apache.commons.lang3.StringUtils;

import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.StringUtil;

public class AplicacoesVas {

	public long spId;
	public String companyName;
	public String appId;
	public String appName;
	public long contractId;
	public String price;
	public String description;
	public String rowId;
	public String loteId;
	public String arquivo;
	public String arquivoTs;
	public String currentDate;
	public String statusProvider;
	public String idGrupoApp;
	public String dscGrupoApp;
	public String statusApp;
	public String idGrupoContractId;
	public String dscGrupoContractId;

	public AplicacoesVas() {
		
	}

	public AplicacoesVas(String spId, String companyName, String appId, String appName, String contractId, String price,
			String description, String rowId, String loteId, String arquivo, String arquivoTs, String currentDate,
			String statusProvider, String idGrupoApp, String dscGrupoApp, String statusApp, String idGrupoContractId,
			String dscGrupoContractId) {
		this.spId = StringUtils.isNumeric(spId) ? Long.parseLong(spId) : 0L;
		this.companyName = companyName;
		this.appId = appId;
		this.appName = appName;
		this.contractId = StringUtils.isNumeric(contractId) ? Long.parseLong(contractId) : 0L;
		this.price = price;
		this.description = description;
		this.rowId = rowId;
		this.loteId = loteId;
		this.arquivo = arquivo;
		this.arquivoTs = arquivoTs;
		this.currentDate = currentDate;
		this.statusProvider = statusProvider;
		this.idGrupoApp = idGrupoApp;
		this.dscGrupoApp = dscGrupoApp;
		this.statusApp = statusApp;
		this.idGrupoContractId = idGrupoContractId;
		this.dscGrupoContractId = dscGrupoContractId;
	}
	
	public static AplicacoesVas parseFromText(String textString) {
        if (textString != null && !textString.trim().isEmpty()) {
            String[] cols = textString.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
            int i = 0;
			return new AplicacoesVas(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++]);
        }
        return null;
    }
	
	@Override
	public String toString() {
		return StringUtil.getDelimitedString(CommonsConstants.FILE_FIELD_SEPARATOR, 
				String.valueOf(this.spId),
				this.companyName,
				this.appId,
				this.appName,
				String.valueOf(this.contractId),
				this.price,
				this.description,
				this.rowId,
				this.loteId,
				this.arquivo,
				this.arquivoTs,
				this.currentDate,
				this.statusProvider,
				this.idGrupoApp,
				this.dscGrupoApp,
				this.statusApp,
				this.idGrupoContractId,
				this.dscGrupoContractId);
	}

	public long getSpId() {
		return spId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public String getAppId() {
		return appId;
	}

	public String getAppName() {
		return appName;
	}

	public long getContractId() {
		return contractId;
	}

	public String getPrice() {
		return price;
	}

	public String getDescription() {
		return description;
	}

	public String getRowId() {
		return rowId;
	}

	public String getLoteId() {
		return loteId;
	}

	public String getArquivo() {
		return arquivo;
	}

	public String getArquivoTs() {
		return arquivoTs;
	}

	public String getCurrentDate() {
		return currentDate;
	}

	public String getStatusProvider() {
		return statusProvider;
	}

	public String getIdGrupoApp() {
		return idGrupoApp;
	}

	public String getDscGrupoApp() {
		return dscGrupoApp;
	}

	public String getStatusApp() {
		return statusApp;
	}

	public String getIdGrupoContractId() {
		return idGrupoContractId;
	}

	public String getDscGrupoContractId() {
		return dscGrupoContractId;
	}

	public void setSpId(long spId) {
		this.spId = spId;
	}

	public void setContractId(long contractId) {
		this.contractId = contractId;
	}
	
}