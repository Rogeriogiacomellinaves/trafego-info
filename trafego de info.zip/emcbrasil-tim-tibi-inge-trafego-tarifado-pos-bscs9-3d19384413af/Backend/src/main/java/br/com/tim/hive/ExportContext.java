package br.com.tim.hive;

import br.com.tim.exception.CommonsException;
import br.com.tim.hive.query.HiveQueryContext;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.utils.CachedFile;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.Constants;
import br.com.tim.utils.FormatDateEnum;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.joda.time.base.AbstractPartial;

import java.io.IOException;
import java.sql.SQLException;

public class ExportContext extends HiveQueryContext {

    protected static Logger log = Logger.getLogger(ExportContext.class);
    private String paramData;


    @Override
    protected void configuration() throws HiveIngestionInitializationException {

        try{
            int minusDays = this.getConfig().getInt(Constants.PARAM_MINUS_DAY,1);

            LocalDate dateRef = getReprocessDay();
            if (null == dateRef){
                dateRef = LocalDate.now().minusDays(minusDays);
            }

            addParam(TraftarPosBscs9Constants.PARAM_DATA_REF_PARTICAO,dateRef,
                    FormatDateEnum.YYYYMMDD,FormatDateEnum.YYYY_MM_DD, FormatDateEnum.DDMMYY);
            log.info("Date Reference is " + dateRef.toString(FormatDateEnum.YYYY_MM_DD.getDateFormat()));

        }catch(Exception e){
            throw new HiveIngestionInitializationException(e);
        }
    }

    protected LocalDate getReprocessDay(){
        if (ArrayUtils.isNotEmpty(this.getArgs())){
            String param = this.getArgs()[0];
            if (StringUtils.startsWithIgnoreCase(param, Constants.REPROCESS_DAY)){
                log.info("TYPE PROCESS IS REPROCESS");
                return  FormatDateEnum.YYYY_MM_DD.getDateFormat().parseLocalDate(StringUtils.substringAfter(param,"="));
            }
        }
        return null;
    }

    public void addParamDates(AbstractPartial data, FormatDateEnum ... format) throws SQLException {
        addParam(Constants.PARAM+"-date",data,format);
    }

    public void addParam(String prefix, AbstractPartial data, FormatDateEnum ... formats) throws SQLException {
        for (FormatDateEnum format : formats){
            this.getConfig().set(prefix+"-"+format.getText(),data.toString(format.getDateFormat()));
        }
    }
}
