package br.com.tim.mapreduce.joinbdo_b;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanValue;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBValue;
import br.com.tim.mapreduce.model.TraftarPosBscs9;

public class TraftarPosBscs9Mapper<T> extends Mapper<T, Text, TraftarPosBscs9JoinBdoBKey, TraftarPosBscs9JoinBdoBValue>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9Mapper.class);
	
	private TraftarPosBscs9JoinBdoBKey outKey;
	private TraftarPosBscs9JoinBdoBValue outValue;
	
	private TraftarPosBscs9 traftar;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outKey = new TraftarPosBscs9JoinBdoBKey();
		this.outValue = new TraftarPosBscs9JoinBdoBValue();
		
		this.traftar = new TraftarPosBscs9();
		
	}
	
	@Override
	protected void map(T key, Text value, Context context) throws IOException, InterruptedException {
		
		this.outKey.clean();
		this.traftar.clean();
		
		String line = value.toString();
		
		if ( StringUtils.isBlank(line) ) return;
		
		this.traftar.setFromText(line);
		
		this.outKey.set(this.traftar);
		this.outValue.set(this.traftar);
		
		context.getCounter("MAPPER", "TRAFTAR WRITTEN").increment(1L);
		context.write(this.outKey, this.outValue);
		
	}
	
}
