package br.com.tim.utils;

public class Constants {

    public static final String PARAM = "param";
    public static final String PARAM_MINUS_DAY = "param-minus-day";
    public static final String REPROCESS_DAY = "reprocess-day";

}
