package br.com.tim.mapreduce.finders;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Reducer;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.model.CNEstado;
import br.com.tim.model.PlanoTarifario;
import br.com.tim.utils.CachedFile;

public class PlanoTarifarioFinder {
	
	private static PlanoTarifarioFinder finder;
	
	@SuppressWarnings("rawtypes")
	public static synchronized PlanoTarifarioFinder getInstance(Configuration conf) {
		if ( null == finder )
			return new PlanoTarifarioFinder(conf);
		return finder;
	}
	
	private static List< PlanoTarifario > list;
	private static PlanoTarifario searchKey;
	private static PlanoTarifario nullPlano;

	public class PlanoTarifarioComparator implements Comparator< PlanoTarifario > {
		@Override
		public int compare( PlanoTarifario o1, PlanoTarifario o2 ) {		
			int r =  o1.getCodPlanoTarifarioPosOltp().compareTo(o2.getCodPlanoTarifarioPosOltp());
			
			if ( 0 == r )
				r = o1.getCodSistemaFonte().compareTo(o2.getCodSistemaFonte());
			
			return r;
		}
	}
	
	private static PlanoTarifarioComparator comparator;
	
	private List< PlanoTarifario > loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
		return CachedFile.getTextFileAsObjectList(
				conf, 
				DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.PLANO_TARIFARIO_DIR),
				false, 
				PlanoTarifario.class );
	}
	
	@SuppressWarnings("rawtypes")
	public PlanoTarifarioFinder( Configuration conf ) {
		searchKey = new PlanoTarifario();
		comparator = new PlanoTarifarioComparator();
		searchKey = new PlanoTarifario();
		nullPlano = null;
		
		try {
			list = loadCachedFile(conf);
		} catch ( IllegalArgumentException | CommonsException e ) {
			throw new RuntimeException( e );
		}
		
		Collections.sort( list, comparator );
	}
	
	public PlanoTarifario find(String codPlanoTarifarioPosOltp) {
		searchKey.setCodPlanoTarifarioPosOltp(codPlanoTarifarioPosOltp);
		searchKey.setCodSistemaFonte("0");
		
		if ( list.size() == 0 ) return nullPlano;
		
		int pos = Collections.binarySearch( list, searchKey, comparator );
		return ( pos >= 0 ) ? list.get( pos ) : nullPlano;
	}
	
}
