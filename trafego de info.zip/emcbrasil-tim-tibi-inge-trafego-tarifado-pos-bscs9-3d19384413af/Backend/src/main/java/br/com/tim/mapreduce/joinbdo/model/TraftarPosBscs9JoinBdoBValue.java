package br.com.tim.mapreduce.joinbdo.model;

import org.apache.hadoop.io.GenericWritable;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.Bdo;
import br.com.tim.mapreduce.model.TraftarPosBscs9;

public class TraftarPosBscs9JoinBdoBValue extends GenericWritable {

	@SuppressWarnings("rawtypes")
	private static Class[] CLASSES = new Class[] { 
			Bdo.class, 
			TraftarPosBscs9.class,
			TraftarPosBscs9JoinBdoBValue.class };

	public TraftarPosBscs9JoinBdoBValue() {
	}

	public TraftarPosBscs9JoinBdoBValue(Writable value) {
		set(value);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected Class[] getTypes() {
		return CLASSES;
	}

	public Bdo getBDOValue() {
		return (Bdo) this.get();
	}
	
	public TraftarPosBscs9 getTraftarPosBscs9() {
		return (TraftarPosBscs9) this.get();
	}

}
