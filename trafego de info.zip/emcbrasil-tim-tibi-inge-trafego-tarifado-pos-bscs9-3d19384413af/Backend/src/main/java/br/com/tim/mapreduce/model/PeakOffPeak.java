package br.com.tim.mapreduce.model;

import br.com.tim.utils.CommonsConstants;
import org.apache.commons.lang3.StringUtils;

public class PeakOffPeak {

    private String ttCode;
    private String des;

    private static final int TT_CODE = 0, DES = 1;

    public static PeakOffPeak parseFromText(String text) {
        PeakOffPeak result = new PeakOffPeak();
        String[] values = StringUtils.splitByWholeSeparatorPreserveAllTokens(
                text, CommonsConstants.FILE_TXT_SPLIT_REGEX);

        result.ttCode = values[TT_CODE];
        result.des = values[DES];

        return result;
    }


    public String getTtCode() {
        return ttCode;
    }

    public void setTtCode(String ttCode) {
        this.ttCode = ttCode;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
