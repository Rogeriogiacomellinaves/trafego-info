package br.com.tim.mapreduce.finders;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.model.CNEstado;
import br.com.tim.model.Pacote;
import br.com.tim.utils.CachedFile;

public class PacoteFinder {
	
	private static PacoteFinder finder;
	
	@SuppressWarnings("rawtypes")
	public static synchronized PacoteFinder getInstance(Configuration conf) {
		if ( null == finder )
			return new PacoteFinder(conf);
		return finder;
	}
	
	private static List< Pacote > list;
	private static Pacote searchKey;
	private static Pacote nullPct;

	public class PacoteComparator implements Comparator< Pacote > {
		@Override
		public int compare( Pacote o1, Pacote o2 ) {		
			return Integer.compare(o1.getSkyPacote(), o2.getSkyPacote());
		}
	}
	
	private static PacoteComparator comparator;
	
	private List< Pacote > loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
		return CachedFile.getTextFileAsObjectList(
				conf, 
				DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.PACOTE_DIR),
				false, 
				Pacote.class );
	}
	
	@SuppressWarnings("rawtypes")
	public PacoteFinder( Configuration conf ) {
		searchKey = new Pacote();
		comparator = new PacoteComparator();
		searchKey = new Pacote();
		nullPct = null;
		
		try {
			list = loadCachedFile(conf);
		} catch ( IllegalArgumentException | CommonsException e ) {
			throw new RuntimeException( e );
		}
		
		Collections.sort( list, comparator );
	}
	
	public Pacote find(int skyPacote) {
		searchKey.setSkyPacote(skyPacote);
		
		if ( list.size() == 0 ) return nullPct;
		
		int pos = Collections.binarySearch( list, searchKey, comparator );
		return ( pos >= 0 ) ? list.get( pos ) : nullPct;
	}
	
}
