package br.com.tim.mapreduce.joinbdo_b;

import org.apache.hadoop.mapreduce.Partitioner;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBValue;

public class TraftarPosBscs9JoinBdoBPartitioner extends Partitioner<TraftarPosBscs9JoinBdoBKey, TraftarPosBscs9JoinBdoBValue> {
	
	@Override
	public int getPartition(TraftarPosBscs9JoinBdoBKey key, TraftarPosBscs9JoinBdoBValue value, int numParts) {
		int hash = key.hashCode();
        int partition = Math.abs(hash % numParts);
        return partition;
	}

}
