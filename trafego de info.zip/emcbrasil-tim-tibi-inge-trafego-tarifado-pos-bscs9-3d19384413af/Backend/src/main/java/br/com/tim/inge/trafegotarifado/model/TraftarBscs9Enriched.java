package br.com.tim.inge.trafegotarifado.model;

import java.io.DataInput;

import java.io.DataOutput;

import java.io.IOException;

import java.text.ParseException;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import org.apache.hadoop.io.Writable;

import br.com.tim.utils.CommonsConstants;

/**
 * 
 * Utilizar classe br.com.tim.mapreduce.model.TraftarPosBscs9
 *
 */
@Deprecated
public class TraftarBscs9Enriched implements Writable, TraftarBscsEnriched {

	public TraftarBscs9 traftarBscs9;

	public String dddTelefonePagador;

	public String ufTelefonePagador;

	public String dddOrigemChamada;

	public String uFOrigemChamada;

	public String dddNumeroB;

	public String numeroBNormalizado;

	public String tipoTrafego;

	public String tipoCobranca;

	public String grupoTrafego;

	public String tipoRedeChamada;

	public String tipoOrigemChamada;

	public String tipoDestinoChamada;

	public String flagRoamimg;

	public String direcaoTrafego;

	public String tipoServico;

	public String csp;

	public String operadoraAOrigem;

	public String operadoraBDestino;

	public String inboundOutbound;

	public String descricaoPlanoTarifario;

	public String segmentoCliente;

	public String tipoCliente;

	public String pacote;

	public String cicloFaturamento;

	public String extrabundle;

	private static StringBuilder sb = new StringBuilder();

	public TraftarBscs9Enriched() {

		this.traftarBscs9 = new TraftarBscs9();

		clean();

	}

	public void clean() {

		this.traftarBscs9.clean();

		dddTelefonePagador = CommonsConstants.EMPTY;

		ufTelefonePagador = CommonsConstants.EMPTY;

		dddOrigemChamada = CommonsConstants.EMPTY;

		uFOrigemChamada = CommonsConstants.EMPTY;

		dddNumeroB = CommonsConstants.EMPTY;

		numeroBNormalizado = CommonsConstants.EMPTY;

		tipoTrafego = CommonsConstants.EMPTY;

		tipoCobranca = CommonsConstants.EMPTY;

		grupoTrafego = CommonsConstants.EMPTY;

		tipoRedeChamada = CommonsConstants.EMPTY;

		tipoOrigemChamada = CommonsConstants.EMPTY;

		tipoDestinoChamada = CommonsConstants.EMPTY;

		flagRoamimg = CommonsConstants.EMPTY;

		direcaoTrafego = CommonsConstants.EMPTY;

		tipoServico = CommonsConstants.EMPTY;

		csp = CommonsConstants.EMPTY;

		operadoraAOrigem = CommonsConstants.EMPTY;

		operadoraBDestino = CommonsConstants.EMPTY;

		inboundOutbound = CommonsConstants.EMPTY;

		descricaoPlanoTarifario = CommonsConstants.EMPTY;

		segmentoCliente = CommonsConstants.EMPTY;

		tipoCliente = CommonsConstants.EMPTY;

		pacote = CommonsConstants.EMPTY;

		cicloFaturamento = CommonsConstants.EMPTY;

		extrabundle = CommonsConstants.EMPTY;

	}

	public String serialize() {

		sb.setLength(0);

		sb.append(traftarBscs9.serialize());

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(dddTelefonePagador);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(ufTelefonePagador);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(dddOrigemChamada);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uFOrigemChamada);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(dddNumeroB);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(numeroBNormalizado);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoTrafego);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoCobranca);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(grupoTrafego);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoRedeChamada);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoOrigemChamada);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoDestinoChamada);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(flagRoamimg);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(direcaoTrafego);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoServico);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(csp);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(operadoraAOrigem);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(operadoraBDestino);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(inboundOutbound);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(descricaoPlanoTarifario);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(segmentoCliente);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tipoCliente);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(pacote);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cicloFaturamento);

		sb.append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(extrabundle);

		return sb.toString();

	}

	public void setTraftarBscsEnriched(String dddTelefonePagador, String ufTelefonePagador, String dddOrigemChamada,
			String uFOrigemChamada, String dddNumeroB, String numeroBNormalizado,

			String tipoTrafego, String tipoCobranca, String grupoTrafego, String tipoRedeChamada,
			String tipoOrigemChamada, String tipoDestinoChamada, String flagRoamimg, String direcaoTrafego,

			String tipoServico, String csp, String operadoraAOrigem, String operadoraBDestino, String inboundOutbound,
			String descricaoPlanoTarifario, String segmentoCliente, String tipoCliente,

			String pacote, String cicloFaturamento, String extrabundle) {

		this.dddTelefonePagador = dddTelefonePagador;

		this.ufTelefonePagador = ufTelefonePagador;

		this.dddOrigemChamada = dddOrigemChamada;

		this.uFOrigemChamada = uFOrigemChamada;

		this.dddNumeroB = dddNumeroB;

		this.numeroBNormalizado = numeroBNormalizado;

		this.tipoTrafego = tipoTrafego;

		this.tipoCobranca = tipoCobranca;

		this.grupoTrafego = grupoTrafego;

		this.tipoRedeChamada = tipoRedeChamada;

		this.tipoOrigemChamada = tipoOrigemChamada;

		this.tipoDestinoChamada = tipoDestinoChamada;

		this.flagRoamimg = flagRoamimg;

		this.direcaoTrafego = direcaoTrafego;

		this.tipoServico = tipoServico;

		this.csp = csp;

		this.operadoraAOrigem = operadoraAOrigem;

		this.operadoraBDestino = operadoraBDestino;

		this.inboundOutbound = inboundOutbound;

		this.descricaoPlanoTarifario = descricaoPlanoTarifario;

		this.segmentoCliente = segmentoCliente;

		this.tipoCliente = tipoCliente;

		this.pacote = pacote;

		this.cicloFaturamento = cicloFaturamento;

		this.extrabundle = extrabundle;

	}

	public boolean parseFromText(String textString) {

		if (StringUtils.isBlank(textString))

			return false;

		String[] cols = textString.split(CommonsConstants.FILE_SPLIT_REGEX, -1);

		if (cols.length != 673)

			return false;

		int i = 0;

		traftarBscs9.setTraftarBscs9_part1(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

		traftarBscs9.setTraftarBscs9_part2(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

		traftarBscs9.setTraftarBscs9_part3(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

		this.setTraftarBscsEnriched(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

				cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
				cols[i++]);

		return true;

	}

	@Override

	public void readFields(DataInput in) throws IOException {

		traftarBscs9.readFields(in);

		this.dddTelefonePagador = in.readUTF();

		this.ufTelefonePagador = in.readUTF();

		this.dddOrigemChamada = in.readUTF();

		this.uFOrigemChamada = in.readUTF();

		this.dddNumeroB = in.readUTF();

		this.numeroBNormalizado = in.readUTF();

		this.tipoTrafego = in.readUTF();

		this.tipoCobranca = in.readUTF();

		this.grupoTrafego = in.readUTF();

		this.tipoRedeChamada = in.readUTF();

		this.tipoOrigemChamada = in.readUTF();

		this.tipoDestinoChamada = in.readUTF();

		this.flagRoamimg = in.readUTF();

		this.direcaoTrafego = in.readUTF();

		this.tipoServico = in.readUTF();

		this.csp = in.readUTF();

		this.operadoraAOrigem = in.readUTF();

		this.operadoraBDestino = in.readUTF();

		this.inboundOutbound = in.readUTF();

		this.descricaoPlanoTarifario = in.readUTF();

		this.segmentoCliente = in.readUTF();

		this.tipoCliente = in.readUTF();

		this.pacote = in.readUTF();

		this.cicloFaturamento = in.readUTF();

		this.extrabundle = in.readUTF();

	}

	@Override

	public void write(DataOutput out) throws IOException {

		traftarBscs9.write(out);

		out.writeUTF(this.dddTelefonePagador);

		out.writeUTF(this.ufTelefonePagador);

		out.writeUTF(this.dddOrigemChamada);

		out.writeUTF(this.uFOrigemChamada);

		out.writeUTF(this.dddNumeroB);

		out.writeUTF(this.numeroBNormalizado);

		out.writeUTF(this.tipoTrafego);

		out.writeUTF(this.tipoCobranca);

		out.writeUTF(this.grupoTrafego);

		out.writeUTF(this.tipoRedeChamada);

		out.writeUTF(this.tipoOrigemChamada);

		out.writeUTF(this.tipoDestinoChamada);

		out.writeUTF(this.flagRoamimg);

		out.writeUTF(this.direcaoTrafego);

		out.writeUTF(this.tipoServico);

		out.writeUTF(this.csp);

		out.writeUTF(this.operadoraAOrigem);

		out.writeUTF(this.operadoraBDestino);

		out.writeUTF(this.inboundOutbound);

		out.writeUTF(this.descricaoPlanoTarifario);

		out.writeUTF(this.segmentoCliente);

		out.writeUTF(this.tipoCliente);

		out.writeUTF(this.pacote);

		out.writeUTF(this.cicloFaturamento);

		out.writeUTF(this.extrabundle);

	}

	@Override

	public String getSPNumberAddress() {

		return traftarBscs9.getSPNumberAddress();

	}

	@Override

	public String getSPLocationAddress() {

		return traftarBscs9.getSPLocationAddress();

	}

	@Override

	public String getOPNormedNumAddress() {

		return traftarBscs9.getOPNormedNumAddress();

	}

	@Override

	public String getOPNumberAddress() {

		return traftarBscs9.getOPNumberAddress();

	}

	@Override

	public String getNetElementAddress() {

		return traftarBscs9.getNetElementAddress();

	}

	@Override

	public String getNumFollowUpCallType() {

		return traftarBscs9.getNumFollowUpCallType();

	}

	@Override

	public String getNumTariffInfoSncode() {

		return traftarBscs9.getNumTariffInfoSncode();

	}

	@Override

	public String getNumTariffInfoZncode() {

		return traftarBscs9.getNumTariffInfoZncode();

	}

	@Override

	public String getNumTechnInfoLngDistCarrierCd() {

		return traftarBscs9.getNumTechnInfoLngDistCarrierCd();

	}

	@Override

	public String getLdcInfoCarrierCode() {

		return traftarBscs9.getLdcInfoCarrierCode();

	}

	@Override

	public String getNumTariffInfoTmcode() {

		return traftarBscs9.getNumTariffInfoTmcode();

	}

	@Override

	public String getNumCustInfoContractId() {

		return traftarBscs9.getNumCustInfoContractId();

	}

	@Override

	public String getNumFreeUnitsInfoFuPackId() {

		return traftarBscs9.getNumFreeUnitsInfoFuPackId();

	}

	@Override

	public String getSPLocationAreaCode() {

		return traftarBscs9.getSPLocationAreaCode();

	}

	@Override

	public Date getTrafTarDate() throws ParseException {

		return traftarBscs9.getTrafTarDate();

	}

	@Override

	public String getTipoServico() {

		return tipoServico;

	}

	@Override

	public String getDDDOrigemChamada() {

		return dddOrigemChamada;

	}

	@Override

	public String getDDDNumeroB() {

		return dddNumeroB;

	}

	@Override

	public String getGrupoTrafego() {

		return grupoTrafego;

	}

	@Override

	public String getTipoDestinoChamada() {

		return tipoDestinoChamada;

	}

	@Override

	public String getDDDTelefonePagador() {

		return dddTelefonePagador;

	}

	@Override

	public String getTipoTrafego() {

		return tipoTrafego;

	}

	@Override

	public String getTipoOrigemChamada() {

		return tipoOrigemChamada;

	}

	@Override

	public String getNumeroBNormalizado() {

		return numeroBNormalizado;

	}

	public TraftarBscs9 getTraftarBscs9() {

		return traftarBscs9;

	}

	public void setTraftarBscs9(TraftarBscs9 traftarBscs9) {

		this.traftarBscs9 = traftarBscs9;

	}

}