package br.com.tim.mapreduce.joinbdo_a;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.finders.AplicacoesVasFinder;
import br.com.tim.mapreduce.finders.CNEstadoFinder;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAValue;
import br.com.tim.mapreduce.model.Bdo;
import br.com.tim.mapreduce.model.EOTPrestadora;
import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Regras;
import br.com.tim.model.Cadup;
import br.com.tim.utils.CachedFile;

public class TraftarPosBscs9JoinBdoAReducer extends Reducer<TraftarPosBscs9JoinBdoAKey, TraftarPosBscs9JoinBdoAValue, NullWritable, TraftarPosBscs9>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9JoinBdoAReducer.class);
	
	private List<Bdo> bdos;
	
	private static Map<String, List<Cadup>> cadupMap;
	private static Map<String, List<EOTPrestadora>> eotMap;
	
	private static CNEstadoFinder cnEstadoFinder;
	private static AplicacoesVasFinder aplicacoesVasFinder;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		bdos = new ArrayList<Bdo>();
		
		try {
			cadupMap = CachedFile.getMapFromTextFile(
									context.getConfiguration(), 
									context.getConfiguration().get(TraftarPosBscs9Constants.CADUP_DIR), 
									92000, 
									Cadup.class );

			eotMap = CachedFile.getMapFromObjectList(
									CachedFile.getTextFileAsObjectList(
											context.getConfiguration(), 
											context.getConfiguration().get(TraftarPosBscs9Constants.EOT_PRESTADORA_DIR), 
											false, 
											EOTPrestadora.class), 
											"codigo" );
			cnEstadoFinder = CNEstadoFinder.getInstance(context.getConfiguration());
			aplicacoesVasFinder = AplicacoesVasFinder.getInstance(context.getConfiguration());
			
		} catch (CommonsException e) {
			LOG.error("Error setting up the Reducer...", e);
			throw new IOException(e);
		}
		
	}
	
	@Override
	protected void reduce(TraftarPosBscs9JoinBdoAKey key, Iterable<TraftarPosBscs9JoinBdoAValue> values, Context context) throws IOException, InterruptedException {
		
		bdos.clear();
		
		for ( TraftarPosBscs9JoinBdoAValue value : values ) {
			
			if ( value.get() instanceof Bdo ) {
				context.getCounter("REDUCER", "BDO ARRIVED").increment(1L);
				bdos.add(new Bdo(value.getBDOValue()));
			}
			
			if ( value.get() instanceof TraftarPosBscs9 ) {
				context.getCounter("REDUCER", "TRAFTAR ARRIVED").increment(1L);
				TraftarPosBscs9 traftar = value.getTraftarPosBscs9();
				
				if ( key.getNumTelefoneA().startsWith("DADOS") )
					context.getCounter("REDUCER", "TRAFTAR W/O BDO WRITTEN").increment(1L);
				else
					context.getCounter("REDUCER", "TRAFTAR WITH BDO WRITTEN").increment(1L);
				
				traftar = TraftarPosBscs9Regras.enrichTrafTarA(traftar, bdos, eotMap, cadupMap, cnEstadoFinder, aplicacoesVasFinder);
				
				context.write(NullWritable.get(), traftar);
				
			}
			
		}
		
	}
	
}
