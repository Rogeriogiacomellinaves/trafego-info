package br.com.tim.mapreduce.finders;

import java.util.List;

import org.apache.hadoop.mapreduce.Reducer.Context;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.model.CentralVolte;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.utils.CachedFile;

public class CentralVolteFinder {
	
private static CNEstadoFinder finder;
	
	private List<CentralVolte> list;

	@SuppressWarnings("rawtypes")
	public CentralVolteFinder(Context context) {
		try {
			this.list = CachedFile.getTextFileAsObject(context.getConfiguration(), 
					DriverUtils.getAuxiliaryPath(context.getConfiguration(), TraftarPosBscs9Constants.AUXILIARY_CENTRAIS_VOLTE_PATH).toUri().toString(), 
					false,
					CentralVolte.class);
		} catch (IllegalArgumentException | CommonsException e) {
			throw new RuntimeException(e);
		}
	}

	public boolean find(String netElementAddress) {
		for (CentralVolte central : list) {
			if (central.getNetElementAddress().equals(netElementAddress)) {
				return true;
			}
		}

		return false;
	}

	public int size() {
		return list.size();
	}

	public String printFirstValue() {
		return list.get(0).getNetElementAddress();
	}

	public String printLastValue() {
		return list.get(size() - 1).getNetElementAddress();
	}
}
