package br.com.tim.mapreduce.finders;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.model.AplicacoesVas;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Utils;
import br.com.tim.utils.SequenceCachedFile;

public class AplicacoesVasFinder {
	
	private static AplicacoesVasFinder finder;
	
	@SuppressWarnings("rawtypes")
	public static synchronized AplicacoesVasFinder getInstance(Configuration conf) {
		if ( null == finder )
			return new AplicacoesVasFinder(conf);
		return finder;
	}
	
	private static List< AplicacoesVas > list;
	private static List< AplicacoesVas > listBySpId;
	private static AplicacoesVas searchKey;
	private static AplicacoesVas searchKeyBySpId;
	private static AplicacoesVas nullVas;

	public class AplicacoesVasComparator implements Comparator< AplicacoesVas > {
		@Override
		public int compare( AplicacoesVas o1, AplicacoesVas o2 ) {
			int r = Long.compare(o1.getContractId(), o2.getContractId());
			
			if ( 0 == r )
				r = Long.compare(o1.getSpId(), o2.getSpId());
			
			return r;
		}
	}

	public class AplicacoesVasComparatorBySpId implements Comparator< AplicacoesVas > {
		@Override
		public int compare( AplicacoesVas o1, AplicacoesVas o2 ) {
			int r = Long.compare(o1.getSpId(), o2.getSpId());
			return r;
		}
	}
	
	private static AplicacoesVasComparator comparator;
	private static AplicacoesVasComparatorBySpId comparatorBySpId;
	
	private List< AplicacoesVas > loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
		return SequenceCachedFile.getSequenceFileAsObjectList(
				conf, 
				DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.APLICACOES_VAS_DIR).toUri().toString(),
				false, 
				AplicacoesVas.class );
	}
	
	public AplicacoesVasFinder( Configuration conf ) {
		searchKey = new AplicacoesVas();
		comparator = new AplicacoesVasComparator();
		comparatorBySpId = new AplicacoesVasComparatorBySpId();
		searchKey = new AplicacoesVas();
		searchKeyBySpId = new AplicacoesVas();
		nullVas = null;
		
		try {
			list = loadCachedFile(conf);
			listBySpId = loadCachedFile(conf);
		} catch ( IllegalArgumentException | CommonsException e ) {
			throw new RuntimeException( e );
		}
		
		Collections.sort( list, comparator );
		Collections.sort( listBySpId, comparatorBySpId );
	}
	
	public AplicacoesVas find(String oPNumberAddress, String numTechInfoLngDistCarrierCd) {
		long contractId = StringUtils.isNumeric(oPNumberAddress) ? Long.parseLong(oPNumberAddress) : 0L;
		long spId = StringUtils.isNumeric(numTechInfoLngDistCarrierCd) ? Long.parseLong(numTechInfoLngDistCarrierCd) : 0L;
		
		if ( contractId == 0 || spId == 0 ) return nullVas;
		
		searchKey.setContractId(contractId);
		searchKey.setSpId(spId);
		
		if ( list.size() == 0 ) return nullVas;
		
		int pos = Collections.binarySearch( list, searchKey, comparator );
		
		if ( pos < 0 )
			searchKey.setContractId(Long.parseLong(TraftarPosBscs9Utils.removeLastChar(oPNumberAddress)));
		
		pos = Collections.binarySearch( list, searchKey, comparator );
		
		return ( pos >= 0 ) ? list.get( pos ) : nullVas;
	}

	public AplicacoesVas findBySpId(String numTechInfoLngDistCarrierCd) {
		long spId = StringUtils.isNumeric(numTechInfoLngDistCarrierCd) ? Long.parseLong(numTechInfoLngDistCarrierCd) : 0L;

		searchKeyBySpId.setSpId(spId);

		if ( listBySpId.size() == 0 ) return nullVas;

		int pos = Collections.binarySearch( listBySpId, searchKeyBySpId, comparatorBySpId );

		return ( pos >= 0 ) ? listBySpId.get( pos ) : nullVas;
	}
	
}
