package br.com.tim.mapreduce.joinbdo_a;

import org.apache.hadoop.io.WritableComparator;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAKey;

public class TraftarPosBscs9JoinBdoAGroupingComparator extends WritableComparator {

	public TraftarPosBscs9JoinBdoAGroupingComparator	() {
        super(TraftarPosBscs9JoinBdoAKey.class, true);
    }
	
	@Override
	public int compare(Object a, Object b) {
		TraftarPosBscs9JoinBdoAKey key1 = (TraftarPosBscs9JoinBdoAKey) a;
		TraftarPosBscs9JoinBdoAKey key2 = (TraftarPosBscs9JoinBdoAKey) b;
		return key1.compareTo(key2);
	}

}
