package br.com.tim.mapreduce.joinbasecan;

import org.apache.hadoop.mapreduce.Partitioner;

import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanValue;

public class TraftarPosBscs9JoinBaseCanPartitioner extends Partitioner<TraftarPosBscs9JoinBaseCanKey, TraftarPosBscs9JoinBaseCanValue> {
	
	@Override
	public int getPartition(TraftarPosBscs9JoinBaseCanKey key, TraftarPosBscs9JoinBaseCanValue value, int numParts) {
		int hash = key.hashCode();
        int partition = Math.abs(hash % numParts);
        return partition;
	}

}
