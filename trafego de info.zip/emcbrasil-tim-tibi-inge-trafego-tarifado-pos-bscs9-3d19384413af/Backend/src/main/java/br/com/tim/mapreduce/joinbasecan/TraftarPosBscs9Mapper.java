package br.com.tim.mapreduce.joinbasecan;

import java.io.IOException;

import br.com.tim.mapreduce.finders.PeakOffPeakFinder;
import br.com.tim.mapreduce.model.PeakOffPeak;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanValue;
import br.com.tim.mapreduce.model.TraftarPosBscs9;

public class TraftarPosBscs9Mapper<T> extends Mapper<T, Text, TraftarPosBscs9JoinBaseCanKey, TraftarPosBscs9JoinBaseCanValue>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9Mapper.class);
	
	private TraftarPosBscs9JoinBaseCanKey outKey;
	private TraftarPosBscs9JoinBaseCanValue outValue;
	
	private TraftarPosBscs9 traftar;

	private PeakOffPeakFinder peakOffPeakFinder;
	private PeakOffPeak peakOffPeak;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outKey = new TraftarPosBscs9JoinBaseCanKey();
		this.outValue = new TraftarPosBscs9JoinBaseCanValue();
		
		this.traftar = new TraftarPosBscs9();

		peakOffPeakFinder = new PeakOffPeakFinder(context.getConfiguration());
	}
	
	@Override
	protected void map(T key, Text value, Context context) throws IOException, InterruptedException {
		peakOffPeak = null;

		this.outKey.clean();
		this.traftar.clean();
		
		String line = value.toString();
		
		if ( StringUtils.isBlank(line) ) return;
		
		this.traftar.setFromText(line);
		setPeakOffPeak();
		
		this.outKey.set(this.traftar);
		this.outValue.set(this.traftar);
		
		context.getCounter("MAPPER", "TRAFTAR WRITTEN").increment(1L);
		context.write(this.outKey, this.outValue);
	}

	private void setPeakOffPeak() {
		peakOffPeak = peakOffPeakFinder.find(traftar.getTariffDetailTtcode());

		if (peakOffPeak != null) {
			if (StringUtils.containsIgnoreCase(peakOffPeak.getDes(), TraftarPosBscs9Constants.NORMAL) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.DIA) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.NOITE) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.DIA_2) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.GPRSDIA) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.GPRSNOITE))
				traftar.setPeakOffPeak(TraftarPosBscs9Constants.PE);
			else if (StringUtils.containsIgnoreCase(peakOffPeak.getDes(), TraftarPosBscs9Constants.REDUZIDO) ||
					StringUtils.containsIgnoreCase(peakOffPeak.getDes(), TraftarPosBscs9Constants.TODO) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.FSDIA) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.FSNOITE) ||
					peakOffPeak.getDes().equalsIgnoreCase(TraftarPosBscs9Constants.NOITE_2) ||
					StringUtils.containsIgnoreCase(peakOffPeak.getDes(), TraftarPosBscs9Constants.FIM_DE_SEMANA))
				traftar.setPeakOffPeak(TraftarPosBscs9Constants.OP);
		}
	}
}
