package br.com.tim.mapreduce.model;

import br.com.tim.model.Pacote;
import br.com.tim.utils.CommonsConstants;
import org.apache.commons.lang3.StringUtils;

public class CecCicloFaturamento {

    private String identificadorCicloFaturamento;
    private String descricaoCicloFaturamento;
    private String categoriaCiclo;

    private static final int
            IDENTIFICADOR_CICLO_FATURAMENTO_COLUMN = 1,
            DESCRICAO_CICLO_FATURAMENTO_COLUMN = 2,
            CATEGORIA_CICLO_COLUMN = 3;


    public static CecCicloFaturamento parseFromText(String text) {
        CecCicloFaturamento result = new CecCicloFaturamento();
        String[] values = StringUtils.splitByWholeSeparatorPreserveAllTokens(
                text, CommonsConstants.FILE_FIELD_SEPARATOR);

        result.identificadorCicloFaturamento = values[IDENTIFICADOR_CICLO_FATURAMENTO_COLUMN];
        result.descricaoCicloFaturamento = values[DESCRICAO_CICLO_FATURAMENTO_COLUMN];
        result.categoriaCiclo = values[CATEGORIA_CICLO_COLUMN];

        return result;
    }

    public String getIdentificadorCicloFaturamento() {
        return identificadorCicloFaturamento;
    }

    public void setIdentificadorCicloFaturamento(String identificadorCicloFaturamento){
        this.identificadorCicloFaturamento = identificadorCicloFaturamento;
    }

    public String getDescricaoCicloFaturamento() {
        return descricaoCicloFaturamento;
    }

    public String getCategoriaCiclo() {
        return categoriaCiclo;
    }
}
