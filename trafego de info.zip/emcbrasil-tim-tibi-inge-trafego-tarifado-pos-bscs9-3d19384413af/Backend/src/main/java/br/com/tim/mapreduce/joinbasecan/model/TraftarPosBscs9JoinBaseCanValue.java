package br.com.tim.mapreduce.joinbasecan.model;

import org.apache.hadoop.io.GenericWritable;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.TraftarPosBscs9;

public class TraftarPosBscs9JoinBaseCanValue extends GenericWritable {

	@SuppressWarnings("rawtypes")
	private static Class[] CLASSES = new Class[] { 
			BaseCandidataPrePosValue.class, 
			TraftarPosBscs9.class,
			TraftarPosBscs9JoinBaseCanValue.class };

	public TraftarPosBscs9JoinBaseCanValue() {
	}

	public TraftarPosBscs9JoinBaseCanValue(Writable value) {
		set(value);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected Class[] getTypes() {
		return CLASSES;
	}

	public BaseCandidataPrePosValue getBaseCandidataPrePosValue() {
		return (BaseCandidataPrePosValue) this.get();
	}
	
	public TraftarPosBscs9 getTraftarPosBscs9() {
		return (TraftarPosBscs9) this.get();
	}

}
