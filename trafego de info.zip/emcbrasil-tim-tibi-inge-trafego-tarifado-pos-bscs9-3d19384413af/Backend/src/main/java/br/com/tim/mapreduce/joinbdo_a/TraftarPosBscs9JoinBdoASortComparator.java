package br.com.tim.mapreduce.joinbdo_a;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAKey;

public class TraftarPosBscs9JoinBdoASortComparator extends WritableComparator {

	public TraftarPosBscs9JoinBdoASortComparator() {
        super(TraftarPosBscs9JoinBdoAKey.class, true);
    }
	
	@SuppressWarnings("rawtypes")
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		TraftarPosBscs9JoinBdoAKey key1 = (TraftarPosBscs9JoinBdoAKey) a;
		TraftarPosBscs9JoinBdoAKey key2 = (TraftarPosBscs9JoinBdoAKey) b;
		
		int result = key1.compareTo(key2);
		
		if ( 0 == result )
			result = Long.compare(key1.getOrdem(), key2.getOrdem());

        return result;
	}

}
