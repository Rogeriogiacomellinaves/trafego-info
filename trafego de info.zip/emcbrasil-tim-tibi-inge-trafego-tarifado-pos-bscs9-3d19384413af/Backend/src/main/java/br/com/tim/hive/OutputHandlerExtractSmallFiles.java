package br.com.tim.hive;

import br.com.tim.hive.query.HiveQueryContext;
import br.com.tim.hive.query.HiveQueryOutputHandler;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * This
 *
 * @author alexandro.feltrin
 */
public class OutputHandlerExtractSmallFiles extends HiveQueryOutputHandler {

    protected static Logger _log = Logger.getLogger(br.com.tim.hive.query.OutputHandlerExtractSmallFiles.class);

    private String header, inputEncoding,outPutEncoding;
    private boolean addHeader, combineStaging, encoding, gzip;
    private Path input, staging , output;
    private String fineNameOutPut;

    public OutputHandlerExtractSmallFiles init(HiveQueryContext context){
        super.init(context);

        validate(this.context.getConfig(),"extract-input-path","extract-staging-path","extract-filename-path");

        this.addHeader = this.context.getConfig().getBoolean("extract-add-header",false);
        this.header = this.context.getConfig().get("extract-content-header",StringUtils.EMPTY);
        this.input = new Path(this.context.getConfig().get("extract-input-path"));
        this.staging = new Path(this.context.getConfig().get("extract-staging-path"));
        this.output = new Path(this.context.getConfig().get("extract-output-path"));
        this.fineNameOutPut = this.context.getConfig().get("extract-filename-path");
        this.encoding = this.context.getConfig().getBoolean("extract-flag-encoding",false);
        this.inputEncoding = this.context.getConfig().get("extract-input-encoding", "UTF-8");
        this.outPutEncoding = this.context.getConfig().get("extract-output-encoding","UTF-8");
        this.gzip = this.context.getConfig().getBoolean("extract-flag-gzip",false);
        return this;
    }

    public void execute() throws Exception {

        try{
            // Used to combine files and add header if is necessary.
            combineFiles();

            // Preparer encoding files e output
            preparerOutPutFiles();

        }catch (FileNotFoundException e){
            _log.warn(e.getMessage());
        }
    }

    protected  void combineFiles() throws Exception{

        Path fileOutput = new Path(staging, "00000");
        fs.delete(fileOutput, true);
        OutputStream outputStream = null;

        _log.info("Reading " + input);
        FileStatus[] files = fs.listStatus(input);
        if (ArrayUtils.isEmpty(files)) {
            throw new FileNotFoundException("Files not found to combine.");
        }

        try {
            _log.info("Creating " + fileOutput);
            outputStream = fs.create(fileOutput);
            if (StringUtils.isNotEmpty(header)) {
                outputStream.write((header + "\n").getBytes());
            }

            for (FileStatus file: files ) {
                if (file.isDirectory()){
                    continue;
                }
                _log.info("Opening file " + file.getPath());
                InputStream in = fs.open(file.getPath());
                try {
                    _log.info("Writing file " + file.getPath() + " on " + fileOutput);
                    IOUtils.copyBytes(in, outputStream, context.getConfig(),false);
                }finally {
                    in.close();
                }
            }
            //cleanup older directory (if any)
            fs.delete(input, true);
        } finally {
            if (null != outputStream)
            outputStream.close();
        }
    }

    protected void preparerOutPutFiles() throws Exception{

        Path inputFiles = staging;
        Path outPutFiles = new Path(output, fineNameOutPut);

        if (fs.exists(outPutFiles)){
            _log.info("Removing " + outPutFiles);
            fs.delete(outPutFiles,true);
        }

        if (fs.isDirectory(staging)){
            inputFiles = new Path(staging,"*");
        }

        String cmd = buildComands(inputFiles,outPutFiles,encoding,inputEncoding,outPutEncoding,gzip);
        executeCmd(cmd);
    }

    protected String buildComands(Path inputPath , Path outputPath ,boolean encoding, String input_encoding , String output_encoding , boolean gzip){
        StringBuilder cmd = new StringBuilder();
        cmd.append(" hadoop fs -cat ").append(inputPath);

        if (encoding){
            cmd.append(" | ");
            cmd.append(" iconv -f ").append(input_encoding).append(" -t ").append(output_encoding).append("//TRANSLIT");
        }

        if (gzip) {
            cmd.append(" | ");
            cmd.append(" gzip -c ");
        }

        cmd.append(" | ");
        cmd.append(" hadoop fs -put -f - ").append(outputPath);

        if (gzip) {
            cmd.append(".gz");
        }

        return cmd.toString();
    }

    private void executeCmd(String command) throws Exception{

        String[] cmd = { "/bin/sh", "-c", command };

        _log.info("Started");
        _log.info(command);
        Process process = Runtime.getRuntime().exec(cmd);
        process.waitFor();
        _log.info("Finished");
    }

    public static void validate(Configuration configuration, String... keys) throws RuntimeException {
        _log.info("Validating configuration file...");

        for (String key: keys) {
            try {
                if (StringUtils.isEmpty(configuration.get(key))) {
                    throw new RuntimeException("ERROR: " + key + " parameter is not set. Check out the configuration file.");
                }
            } catch (NullPointerException e) {
                throw new NullPointerException("The Configuration is not initialize!" + e.getMessage());
            }
        }

        _log.info("Configuration file validated successfully!");
    }

}
