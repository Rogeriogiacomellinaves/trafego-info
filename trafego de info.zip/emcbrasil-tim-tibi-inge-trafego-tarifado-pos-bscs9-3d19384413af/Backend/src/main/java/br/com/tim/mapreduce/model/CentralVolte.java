package br.com.tim.mapreduce.model;

import br.com.tim.utils.CommonsConstants;

public class CentralVolte {

	private String netElementAddress;
	
	public CentralVolte() {
		clean();
	}
	
	public CentralVolte(String netElementAddress) {
		this.netElementAddress = netElementAddress;
	}

	public void clean() {
		netElementAddress = CommonsConstants.EMPTY;
	}
	
	public String getNetElementAddress() {
		return netElementAddress;
	}

	public void setNetElementAddress(String netElementAddress) {
		this.netElementAddress = netElementAddress;
	}
	
	public static CentralVolte parseFromText(String text) {
		return new CentralVolte(text);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((netElementAddress == null) ? 0 : netElementAddress.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CentralVolte other = (CentralVolte) obj;
		if (netElementAddress == null) {
			if (other.netElementAddress != null)
				return false;
		} else if (!netElementAddress.equals(other.netElementAddress))
			return false;
		return true;
	}
	
	
}
