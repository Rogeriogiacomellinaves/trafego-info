package br.com.tim.mapreduce.joinbasecan;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;

public class TraftarPosBscs9JoinBaseCanSortComparator extends WritableComparator {

	public TraftarPosBscs9JoinBaseCanSortComparator() {
        super(TraftarPosBscs9JoinBaseCanKey.class, true);
    }
	
	@SuppressWarnings("rawtypes")
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		TraftarPosBscs9JoinBaseCanKey key1 = (TraftarPosBscs9JoinBaseCanKey) a;
		TraftarPosBscs9JoinBaseCanKey key2 = (TraftarPosBscs9JoinBaseCanKey) b;
		
		int result = key1.compareTo(key2);
		
		if ( 0 == result )
			result = Integer.compare(key1.getOrdem(), key2.getOrdem());

        return result;
	}

}
