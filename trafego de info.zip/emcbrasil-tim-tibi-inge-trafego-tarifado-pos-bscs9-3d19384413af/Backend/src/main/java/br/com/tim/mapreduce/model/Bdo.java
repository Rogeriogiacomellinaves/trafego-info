package br.com.tim.mapreduce.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.DateUtil;

/**
 * Base de Dados Operacional (BDO)
 * 
 * @author Gregory Elias Miguel
 * @version 01.00.00
 */
public class Bdo implements Writable {

	private static final SimpleDateFormat sdfHora = new SimpleDateFormat("ddMMyyyyHHmmss");

	public static final String TIPO_OPERACAO_C = "C";
	public static final String TIPO_OPERACAO_D = "D";

	public String numeroSequenciaLinha;
	public String tipoOperacao;
	public String numeroTelefone;
	public Date dataInicioJanela;
	public Date dataEfetivacaoTim;
	public String spid;
	public String eot;
	public String codigoRn1;
	public String codigoCnl;
	public String nomeArquivo;
	public String tipoArquivo;
	public String tsArquivo;
	public String seqArquivo;
	public String tsIngestao;

	public Bdo() {
		this.dataInicioJanela = new Date();
		this.dataEfetivacaoTim = new Date();
		this.clean();
	}
	
	public Bdo(Bdo o) {
		this.numeroSequenciaLinha = o.numeroSequenciaLinha;
		this.tipoOperacao = o.tipoOperacao;
		this.numeroTelefone = o.numeroTelefone;
		this.dataInicioJanela = new Date(o.dataInicioJanela.getTime());
		this.dataEfetivacaoTim = new Date(o.dataEfetivacaoTim.getTime());
		this.spid = o.spid;
		this.eot = o.eot;
		this.codigoRn1 = o.codigoRn1;
		this.codigoCnl = o.codigoCnl;
		this.nomeArquivo = o.nomeArquivo;
		this.tipoArquivo = o.tipoArquivo;
		this.tsArquivo = o.tsArquivo;
		this.seqArquivo = o.seqArquivo;
		this.tsIngestao = o.tsIngestao;
	}
	
	public void clean() {
		this.numeroSequenciaLinha  = CommonsConstants.EMPTY;
		this.tipoOperacao = CommonsConstants.EMPTY;
		this.numeroTelefone = CommonsConstants.EMPTY;
		this.dataInicioJanela.setTime(0L);
		this.dataEfetivacaoTim.setTime(0L);
		this.spid = CommonsConstants.EMPTY;
		this.eot = CommonsConstants.EMPTY;
		this.codigoRn1 = CommonsConstants.EMPTY;
		this.codigoCnl = CommonsConstants.EMPTY;
		this.nomeArquivo = CommonsConstants.EMPTY;
		this.tipoArquivo = CommonsConstants.EMPTY;
		this.tsArquivo = CommonsConstants.EMPTY;
		this.seqArquivo = CommonsConstants.EMPTY;
		this.tsIngestao = CommonsConstants.EMPTY;
	}

	public void parseFromText(String text) {
		
		String[] colunms = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
		int i = 0;

		this.numeroSequenciaLinha = colunms[i++];
		this.tipoOperacao = colunms[i++];
		this.numeroTelefone = colunms[i++];
		this.dataInicioJanela.setTime(StringUtils.isBlank(colunms[i]) ? 0L : DateUtil.parseDate(colunms[i], sdfHora).getTime()); i++;
		this.dataEfetivacaoTim.setTime(StringUtils.isBlank(colunms[i]) ? 0L : DateUtil.parseDate(colunms[i], sdfHora).getTime()); i++;
		this.spid = colunms[i++];
		this.eot = colunms[i++];
		this.codigoRn1 = colunms[i++];
		this.codigoCnl = colunms[i++];
		this.nomeArquivo = colunms[i++];
		this.tipoArquivo = colunms[i++];
		this.tsArquivo = colunms[i++];
		this.seqArquivo = colunms[i++];
		this.tsIngestao = colunms[i++];

	}	

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.numeroSequenciaLinha);
		out.writeUTF(this.tipoOperacao);
		out.writeUTF(this.numeroTelefone);
		out.writeLong(this.dataInicioJanela.getTime());
		out.writeLong(this.dataEfetivacaoTim.getTime());
		out.writeUTF(this.spid);
		out.writeUTF(this.eot);
		out.writeUTF(this.codigoRn1);
		out.writeUTF(this.codigoCnl);
		out.writeUTF(this.nomeArquivo);
		out.writeUTF(this.tipoArquivo);
		out.writeUTF(this.tsArquivo);
		out.writeUTF(this.seqArquivo);
		out.writeUTF(this.tsIngestao);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.numeroSequenciaLinha = in.readUTF();
		this.tipoOperacao = in.readUTF();
		this.numeroTelefone = in.readUTF();
		this.dataInicioJanela.setTime(in.readLong());
		this.dataEfetivacaoTim.setTime(in.readLong());
		this.spid  = in.readUTF();
		this.eot  = in.readUTF();
		this.codigoRn1 = in.readUTF();
		this.codigoCnl = in.readUTF();
		this.nomeArquivo = in.readUTF();
		this.tipoArquivo = in.readUTF();
		this.tsArquivo = in.readUTF();
		this.seqArquivo = in.readUTF();
		this.tsIngestao = in.readUTF();
	}

	public String getNumeroSequenciaLinha() {
		return numeroSequenciaLinha;
	}

	public String getTipoOperacao() {
		return tipoOperacao;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public Date getDataInicioJanela() {
		return dataInicioJanela;
	}

	public Date getDataEfetivacaoTim() {
		return dataEfetivacaoTim;
	}

	public String getSpid() {
		return spid;
	}

	public String getEot() {
		return eot;
	}

	public String getCodigoRn1() {
		return codigoRn1;
	}

	public String getCodigoCnl() {
		return codigoCnl;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public String getTipoArquivo() {
		return tipoArquivo;
	}

	public String getTsArquivo() {
		return tsArquivo;
	}

	public String getSeqArquivo() {
		return seqArquivo;
	}

	public String getTsIngestao() {
		return tsIngestao;
	}
	
}