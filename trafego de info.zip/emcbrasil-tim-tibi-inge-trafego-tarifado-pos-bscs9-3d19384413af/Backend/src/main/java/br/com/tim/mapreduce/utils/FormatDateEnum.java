package br.com.tim.utils;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public enum FormatDateEnum {

    YYYYMM("yyyyMM"),
    YYYY_MM("yyyy-MM"),
    YYYYMMDD("yyyyMMdd"),
    YYYY_MM_DD("yyyy-MM-dd"),
    YYMMDD("yyMMdd"),
    YYMMDDHHMMSS("yyMMddHHmmss"),
    YYYYMMDDHHMMSS("yyyyMMddHHmmss"),
    YYYY_MM_DD_HH2pMM2pSS("yyyy-MM-dd HH:mm:ss"),
    DDMMYY("ddMMyy");

    private DateTimeFormatter dateFormat;
    private String text;

    private FormatDateEnum(String text){
        this.text = text;
        this.dateFormat = DateTimeFormat.forPattern(text);
    }

    public DateTimeFormatter getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(DateTimeFormatter dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
