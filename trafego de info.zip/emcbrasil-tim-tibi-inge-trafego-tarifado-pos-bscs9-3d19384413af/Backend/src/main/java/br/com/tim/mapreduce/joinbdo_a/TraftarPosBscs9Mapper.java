package br.com.tim.mapreduce.joinbdo_a;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAValue;
import br.com.tim.mapreduce.model.TraftarPosBscs9;

public class TraftarPosBscs9Mapper<T> extends Mapper<T, Text, TraftarPosBscs9JoinBdoAKey, TraftarPosBscs9JoinBdoAValue>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9Mapper.class);
	
	private TraftarPosBscs9JoinBdoAKey outKey;
	private TraftarPosBscs9JoinBdoAValue outValue;
	
	private TraftarPosBscs9 traftar;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outKey = new TraftarPosBscs9JoinBdoAKey();
		this.outValue = new TraftarPosBscs9JoinBdoAValue();
		
		this.traftar = new TraftarPosBscs9();
		
	}
	
	@Override
	protected void map(T key, Text value, Context context) throws IOException, InterruptedException {
		
		this.outKey.clean();
		this.traftar.clean();
		
		String line = value.toString();
		
		if ( StringUtils.isBlank(line) ) return;
		
		this.traftar.setFromText(line);
		
		this.outKey.set(this.traftar);
		this.outValue.set(this.traftar);
		
		context.getCounter("MAPPER", "TRAFTAR WRITTEN").increment(1L);
		context.write(this.outKey, this.outValue);
		
	}
	
}
