package br.com.tim.inge.trafegotarifado.model;

import java.io.DataInput;

import java.io.DataOutput;

import java.io.IOException;

import java.text.ParseException;

import java.util.Date;

import org.apache.hadoop.io.Writable;

/**
 * 
 * Utilizar classe br.com.tim.mapreduce.model.TraftarPosBscs9
 *
 */
@Deprecated
public interface TraftarBscs extends Writable {

	@Override

	public void readFields(DataInput arg0) throws IOException;

	@Override

	public void write(DataOutput arg0) throws IOException;

	public String getSPNumberAddress();

	public String getSPLocationAddress();

	public String getOPNormedNumAddress();

	public String getOPNumberAddress();

	public String getNetElementAddress();

	public String getNumFollowUpCallType();

	public String getNumTariffInfoSncode();

	public String getNumTariffInfoZncode();

	public String getNumTechnInfoLngDistCarrierCd();

	public String getLdcInfoCarrierCode();

	public String getNumTariffInfoTmcode();

	public String getNumCustInfoContractId();

	public String getNumFreeUnitsInfoFuPackId();

	public String getSPLocationAreaCode();

	/**
	 * 
	 * 
	 * Partição da Tráfego Tarifado Pós.
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @return Data da partição
	 * 
	 * 
	 * @throws ParseException
	 * 
	 * 
	 */

	public Date getTrafTarDate() throws ParseException;

	public String serialize();

}