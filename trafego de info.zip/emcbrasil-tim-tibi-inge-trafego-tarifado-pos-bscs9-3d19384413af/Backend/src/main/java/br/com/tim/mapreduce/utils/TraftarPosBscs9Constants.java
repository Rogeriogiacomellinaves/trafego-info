package br.com.tim.mapreduce.utils;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.SimpleDateFormat;

public class TraftarPosBscs9Constants {

	public static final SimpleDateFormat SDF_yyyy_MM_dd = new SimpleDateFormat("yyyy-MM-dd");
	public static final SimpleDateFormat SDF_yyyy_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static final String TRAFTAR_POS_BSCS9 = "TRAFTAR_POS_BSCS9";
	public static final String TRAFTAR_POS_BSCS9_DIRECTORY = "TRAFTAR_POS_BSCS9_DIRECTORY";
	public static final String BDO = "BDO";
	public static final String BASE_CANDIDATA_PRE_POS = "BASE_CANDIDATA_PRE_POS";

	public static final String BDO_FACT_PARTITION = "bdo-fact-partition";
	public static final String BASE_CANDIDATA_PRE_POS_PARTITION = "base-candidata-fact-partition";

	public static final String TRAFTAR_POS_BSCS9_FACT_INPUT = "traftar-pos-bscs9-fact-input";
	public static final String CEC_CICLO_FATURAMENTO_INPUT = "cec-ciclo-faturamento-input";
	public static final String TRAFTAR_POS_BSCS9_FACT_PARTITION = "traftar-pos-bscs9-fact-partition";
	public static final String TRAFTAR_POS_BSCS9_DIRECTORY_INPUT = "traftar-pos-bscs9-directory-input";
	public static final String TRAFTAR_POS_BSCS9_DIRECTORY_DELETE = "traftar-pos-bscs9-directory-delete";
	public static final String TRAFTAR_POS_BSCS9_FACT_QTD_DIAS = "traftar-pos-bscs9-fact-qtd-dias";
	public static final String BDO_FACT_INPUT = "bdo-fact-input";
	public static final String BASE_CANDIDATA_PRE_POS_FACT_INPUT = "base-candidata-fact-input";

	public static final String TRAFTAR_POS_BSCS9_OUTPUT = "traftar-pos-bscs9-output";
	public static final String TRAFTAR_POS_BSCS9_HIVE_INPUT = "traftar-pos-bscs9-hive-input";
	public static final String TRAFTAR_POS_BSCS9_GPDB_INPUT = "traftar-pos-bscs9-gpdb-input";

	public static final String CADUP_DIR = "cadup-dir";
	public static final String EOT_PRESTADORA_DIR = "eot-prestadora-dir";
	public static final String PLANO_TARIFARIO_DIR = "plano-tarifario-dir";
	public static final String PACOTE_DIR = "dw-d-pacote-dir";
	public static final String APLICACOES_VAS_DIR = "aplicacoes-vas-dir";
	public static final String TIPO_CLIENTE_DIR = "tipo-cliente-dir";
	public static final String PATH_CN_ESTADO = "path-cn-estado";

	public static final String BASECAN_REF_DATE = "basecan-ref-date";
	
	public static final String DAT_REF = "dat_ref";
	public static final String YYYYMMDD = "yyyyMMdd";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String YYMMDD = "yyMMdd";
	public static final String YYYYMMDDHHmmss = "yyyyMMddhhmmss";

	public static final String VALUE_TYPE_BSCS9 = "BSCS";
	public static final String VALUE_TYPE_BSCS_ENRICHED = "BSCS_ENRICHED";
	public static final String VALUE_TYPE_BDO = "BDO";
	public static final String VALUE_TYPE_BASE_CANDIDATA = "BASE_CANDIDATA";

	public static final String COD_PLANO_TARIFARIO_POS_OLTP = "codPlanoTarifarioPosOltp";
	public static final String SKY_PACOTE = "skyPacote";

	public static final String TRAFTAR_BASECANDIDATA_PROCESS_ID = "traftar-basecandidata-process-id";
	public static final String BDO_END_JOB_PROCESS_ID = "traftar-bdo-process-id";

	public static final String JOB_INITIAL_DATE = "job-initial-date";

	public static final String CN = "cn";
	public static final String NUMERO_APP_VAS = "numero";

	public static final String DRIVER_TIMESTAMP = "process-timestamp";

	public static final String TRAFTAR_POS_BSCS9_COPY_GPDB_INPUT_DIST_CP = "traftar-pos-bscs9-gpdb-input-copy-distcp";

	public static final String TRAFTAR_POS_BSCS9_CONTROL_FILE_DROP_PARTITION = "control-file-drop-partition";

	public static final String AUXILIARY_CENTRAIS_VOLTE_PATH = "auxiliary-centrais-volte-path";
	
	public static final String IS_REPROCESS = "job-is-reprocess";

	public static final String INCOMING_PATH = "incoming-path";
	public static final String FULL_PEAK_OFF_PEAK_FILE_NAME_INPUT =
			"full-peak-off-peak-file-name-input";

	public static final String NORMAL = "Normal";
	public static final String DIA = "Dia";
	public static final String NOITE = "Noite";
	public static final String DIA_2 = "Dia 2";
	public static final String GPRSDIA = "GPRSDia";
	public static final String GPRSNOITE = "GPRSNoite";
	public static final String REDUZIDO = "Reduzido";
	public static final String TODO = "Todo";
	public static final String FSDIA = "FSDia";
	public static final String FSNOITE = "FSNoite";
	public static final String NOITE_2 = "Noite 2";
	public static final String FIM_DE_SEMANA = "fim de semana";
	public static final String PE = "PE";
	public static final String OP = "OP";
	public static final String PORTO_CONECTA = "PORTO CONECTA";

	public static final DateTimeFormatter FORMAT_YYYYMMDD = DateTimeFormat.forPattern("yyyyMMdd");
	public static final String PARAM_DATA_REF_PARTICAO = "PARAM_DATA_REF_PARTICAO";
	public static final String PARAM_DATA_ARQUIVO_YYYYMMDD = "{PARAM_DATA_ARQUIVO_YYYYMMDD}";
}