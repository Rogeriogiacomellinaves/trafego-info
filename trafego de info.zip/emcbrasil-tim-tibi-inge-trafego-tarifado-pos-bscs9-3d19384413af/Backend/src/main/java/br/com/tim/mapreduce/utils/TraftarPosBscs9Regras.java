package br.com.tim.mapreduce.utils;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import br.com.tim.mapreduce.finders.*;
import br.com.tim.mapreduce.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.google.common.base.Strings;

import br.com.tim.mapreduce.joinbasecan.model.BaseCandidataPrePosValue;
import br.com.tim.model.CNEstado;
import br.com.tim.model.Cadup;
import br.com.tim.model.Pacote;
import br.com.tim.model.PlanoTarifario;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.CommonsUtils;

/**
 * @author dacosa1
 */
public class TraftarPosBscs9Regras {

    /**
     * Apply the rules
     *
     * @param traftar
     * @return
     */
    public static TraftarPosBscs9 enrichTrafTar(TraftarPosBscs9 traftar,
                                                BaseCandidataPrePosValue baseCan,
                                                AplicacoesVasFinder aplicacoesVasFinder,
                                                CentralVolteFinder centralVolteFinder,
                                                PacoteFinder pacoteFinder,
                                                CNEstadoFinder cnEstadoFinder,
                                                PlanoTarifarioFinder planoTarifarioFinder,
                                                TipoClienteFinder tipoClienteFinder,
                                                boolean isRep
    ) {

        traftar.setTipoServico(getTipoServico(traftar, aplicacoesVasFinder, centralVolteFinder));
        traftar.setDddOrigemChamada(getDddOrigemChamada(traftar));

        if (StringUtils.isNotBlank(baseCan.getCodContratoOltp())) {
            traftar.setPacote(getPacote(baseCan, pacoteFinder));
            traftar.setCicloFaturamento(getCicloFaturamento(baseCan));
            if (isTipoTrafegoDados(traftar))
                traftar.setSPNumberAddress(baseCan.getNumTelefone());
        }

        traftar.setDddTelefonePagador(getDddTelefonePagador(traftar));

        traftar.setTipoCobranca(getTipoCobranca(traftar));
        traftar.setFlagRoamimg(getFlagRoaming(traftar));
        traftar.setCsp(getCSP(traftar));
        traftar.setInboundOutbound(getInboundOutbound(traftar));
        traftar.setDescricaoPlanoTarifario(getDescricaoPlanoTarifario(traftar, planoTarifarioFinder));
        traftar.setSegmentoCliente(getSegmentoCliente());
        traftar.setTipoCliente(getTipoCliente(traftar, planoTarifarioFinder));
        traftar.setExtrabundle(getExtraBundle(traftar));
        traftar.setUfTelefonePagador(getUfTelefonePagador(traftar, cnEstadoFinder));
        traftar.setUFOrigemChamada(getUfOrigemChamada(traftar, cnEstadoFinder));

        traftar.setIndicadorClienteMigrado(getIndicadorClienteMigrado(baseCan));
        traftar.setDataCorteFatura(baseCan.getDescricaoDataCorteFatura());
        traftar.setFornecedor(getFornecedor(aplicacoesVasFinder, traftar));
        traftar.setSegmentoMarketing(getSegmentoMarketing(tipoClienteFinder,baseCan));

        return traftar;
    }

    public static TraftarPosBscs9 enrichTrafTarA(TraftarPosBscs9 traftar,
                                                 List<Bdo> bdos,
                                                 Map<String, List<EOTPrestadora>> eotMap,
                                                 Map<String, List<Cadup>> cadupMap,
                                                 CNEstadoFinder cnEstadoFinder,
                                                 AplicacoesVasFinder aplicacoesVasFinder) {
        try {
            traftar.setTipoOrigemChamada(getTipoOrigemChamada(traftar, bdos, eotMap, cadupMap));
            traftar.setOperadoraAOrigem(getOperadoraAOrigem(traftar, bdos, eotMap, cadupMap, cnEstadoFinder));
        } catch (ParseException e) {
        }

        traftar.setTipoTrafego(getTipoTrafego(traftar, aplicacoesVasFinder));
        traftar.setGrupoTrafego(getGrupoTrafego(traftar));
        traftar.setDirecaoTrafego(getDirecaoTrafego(traftar));

        traftar.setFlagPortabilidade(getFlagPortabilidade(bdos));
        traftar.setIndicadorClienteAtivoConecta(getIndicadorClienteAtivoConecta(traftar));

        return traftar;
    }

    public static TraftarPosBscs9 enrichTrafTarB(TraftarPosBscs9 traftar,
                                                 List<Bdo> bdos,
                                                 Map<String, List<EOTPrestadora>> eotMap,
                                                 Map<String, List<Cadup>> cadupMap) {
        traftar.setDddNumeroB(getDddNumeroB(traftar));
        traftar.setNumeroBNormalizado(getNumeroBNormalizado(traftar));

        try {
            traftar.setTipoDestinoChamada(getTipoDestinoChamada(traftar, bdos, eotMap, cadupMap));
            traftar.setOperadoraBDestino(getOperadoraBDestino(traftar, bdos, eotMap, cadupMap));
        } catch (ParseException e) {
        }

        traftar.setTipoRedeChamada(getTipoRedeChamada(traftar));

        return traftar;
    }

    /**
     * Inicio regras
     */

    public static String getDddNumeroB(TraftarPosBscs9 enrichFields) {

        String tpoTrafego = enrichFields.getTipoTrafego();
        String grupoTrafego = enrichFields.getGrupoTrafego();
        String tpoServico = enrichFields.getTipoServico();

        if (CommonsUtils.equalsIn(tpoTrafego, CAIXA_POSTAL, AD, VCI, TIM_CONNECT_WAP))
            return CommonsConstants.EMPTY;

        if (CommonsUtils.equalsIn(tpoServico, PROVIDER))
            return CommonsConstants.EMPTY;

        if (CommonsUtils.equalsIn(grupoTrafego, NUM_NAO_GEOGRAFICO, VAS)
                && !CommonsUtils.equalsIn(tpoTrafego, VIDEO_CHAMADA, VOZ, SMS))
            return CommonsConstants.EMPTY;

        return getDddNumeroBQtdNumeros(enrichFields);
    }

    public static String getDddNumeroBQtdNumeros(TraftarPosBscs9 enrichFields) {
        String opNormedNumAddress = enrichFields.getOPNormedNumAddress();
        if (!Strings.isNullOrEmpty(opNormedNumAddress)) {
            if (_17_18.contains(opNormedNumAddress.length()) || _14 == opNormedNumAddress.length()) {
                return opNormedNumAddress.substring(4, 6);
            } else if (_12_13.contains(opNormedNumAddress.length())) {
                return opNormedNumAddress.substring(2, 4);
            } else if (_20 == opNormedNumAddress.length() || (_19 == opNormedNumAddress.length() && _1.equals(enrichFields.getTariffInfoSncode()))) {
                return opNormedNumAddress.substring(9, 11);
            }
        }
        return StringUtils.EMPTY;
    }

    // RN003
    public static String getNumeroBNormalizado(TraftarPosBscs9 enrichFields) {

        String tpoTrafego = enrichFields.getTipoTrafego();
        String grupoTrafego = enrichFields.getGrupoTrafego();
        String tpoServico = enrichFields.getTipoServico();

        if (CommonsUtils.equalsIn(tpoTrafego, CAIXA_POSTAL, AD, VCI, TIM_CONNECT_WAP))
            return CommonsConstants.EMPTY;

        if (CommonsUtils.equalsIn(tpoTrafego, URA)
                || CommonsUtils.equalsIn(tpoServico, PROVIDER))
            return enrichFields.getOPNumberAddress();

        if (CommonsUtils.equalsIn(grupoTrafego, NUM_NAO_GEOGRAFICO, VAS)
                && !CommonsUtils.equalsIn(tpoTrafego, VIDEO_CHAMADA, VOZ, SMS))
            return CommonsConstants.EMPTY;

        return getNumeroBNormalizadoQtdDigitos(enrichFields);
    }

    public static String getNumeroBNormalizadoQtdDigitos(TraftarPosBscs9 enrichFields) {
        String opNormedNumAddress = enrichFields.getOPNormedNumAddress();
        String numTariffInfoSncode = enrichFields.getTariffInfoSncode();
        if (!Strings.isNullOrEmpty(opNormedNumAddress)) {
            if (_17_18.contains(opNormedNumAddress.length())) {
                return opNormedNumAddress.substring(4, 6) + opNormedNumAddress.substring(9);
            } else if (_12_13.contains(opNormedNumAddress.length())) {
                return opNormedNumAddress.substring(2);
            } else if (_20 == opNormedNumAddress.length() || (_19 == opNormedNumAddress.length() && _1.equals(numTariffInfoSncode))) {
                return opNormedNumAddress.substring(9);
            } else if (_14 == opNormedNumAddress.length()) {
                return opNormedNumAddress.substring(4);
            }
        }
        return opNormedNumAddress;
    }

    public static String getTipoServico(TraftarPosBscs9 enrichFields, AplicacoesVasFinder aplicacoesVasFinder, CentralVolteFinder centralVolteFinder) {
        if (enrichFields.getNetElementAddress() != null) {
            if (centralVolteFinder.find(enrichFields.getNetElementAddress())) {
                return VOLTE;
            }
        }


        if (enrichFields.getTariffInfoSncode() != null) {
            String snCode = enrichFields.getTariffInfoSncode();
            if (tiposServicoVoz.contains(snCode)) {
                return VOZ;
            }
            if (dadosSnCodes.contains(snCode)) {
                return DADOS;
            }
            if (CommonsUtils.equalsIn(snCode, _2, _2983, _2955, _3337, _3348)) {
                String grupoVas = findIfAplicacoesVas(aplicacoesVasFinder, enrichFields);
                if (StringUtils.isNotBlank(grupoVas)) {
                    return PROVIDER;
                }
            }
            if (CommonsUtils.equalsIn(snCode, _2, _3, _10030, _10031)) {
                return SMS;
            }
            if (snCode.equals(_202)) {
                return MMS;
            }
        }

        return "";
    }

    // RN001 campo 254
    public static String getDddTelefonePagador(TraftarPosBscs9 enrichFields) {
        String numTelefonePagador = getNumTelefonePagador(enrichFields);
        if (StringUtils.isBlank(numTelefonePagador)) return CommonsConstants.EMPTY;
        return numTelefonePagador.substring(0, 2);
    }

    // RN002 campo 256
    public static String getDddOrigemChamada(TraftarPosBscs9 enrichFields) {
        if (!Strings.isNullOrEmpty(enrichFields.getSPLocationAddress()) && enrichFields.getSPLocationAddress().length() > 6 && _724.equals(enrichFields.getSPLocationAddress().substring(0, 3))) {
            return enrichFields.getSPLocationAddress().substring(5, 7);
        }
        return StringUtils.EMPTY;
    }

    public static String getDddNumeroBQtdCaracteres(TraftarPosBscs9 enrichFields) {
        String opNormedNumAddress = enrichFields.getOPNormedNumAddress();

        if (!Strings.isNullOrEmpty(opNormedNumAddress)) {
            if (_17_18.contains(opNormedNumAddress.length()) || _15 == opNormedNumAddress.length() || opNormedNumAddress.length() == 14) {
                return opNormedNumAddress.substring(4, 6);
            }

            if (_12_13.contains(opNormedNumAddress.length())) {
                return opNormedNumAddress.substring(2, 4);
            }
        }
        return StringUtils.EMPTY;
    }

    public static boolean isTipoServicoProvider(TraftarPosBscs9 enrichFields) {
        return PROVIDER.equalsIgnoreCase(enrichFields.getTipoServico());
    }

    public static boolean isNumNaoGeografico(TraftarPosBscs9 enrichFields) {
        return isTipoTrafego0300(enrichFields) || isTipoTrafego0500(enrichFields) || isTipoTrafego0800(enrichFields) || isTipoTrafegoNumEspecial(enrichFields)
                || isTipoTrafegoNumNaoRegional(enrichFields);
    }

    // regra RN004 campo 259
    public static String getTipoTrafego(TraftarPosBscs9 enrichFields, AplicacoesVasFinder aplicacoesVasFinder) {

        if (isTipoTrafegoDados(enrichFields)) {
            return DADOS;
        }

        if (isTipoTrafegoVideoChamada(enrichFields)) {
            return VIDEO_CHAMADA;
        }

        if (isTipoTrafegoTimConnectWap(enrichFields)) {
            return TIM_CONNECT_WAP;
        }

        if (PROVIDER.equals(enrichFields.getTipoServico())) {
            String grupoAplicacoesVas = findIfAplicacoesVas(aplicacoesVasFinder, enrichFields);
            if (!Strings.isNullOrEmpty(grupoAplicacoesVas)) {
                return grupoAplicacoesVas;
            }
        }

        if (isTipoTrafegoDSL1(enrichFields)) {
            return DSL1;
        }

        if (isTipoTrafegoDSL2(enrichFields)) {
            return DSL2;
        }

        if (isTipoTrafegoDSLI(enrichFields)) {
            return DSLI;
        }

        if (isTipoTrafegoSMS(enrichFields)) {
            return SMS;
        }

        if (isTipoTrafegoMMS(enrichFields)) {
            return MMS;
        }

        if (isTipoTrafegoVCI(enrichFields)) {
            return VCI;
        }

        if (isTipoTrafegoCaixaPostal(enrichFields)) {
            return CAIXA_POSTAL;
        }

        if (isTipoTrafegoVCN_NR(enrichFields)) {
            return VCN_NR;
        }

        if (isTipoTrafegoVC1(enrichFields)) {
            return VC1;
        }

        if (isTipoTrafegoVC2(enrichFields)) {
            return VC2;
        }

        if (isTipoTrafegoVC3(enrichFields)) {
            return VC3;
        }

        if (isTipoTrafegoLD1(enrichFields)) {
            return LD1;
        }

        if (isTipoTrafegoLD2(enrichFields)) {
            return LD2;
        }

        if (isTipoTrafegoLD3(enrichFields)) {
            return LD3;
        }

        if (isTipoTrafegoLDI(enrichFields)) {
            return LDI;
        }

        if (isTipoTrafego0300(enrichFields)) {
            return _0300;
        }

        if (isTipoTrafego0500(enrichFields)) {
            return _0500;
        }

        if (isTipoTrafego0800(enrichFields)) {
            return _0800;
        }

        if (isTipoTrafegoAD(enrichFields)) {
            return AD;
        }

        if (isTipoTrafegoNumEspecial(enrichFields)) {
            return NUM_ESPECIAL;
        }

        if (isTipoTrafegoNumNaoRegional(enrichFields)) {
            return NUM_NAO_REGINAL;
        }

        if (isTipoTrafegoCallCenter(enrichFields)) {
            return CALL_CENTER;
        }

        if (isTipoTrafegoURA(enrichFields)) {
            return URA;
        }

        return enrichFields.getTipoServico();
    }

    public static String findIfAplicacoesVas(AplicacoesVasFinder aplicacoesVasFinder, TraftarPosBscs9 enrichFields) {
        String oPNumberAddress = enrichFields.getOPNumberAddress();
        String numTechInfoLngDistCarrierCd = enrichFields.getTechnInfoLngDistCarrierCd();

        AplicacoesVas appVas = null;

        appVas = aplicacoesVasFinder.find(oPNumberAddress, numTechInfoLngDistCarrierCd);

        if (null == appVas) return CommonsConstants.EMPTY;

        return appVas.getDscGrupoContractId();

    }

    public static boolean isTipoTrafegoDados(TraftarPosBscs9 enrichFields) {
        return _157.equals(enrichFields.getTariffInfoSncode());
    }

    public static boolean isTipoTrafegoTimConnectWap(TraftarPosBscs9 enrichFields) {
        return _5.equals(enrichFields.getTariffInfoSncode());
    }

    public static boolean isTipoTrafegoVideoChamada(TraftarPosBscs9 enrichFields) {
        return _675.equals(enrichFields.getTariffInfoSncode());
    }

    public static boolean isTipoTrafegoSMS(TraftarPosBscs9 enrichFields) {
        return CommonsUtils.equalsIn(enrichFields.getTariffInfoSncode(),
                _2, _3, _10030, _10031);
    }

    public static boolean isTipoTrafegoMMS(TraftarPosBscs9 enrichFields) {
        return _202.equals(enrichFields.getTariffInfoSncode());
    }

    public static boolean isTipoTrafegoAD(TraftarPosBscs9 enrichFields) {
        return enrichFields.getTariffInfoSncode().equals(_22);
    }

    public static boolean isTipoTrafegoNumEspecial(TraftarPosBscs9 enrichFields) {
        return enrichFields.getOPNumberAddress().length() == 3;
    }

    public static boolean isTipoTrafegoNumNaoRegional(TraftarPosBscs9 enrichFields) {
        return (enrichFields.getOPNumberAddress().length() > 3 && grupoNumNaoRegional.contains(enrichFields.getOPNumberAddress().substring(0, 4)))
                || (enrichFields.getOPNumberAddress().length() > 5 && CommonsUtils.equalsIn(enrichFields.getOPNumberAddress().substring(0, 6), grupoNumNaoRegional2));
    }

    public static boolean isTipoTrafego0300(TraftarPosBscs9 enrichFields) {
        return enrichFields.getOPNumberAddress().startsWith(_0300) || enrichFields.getOPNumberAddress().startsWith(_550300);
    }

    public static boolean isTipoTrafego0500(TraftarPosBscs9 enrichFields) {
        return enrichFields.getOPNumberAddress().startsWith(_0500) && (enrichFields.getTariffInfoZncode().equals(_1260) || enrichFields.getTariffInfoZncode().equals(_2830));
    }

    public static boolean isTipoTrafego0800(TraftarPosBscs9 enrichFields) {
        return enrichFields.getOPNumberAddress().startsWith(_00800);
    }

    public static boolean isTipoTrafegoCaixaPostal(TraftarPosBscs9 enrichFields) {
        String numB = getNumeroBNormalizadoQtdDigitos(enrichFields);
        return enrichFields.getOPNormedNumAddress().equals(_55009999999991100) || enrichFields.getOPNormedNumAddress().equals(_55009999999991111)
                || (enrichFields.getSPNumberAddress().equalsIgnoreCase(numB) && !sncodesNotCaixaPostal.contains(enrichFields.getTariffInfoSncode()))
                || _AST_100.equals(enrichFields.getOPNumberAddress());
    }

    public static boolean isTipoTrafegoVCN_NR(TraftarPosBscs9 enrichFields) {
        int znCode = Integer.parseInt(enrichFields.getTariffInfoZncode());
        return (znCode >= 8192 && znCode <= 8248);
    }

    public static boolean isTipoTrafegoCallCenter(TraftarPosBscs9 enrichFields) {
        return callCenterNumbers.contains(enrichFields.getOPNumberAddress());
    }

    public static boolean isTipoTrafegoURA(TraftarPosBscs9 enrichFields) {
        return enrichFields.getOPNumberAddress().length() > 0 && ASTERISCO.equals(enrichFields.getOPNumberAddress().substring(0, 1));
    }

    public static boolean isTipoTrafegoDSLI(TraftarPosBscs9 enrichFields) {
        return enrichFields.getSPLocationAddress().length() > 2 && enrichFields.getTariffInfoSncode().equals(_62) && !enrichFields.getSPLocationAddress().substring(0, 3).equals(_724);
    }

    public static boolean isTipoTrafegoDSL1(TraftarPosBscs9 enrichFields) {
        String dddNumB = getDddNumeroBQtdNumeros(enrichFields);
        return !StringUtils.isEmpty(dddNumB) && dddNumB.length() > 1 && !StringUtils.isEmpty(enrichFields.getDddOrigemChamada())
                && enrichFields.getDddOrigemChamada().length() > 1 && enrichFields.getTariffInfoSncode().equals(_62)
                && enrichFields.getDddOrigemChamada().substring(0, 1).equals(dddNumB.substring(0, 1))
                && !enrichFields.getDddOrigemChamada().substring(1, 2).equals(dddNumB.substring(1, 2));
    }

    public static boolean isTipoTrafegoDSL2(TraftarPosBscs9 enrichFields) {
        String dddNumB = getDddNumeroBQtdNumeros(enrichFields);
        return !StringUtils.isEmpty(dddNumB) && !StringUtils.isEmpty(enrichFields.getDddOrigemChamada()) && enrichFields.getTariffInfoSncode().equals(_62)
                && !enrichFields.getDddOrigemChamada().substring(0, 1).equals(dddNumB.substring(0, 1));
    }

    public static boolean isNotLocationAddress09(TraftarPosBscs9 enrichFields) {
        return enrichFields.getSPLocationAddress().length() > 8 ? !enrichFields.getSPLocationAddress().substring(7, 9).equals(_09) : true;
    }

    //VC/LD1 - VC/LD2 - VC/LD3 - VC/LCI
    public static boolean checkVcLd1Rule(TraftarPosBscs9 enrichFields) {
        String dddNumB = getDddNumeroBQtdNumeros(enrichFields);
        return ((StringUtils.isNotBlank(dddNumB)
                && StringUtils.isNotBlank(enrichFields.getDddOrigemChamada())
                && enrichFields.getDddOrigemChamada().equals(dddNumB)
                && enrichFields.getSPLocationAddress().length() >= 5
                && CommonsUtils.equalsIn(enrichFields.getSPLocationAddress().substring(0, 5), _72402, _72403, _72404, _72499, _72441))
                || (enrichFields.getSPLocationAddress().length() >= 8
                && enrichFields.getSPLocationAddress().substring(0, 3).equals(_724)
                && enrichFields.getSPLocationAddress().substring(7, 8).equals(_6))
                || (enrichFields.getSPLocationAddress().length() >= 9
                && enrichFields.getSPLocationAddress().substring(0, 3).equals(_724)
                && enrichFields.getSPLocationAddress().substring(7, 9).equals(_08)));
    }

    public static boolean checkVcLd2Rule(TraftarPosBscs9 enrichFields) {
        String dddNumB = getDddNumeroBQtdNumeros(enrichFields);
        return (!StringUtils.isEmpty(dddNumB) && !StringUtils.isEmpty(enrichFields.getDddOrigemChamada()) && enrichFields.getDddOrigemChamada().length() > 1
                && enrichFields.getDddOrigemChamada().substring(0, 1).equals(dddNumB.substring(0, 1))
                && !enrichFields.getDddOrigemChamada().substring(1, 2).equals(dddNumB.substring(1, 2)))
                || (enrichFields.getSPLocationAddress().length() > 8
                && enrichFields.getSPLocationAddress().substring(7, 9).equals(_09)
                && enrichFields.getSPLocationAddress().substring(0, 3).equals(_724));
    }

    public static boolean checkVcLd3Rule(TraftarPosBscs9 enrichFields) {
        String dddNumB = getDddNumeroBQtdNumeros(enrichFields);
        return enrichFields.getSPLocationAddress().length() > 2 && !StringUtils.isEmpty(dddNumB) && !StringUtils.isEmpty(enrichFields.getDddOrigemChamada())
                && !enrichFields.getDddOrigemChamada().substring(0, 1).equals(dddNumB.substring(0, 1)) && enrichFields.getSPLocationAddress().substring(0, 3).equals(_724);
    }

    public static boolean checkVcLdIRule(TraftarPosBscs9 enrichFields) {
        return enrichFields.getOPNormedNumAddress().length() > 1 && !enrichFields.getOPNormedNumAddress().substring(0, 2).equals(_55);
    }
    //VC/LD1 - VC/LD2 - VC/LD3 - VC/LCI

    public static boolean isTipoTrafegoVC1(TraftarPosBscs9 enrichFields) {
        return !FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLd1Rule(enrichFields);
    }

    public static boolean isTipoTrafegoVC2(TraftarPosBscs9 enrichFields) {
        return !FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLd2Rule(enrichFields);
    }

    public static boolean isTipoTrafegoVC3(TraftarPosBscs9 enrichFields) {
        return !FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLd3Rule(enrichFields);
    }

    public static boolean isTipoTrafegoVCI(TraftarPosBscs9 enrichFields) {
        return !FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLdIRule(enrichFields);
    }

    public static boolean isTipoTrafegoLD1(TraftarPosBscs9 enrichFields) {
        return FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLd1Rule(enrichFields);
    }

    public static boolean isTipoTrafegoLD2(TraftarPosBscs9 enrichFields) {
        return FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLd2Rule(enrichFields);
    }

    public static boolean isTipoTrafegoLD3(TraftarPosBscs9 enrichFields) {
        return FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLd3Rule(enrichFields);
    }

    public static boolean isTipoTrafegoLDI(TraftarPosBscs9 enrichFields) {
        return FIXO_TIM.equals(enrichFields.getTipoOrigemChamada())
                && checkVcLdIRule(enrichFields);
    }

    // regra RN005 campo 260
    public static String getTipoCobranca(TraftarPosBscs9 enrichFields) {
        if (SMS.equalsIgnoreCase(enrichFields.getTipoServico()) || MMS.equalsIgnoreCase(enrichFields.getTipoServico()) || DADOS.equalsIgnoreCase(enrichFields.getTipoServico())
                || PROVIDER.equalsIgnoreCase(enrichFields.getTipoServico())) {
            return NORMAL;
        }

        if (_2.equals(enrichFields.getFollowUpCallType())) {
            return A_COBRAR;
        }

        return NORMAL;
    }

    // regra RN006 campo 261
    public static String getGrupoTrafego(TraftarPosBscs9 enrichFields) {
        String tipoTrafego = enrichFields.getTipoTrafego();
        if (CommonsUtils.equalsIn(tipoTrafego, VC1, LD1)) {
            return LOCAL;
        }

        if (CommonsUtils.equalsIn(tipoTrafego, VC2, VC3, LD2, LD3)) {
            return LDN;
        }

        if (CommonsUtils.equalsIn(tipoTrafego, VCI, LDI)) {
            return LDI;
        }

        if (grupoTrafegoCobrancaAdicional.contains(tipoTrafego.toUpperCase())) {
            return COBRANCA_ADICIONAL;
        }

        if (grupoTrafegoNumNaoGeografico.contains(tipoTrafego.toUpperCase())) {
            return NUM_NAO_GEOGRAFICO;
        }

        if (tipoTrafego.equals(VOLTE))
            return VOLTE;

        return VAS;

    }


    /**
     * "CASE
     * WHEN Tipo Destino Chamada (RN009) IS NULL THEN NULL
     * WHEN Tipo Tráfego (RN004) IN (0300, 0500, 0800, Número não Regional, Número Especial, Caixa Postal, URA, PROVIDER, DADOS) THEN 'OTHER'
     * WHEN Tipo Serviço (RN012) = 'PROVIDER' THEN 'OTHER'
     * WHEN Tipo Origem Chamada (RN008) = Tipo Destino Chamada (RN009) THEN 'ONNET'
     * WHEN Tipo Origem Chamada (RN008) <> Tipo Destino Chamada (RN009) THEN 'OFFNET'
     * ELSE NULL"
     *
     * @param enrichFields
     * @return
     */
    public static String getTipoRedeChamada(TraftarPosBscs9 enrichFields) {
        String tipoOrigemChamada = enrichFields.getTipoOrigemChamada();
        String tipoDestinoChamada = enrichFields.getTipoDestinoChamada();
        String tipoTrafego = enrichFields.getTipoTrafego();
        String tipoServico = enrichFields.getTipoServico();

        if (CommonsUtils.equalsIn(tipoTrafego, _0300, _0500, _0800, NUM_NAO_REGINAL, NUM_ESPECIAL, CAIXA_POSTAL, URA, PROVIDER, DADOS, TIM_CONNECT_WAP))
            return OTHER;

        if (StringUtils.isBlank(tipoDestinoChamada))
            return CommonsConstants.EMPTY;

        if (CommonsUtils.equalsIn(NAO_IDENTIFICADO, tipoDestinoChamada, tipoOrigemChamada))
            return OTHER;

        if (CommonsUtils.equalsIn(tipoServico, PROVIDER))
            return OTHER;

        if (CommonsUtils.equalsIn(tipoOrigemChamada, MOVEL, FIXO))
            return OFFNET;

        if (CommonsUtils.equalsIn(tipoOrigemChamada, MOVEL_TIM, FIXO_TIM)
                && CommonsUtils.equalsIn(tipoDestinoChamada, MOVEL_TIM, FIXO_TIM))
            return ONNET;

        if (CommonsUtils.equalsIn(tipoOrigemChamada, MOVEL_TIM, FIXO_TIM)
                && CommonsUtils.equalsIn(tipoDestinoChamada, MOVEL, FIXO))
            return OFFNET;

        return CommonsConstants.EMPTY;
    }

    // regra RN009 campo 264
    public static String getTipoDestinoChamada(TraftarPosBscs9 enrichFields, List<Bdo> bdos, Map<String, List<EOTPrestadora>> eotMap, Map<String, List<Cadup>> cadupMap) throws ParseException {
        String tipoServico = enrichFields.getTipoServico();
        String opNormedNumAddress = enrichFields.getOPNormedNumAddress();
        String tpoTrafego = enrichFields.getTipoTrafego();

        if (NUM_NAO_GEOGRAFICO.equalsIgnoreCase(enrichFields.getGrupoTrafego())) {
            return NUMEROS_ESPECIAIS;
        }

        if (CommonsUtils.equalsIn(tpoTrafego, CAIXA_POSTAL, URA_SERVICOS)) {
            return NUMEROS_ESPECIAIS;
        }

        if (TIM_CONNECT_WAP.equals(tpoTrafego))
            return CommonsConstants.EMPTY;

        if (tipoServico.equalsIgnoreCase(PROVIDER)) {
            return PROVIDER;
        }

        if (tipoServico.equalsIgnoreCase(DADOS) && !CommonsUtils.equalsIn(tpoTrafego, VIDEO_CHAMADA)) {
            return enrichFields.getOPNumberAddress();
        }

//		if (_17_18.contains(opNormedNumAddress.length())) {
//			return getTipoDestinoFromLength(enrichFields);
//		}

        try {
            EOTPrestadora prestadoraFromBDO = EOTPrestadoraUtility.getEotPrestadoraFromBDO(bdos, eotMap, enrichFields.getTrafTarDate());
            if (prestadoraFromBDO != null) {
                return getTipoDestinoChamadaFromEot(prestadoraFromBDO);
            } else {
                // se não encontrar na BDO busca da CADUP
                String cadupKey = findCadupKeyFromNumNormalizado(enrichFields.getNumeroBNormalizado());

                int mcdu = Integer.valueOf(StringUtils.right(enrichFields.getNumeroBNormalizado(), 4));
                EOTPrestadora cadupEot = EOTPrestadoraUtility.getEotPrestadoraFromCadup(cadupMap, eotMap, cadupKey, mcdu, enrichFields.getTrafTarDate());

                return getTipoDestinoChamadaFromEot(cadupEot);
            }
        } catch (NumberFormatException e) {
            return NAO_IDENTIFICADO;
        }
    }

    public static String getNumTelefonePagador(TraftarPosBscs9 enrichFields) {
        String spNumberAddress = enrichFields.getSPNumberAddress();

        if (spNumberAddress.length() == 10 || spNumberAddress.length() == 11)
            return spNumberAddress;

        if (spNumberAddress.length() == 12) {
            if (_00.equals(spNumberAddress.substring(2, 4)))
                return spNumberAddress.substring(0, 2) + spNumberAddress.substring(4);
            if (_0.equals(spNumberAddress.substring(2, 3)))
                return spNumberAddress.substring(0, 2) + spNumberAddress.substring(3);
            if (!_0.equals(spNumberAddress.substring(2, 3)))
                return spNumberAddress.substring(2);
        }

        if (spNumberAddress.length() == 13)
            return spNumberAddress.substring(2);

        return CommonsConstants.EMPTY;
    }

    public static String getTipoOrigemChamada(TraftarPosBscs9 enrichFields, List<Bdo> bdos, Map<String, List<EOTPrestadora>> eotMap, Map<String, List<Cadup>> cadupMap) throws ParseException {
        String numTelefonePagador = getNumTelefonePagador(enrichFields);

        try {
            EOTPrestadora prestadoraFromBDO = EOTPrestadoraUtility.getEotPrestadoraFromBDO(bdos, eotMap, enrichFields.getTrafTarDate());
            if (prestadoraFromBDO != null) {
                return getTipoDestinoChamadaFromEot(prestadoraFromBDO);
            } else {
                // se não encontrar na BDO busca da CADUP
                String cadupKey = findCadupKeyFromNumNormalizado(numTelefonePagador);

                int mcdu = Integer.valueOf(StringUtils.right(numTelefonePagador, 4));
                EOTPrestadora cadupEot = EOTPrestadoraUtility.getEotPrestadoraFromCadup(cadupMap, eotMap, cadupKey, mcdu, enrichFields.getTrafTarDate());

                return getTipoDestinoChamadaFromEot(cadupEot);
            }
        } catch (NumberFormatException e) {
            return NAO_IDENTIFICADO;
        }

    }

//	REGRA REMOVIDA
//	public static String getTipoDestinoFromLength(TraftarPosBscs9 enrichFields) {
//		String opNormedNumAddress = enrichFields.getOPNormedNumAddress();
//
//		if (opNormedNumAddress.substring(6, 7).equals(_1) && opNormedNumAddress.substring(7, 9).equals(_99)) {
//			return FIXO;
//		}
//
//		if (opNormedNumAddress.substring(6, 7).equals(_3) && (opNormedNumAddress.substring(7, 9).equals(_99) || opNormedNumAddress.substring(7, 9).equals(_85))) {
//			return MOVEL;
//		}
//
//		if (opNormedNumAddress.substring(6, 7).equals(_1) && (opNormedNumAddress.substring(7, 9).equals(_41) || opNormedNumAddress.substring(7, 9).equals(_23))) {
//			return FIXO_TIM;
//		}
//
//		if (opNormedNumAddress.substring(6, 7).equals(_3) && opNormedNumAddress.substring(7, 9).equals(_41)) {
//			return MOVEL_TIM;
//		}
//
//		return NAO_IDENTIFICADO;
//	}

    public static String getTipoDestinoChamadaFromEot(EOTPrestadora eotPrestadora) {
        if (eotPrestadora != null) {
            if (SMP.equalsIgnoreCase(eotPrestadora.getTipoServico())) {
                if (eotPrestadora.getNomeFantasia().toUpperCase().startsWith(TIM)) {
                    return MOVEL_TIM;
                } else {
                    return MOVEL;
                }
            }

            if (STFC.equalsIgnoreCase(eotPrestadora.getTipoServico())) {
                if (eotPrestadora.getNomeFantasia().toUpperCase().startsWith(TIM)) {
                    return FIXO_TIM;
                } else {
                    return FIXO;
                }
            }

            if (SME.equalsIgnoreCase(eotPrestadora.getTipoServico()) || SMGS.equalsIgnoreCase(eotPrestadora.getTipoServico())) {
                return MOVEL;
            }
        }

        return NAO_IDENTIFICADO;
    }

    // regra RN010 campo 265
    public static String getFlagRoaming(TraftarPosBscs9 enrichFields) {
        if (!enrichFields.getDddOrigemChamada().equals(enrichFields.getDddTelefonePagador())) {
            return S;
        }

        return N;
    }

    // regra RN011 campo 266
    public static String getDirecaoTrafego(TraftarPosBscs9 enrichFields) {
        String tipoServico = enrichFields.getTipoServico();
        String tipoTrafego = enrichFields.getTipoTrafego();
        if (tiposServico.contains(tipoServico.toUpperCase()) && !tipoTrafegoList.contains(tipoTrafego)) {
            if (enrichFields.getFollowUpCallType().equals(_2)) {
                return RECEBIDO;
            } else {
                return ORIGINADO;
            }
        }

        if (DADOS.equalsIgnoreCase(tipoServico) || PROVIDER.equalsIgnoreCase(tipoServico)) {
            return ORIGINADO;
        }

        if (tipoTrafegoList.contains(tipoTrafego)) {
            return RECEBIDO;
        }

        return StringUtils.EMPTY;
    }

    // regra RN013 campo 268
    public static String getCSP(TraftarPosBscs9 enrichFields) {
        if (!_0.equals(enrichFields.getTechnInfoLngDistCarrierCd())) {
            return enrichFields.getTechnInfoLngDistCarrierCd();
        }

        return StringUtils.EMPTY;
    }

    // regra RN014 campo 269
    public static String getOperadoraAOrigem(TraftarPosBscs9 enrichFields, List<Bdo> bdos, Map<String, List<EOTPrestadora>> eotMap, Map<String, List<Cadup>> cadupMap, CNEstadoFinder cnEstadoFinder) {
        String nomFantasia = null;
        String numTelefonePagador = getNumTelefonePagador(enrichFields);

        try {
            EOTPrestadora prestadoraFromBDO = EOTPrestadoraUtility.getEotPrestadoraFromBDO(bdos, eotMap, enrichFields.getTrafTarDate());
            if (prestadoraFromBDO != null) {
                return prestadoraFromBDO.getNomeFantasia();
            } else {
                // se não encontrar na BDO busca da CADUP

                String cadupKey = findCadupKeyFromNumNormalizado(numTelefonePagador);

                int mcdu = Integer.valueOf(StringUtils.right(numTelefonePagador, 4));
                EOTPrestadora cadupEot = EOTPrestadoraUtility.getEotPrestadoraFromCadup(cadupMap, eotMap, cadupKey, mcdu, enrichFields.getTrafTarDate());
                if (cadupEot != null) {
                    return cadupEot.getNomeFantasia();
                }
            }
        } catch (NumberFormatException e) {
            return CommonsConstants.EMPTY;
        }

//		if ( CommonsUtils.equalsIn(nomFantasia, FIXO_TIM, MOVEL_TIM) ) {
//			CNEstado cnEstado = cnEstadoFinder.find(numTelefonePagador.substring(0, 2));
//			
//			if ( null == cnEstado ) return CommonsConstants.EMPTY;
//			
//			return cnEstado.getRegionalVenda();
//		}

        return CommonsConstants.EMPTY;

    }

    // regra RN015 campo 270
    public static String getOperadoraBDestino(TraftarPosBscs9 enrichedFields, List<Bdo> bdos, Map<String, List<EOTPrestadora>> eotMap, Map<String, List<Cadup>> cadupMap) throws ParseException {
//		if (MOVEL_TIM.equals(enrichedFields.getTipoDestinoChamada()) || FIXO_TIM.equals(enrichedFields.getTipoDestinoChamada())) {
//			return TIM;
//		}
        try {
            EOTPrestadora prestadoraFromBDO = EOTPrestadoraUtility.getEotPrestadoraFromBDO(bdos, eotMap, enrichedFields.getTrafTarDate());
            if (prestadoraFromBDO != null) {
                return prestadoraFromBDO.getNomeFantasia();
            } else {
                // se não encontrar na BDO busca da CADUP

                String cadupKey = findCadupKeyFromNumNormalizado(enrichedFields.getNumeroBNormalizado());

                int mcdu = Integer.valueOf(StringUtils.right(enrichedFields.getNumeroBNormalizado(), 4));
                EOTPrestadora cadupEot = EOTPrestadoraUtility.getEotPrestadoraFromCadup(cadupMap, eotMap, cadupKey, mcdu, enrichedFields.getTrafTarDate());
                if (cadupEot != null) {
                    return cadupEot.getNomeFantasia();
                }
            }
        } catch (NumberFormatException e) {
            return StringUtils.EMPTY;
        }

        return StringUtils.EMPTY;
    }

    /**
     * A partir do Número de telefone normalizado, irá realizar a busca pelo CN|Prefixo.<br>
     * CN é representado pelos 2 primeiros caracteres do número.<br>
     * O Prefixo é representado pelos início do número sem o CN, no caso de o número ter o número 9 adicional, o prefixo terá 5 caracteres, caso contrário terá apenas 4.<br>
     * <br>
     * <b>Exemplo 1:</b> <br>
     * Número: "11987779243"<br>
     * CN:11<br>
     * Prefixo:98777<br>
     * CadupKey: 11|98777<br>
     * <br>
     * <b>Exemplo 2:</b> <br>
     * Número: "4196706100"<br>
     * CN:41<br>
     * Prefixo:9670<br>
     * CadupKey: 41|9670<br>
     *
     * @param numNormalizado
     * @return CN|MCDU (chave utilizada no CADUP)
     */
    public static String findCadupKeyFromNumNormalizado(String numNormalizado) {
        StringBuilder cadupKey = new StringBuilder();

        if (StringUtils.isNotBlank(numNormalizado)) {
            if (numNormalizado.length() > 9) {
                cadupKey.append(numNormalizado.substring(0, 2));
                cadupKey.append(CommonsConstants.FILE_FIELD_SEPARATOR);
                if (numNormalizado.length() == 11) {
                    cadupKey.append(numNormalizado.substring(2, 7));
                }
                if (numNormalizado.length() == 10) {
                    cadupKey.append(numNormalizado.substring(2, 6));
                }
            }
        }

        return cadupKey.toString();
    }

    // regra RN016 campo 271
    public static String getOperadoraVisitada(TraftarPosBscs9 enrichFields) {
        return StringUtils.EMPTY;
    }

    // regra RN017 campo 272
    public static String getInboundOutbound(TraftarPosBscs9 enrichFields) {
        String spLocationAddress = enrichFields.getSPLocationAddress();
        if (spLocationAddress.length() > 4 && grupoInbound.contains(spLocationAddress.substring(0, 5))) {
            return INBOUND;
        }

        if ((spLocationAddress.length() > 4 && (spLocationAddress.substring(0, 5).equals(_72499) || spLocationAddress.substring(0, 5).equals(_72488)))
                || (spLocationAddress.length() > 2 && !spLocationAddress.substring(0, 3).startsWith(_724))) {
            return OUTBOUND;
        }
        return StringUtils.EMPTY;

    }

    // regra RN018 campo 273
    public static String getDescricaoPlanoTarifario(TraftarPosBscs9 traftarBscs, PlanoTarifarioFinder planoTarifarioFinder) {

        PlanoTarifario plano = planoTarifarioFinder.find(traftarBscs.getTariffInfoTmcode());

        if (null == plano) return CommonsConstants.EMPTY;

        if ("-1".equals(plano.getSkyNivelPlano()))
            return plano.getDscPlanoTarifario();

        return plano.getDscNivelPlano();

    }

    // regra RN019 campo 274
    public static String getSegmentoCliente() {
        return POS_PAGO;
    }

    // regra RN020 campo 275
    public static String getTipoCliente(TraftarPosBscs9 enrichFields, PlanoTarifarioFinder planoTarifarioFinder) {

        PlanoTarifario plano = planoTarifarioFinder.find(enrichFields.getTariffInfoTmcode());

        if (null == plano) return CommonsConstants.EMPTY;

        return plano.getDscTipoFamiliaPlano();

    }

    // regra RN021 campo 276
    public static String getPacote(BaseCandidataPrePosValue baseCandidataValue, PacoteFinder pacoteFinder) {
        int baseSkyPct = StringUtils.isNumeric(baseCandidataValue.getSkyPacote()) ? Integer.parseInt(baseCandidataValue.getSkyPacote()) : 0;
        Pacote pct = pacoteFinder.find(baseSkyPct);

        if (null == pct) return CommonsConstants.EMPTY;

        return pct.getDscPacoteMinuto();

    }

    // regra RN022 campo 277
    public static String getCicloFaturamento(BaseCandidataPrePosValue baseCandidataValue) {
        return baseCandidataValue.getCodCicloFatOltp();
    }

    // regra RN023 campo 278
    public static String getExtraBundle(TraftarPosBscs9 enrichFields) {
        if (Strings.isNullOrEmpty(enrichFields.getFreeUnitsInfoFuPackId())) {
            return S;
        }

        return N;
    }

    // regra RN024
    public static String getUfTelefonePagador(TraftarPosBscs9 enrichFields, CNEstadoFinder cnEstadoFinder) {

        CNEstado cnEstado = cnEstadoFinder.find(enrichFields.getDddTelefonePagador());

        if (null == cnEstado) return CommonsConstants.EMPTY;

        return cnEstado.getEstado();

    }

    // regra RN025
    public static String getUfOrigemChamada(TraftarPosBscs9 enrichedFields, CNEstadoFinder cnEstadoFinder) {

        CNEstado cnEstado = cnEstadoFinder.find(enrichedFields.getDddOrigemChamada());

        if (null == cnEstado) return CommonsConstants.EMPTY;

        return cnEstado.getEstado();

    }

    public static String getFlagPortabilidade(List<Bdo> bdos) {
        return CollectionUtils.isNotEmpty(bdos) ? S : N;
    }

    public static String getIndicadorClienteMigrado(BaseCandidataPrePosValue baseCan) {
        return StringUtils.isNotBlank(baseCan.getSkyPlanoTarifarioAnt()) ? S : N;
    }

    public static String getFornecedor(AplicacoesVasFinder aplicacoesVasFinder, TraftarPosBscs9 traftarPosBscs9) {
        AplicacoesVas aplicacoesVas = aplicacoesVasFinder.findBySpId(traftarPosBscs9.getCsp());

        if (aplicacoesVas != null)
            return aplicacoesVas.getCompanyName();

        return StringUtils.EMPTY;
    }

    public static String getSegmentoMarketing(TipoClienteFinder tipoClienteFinder, BaseCandidataPrePosValue base) {
        TipoCliente tipoCliente = tipoClienteFinder.find(base.getSkyTipoCliente());

        if (tipoCliente != null)
            return tipoCliente.getSglTipoClienteOltp();

        return StringUtils.EMPTY;
    }

    public static String getIndicadorClienteAtivoConecta(TraftarPosBscs9 traftarPosBscs9) {
		return StringUtils.containsIgnoreCase(traftarPosBscs9.getOperadoraAOrigem(),
                TraftarPosBscs9Constants.PORTO_CONECTA) ? S : N;
    }

    public static final String NAO_IDENTIFICADO = "NÃO IDENTIFICADO";
    public static final String NAO_INFORMADO = "NÃO INFORMADO";
    public static final String N = "N";
    public static final String S = "S";
    public static final String _72488 = "72488";
    public static final String _72499 = "72499";
    public static final String _72441 = "72441";
    public static final String INTERNACIONAL = "INTERNACIONAL";
    public static final String OUTBOUND = "OUTBOUND";
    public static final String INBOUND = "INBOUND";
    public static final String _202 = "202";
    public static final String _00 = "00";
    public static final String _0 = "0";
    public static final String _157 = "157";
    public static final String ORIGINADO = "ORIGINADO";
    public static final String RECEBIDO = "RECEBIDO";
    public static final String RESIDENTE = "RESIDENTE";
    public static final String ROMEIRO = "ROMEIRO";
    public static final String DADOS = "DADOS";
    public static final String PROVIDER = "PROVIDER";
    public static final String OUTROS = "OUTROS";
    public static final String SMP = "SMP";
    public static final String STFC = "STFC";
    public static final String SME = "SME";
    public static final String SMGS = "SMGS";
    public static final String _85 = "85";
    public static final String _3 = "3";
    public static final String MOVEL = "Móvel";
    public static final String FIXO = "Fixo";
    public static final String _99 = "99";
    public static final String TIM = "TIM";
    public static final String FIXO_TIM = "Fixo TIM";
    public static final String MOVEL_TIM = "Móvel TIM";
    public static final String OFFNET = "OFFNET";
    public static final String ONNET = "ONNET";
    public static final String _23 = "23";
    public static final String _41 = "41";
    public static final String VAS = "VAS";
    public static final String NUM_NAO_GEOGRAFICO = "NUM NÃO GEOGRAFICO";
    public static final String COBRANCA_ADICIONAL = "COBRANCA ADIC";
    public static final String LDN = "LDN";
    public static final String LOCAL = "LOCAL";
    public static final String LD1 = "LD1";
    public static final String LD2 = "LD2";
    public static final String LD3 = "LD3";
    public static final String LDI = "LDI";
    public static final String NORMAL = "NORMAL";
    public static final String A_COBRAR = "A COBRAR";
    public static final String _2 = "2";
    public static final String VOLTE = "VOLTE";
    public static final String NUM_NAO_REGINAL = "NUM NAO REGIONAL";
    public static final String CAIXA_POSTAL = "CAIXA POSTAL";
    public static final String URA_SERVICOS = "URA SERVIÇOS";
    public static final String _55009999999991111 = "55009999999991111";
    public static final String _55009999999991100 = "55009999999991100";
    public static final String _55 = "55";
    public static final String _2830 = "2830";
    public static final String _1260 = "1260";
    public static final String VCI = "VCI";
    public static final String VC3 = "VC3";
    public static final String VC2 = "VC2";
    public static final String _09 = "09";
    public static final String _08 = "08";
    public static final String _724 = "724";
    public static final String VC1 = "VC1";
    public static final String VCN_NR = "VCN_NR";
    public static final String _4009 = "4009";
    public static final String _4004 = "4004";
    public static final String _3003 = "3003";
    public static final String _10030 = "10030";
    public static final String _10031 = "10031";
    public static final String _72404 = "72404";
    public static final String _72403 = "72403";
    public static final String _72402 = "72402";
    public static final String _72401 = "72401";
    public static final String _72400 = "72400";
    public static final String NUM_NAO_REGIONAL = "NUM NAO REGIONAL";
    public static final String NUM_ESPECIAL = "NUM ESPECIAL";
    public static final String NUMEROS_ESPECIAIS = "NÚMEROS ESPECIAIS";
    public static final String _0800 = "0800";
    public static final String _00800 = "00800";
    public static final String _0500 = "0500";
    public static final String _0300 = "0300";
    public static final String _550300 = "550300";
    public static final String AD = "AD";
    public static final String DSLI = "DSLI";
    public static final String DSL2 = "DSL2";
    public static final String DSL1 = "DSL1";
    public static final String MMS = "MMS";
    public static final String SMS = "SMS";
    public static final String VOZ = "VOZ";
    public static final String TIM_CONNECT_WAP = "TIM CONNECT / TIM WAP";
    public static final String VIDEO_CHAMADA = "VIDEO CHAMADA";
    public static final String _2031 = "2031";
    public static final String _2030 = "2030";
    public static final String _10012 = "10012";
    public static final String _2955 = "2955";
    public static final String _2983 = "2983";
    public static final String _3337 = "3337";
    public static final String _3348 = "3348";
    public static final String _62 = "62";
    public static final String _22 = "22";
    public static final String _1 = "1";
    public static final String _7 = "7";
    public static final String _6 = "6";
    public static final String _5 = "5";
    public static final String _675 = "675";
    public static final int _9 = 9;
    public static final int _15 = 15;
    public static final String POS_PAGO = "POS PAGO";
    public static final String OTHER = "OTHER";
    public static final String URA = "URA SERVIÇOS";
    public static final String CALL_CENTER = "CALL CENTER";
    public static final String AST_244 = "*244";
    public static final String AST_144 = "*144";
    public static final String AST_222 = "*222";
    public static final String _1056 = "1056";
    public static final String _10341 = "10341";
    public static final String ASTERISCO = "*";
    public static final String _AST_100 = "*100";
    public static final List<Integer> _17_18 = Arrays.asList(17, 18);
    public static final List<Integer> _12_13 = Arrays.asList(12, 13);
    public static final List<String> callCenterNumbers = Arrays.asList(AST_244, AST_144, AST_222, _1056, _10341);
    public static final List<String> tiposServicoVoz = Arrays.asList(_1, _22, _62, _10012, _2030, _2031);
    public static final List<String> tiposServico = Arrays.asList(VOZ, SMS, MMS, VOLTE);
    public static final List<String> grupoTrafegoCobrancaAdicional = Arrays.asList(DSL1, DSL2, DSLI, AD);
    public static final List<String> grupoTrafegoNumNaoGeografico = Arrays.asList(_0300, _0500, _0800, NUM_ESPECIAL, NUM_NAO_REGIONAL, URA);
    public static final List<String> grupoTrafegoRedeChamada = Arrays.asList(_0300, _0500, _0800, NUM_ESPECIAL, NUM_NAO_REGIONAL, CAIXA_POSTAL, URA, PROVIDER, DADOS, TIM_CONNECT_WAP);
    public static final List<String> grupoInbound = Arrays.asList(_72401, _72402, _72403, _72404, _72400);
    public static final List<String> grupoVc1LocationAddress = Arrays.asList(_72402, _72403, _72404);
    public static final List<String> grupoNumNaoRegional = Arrays.asList(_3003, _4004, _4009);
    public static final String[] grupoNumNaoRegional2 = new String[]{"553003", "554004", "554009"};
    public static final List<String> grupoDddB = Arrays.asList(LDI, NUM_NAO_GEOGRAFICO);
    public static final List<String> tipoTrafegoDddB = Arrays.asList(AD, CAIXA_POSTAL);
    public static final List<String> dadosSnCodes = Arrays.asList(_5, _157, _675);
    public static final List<String> tipoTrafegoList = Arrays.asList(DSL1, DSL2, DSLI);
    public static final List<String> sncodesNotCaixaPostal = Arrays.asList(_157);
    public static final int _14 = 14;
    public static final int _19 = 19;
    public static final int _20 = 20;
}
