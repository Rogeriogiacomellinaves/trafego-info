package br.com.tim.mapreduce.finders;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.model.AplicacoesVas;
import br.com.tim.mapreduce.model.TipoCliente;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Utils;
import br.com.tim.utils.CachedFile;
import br.com.tim.utils.SequenceCachedFile;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TipoClienteFinder {

    private static TipoClienteFinder finder;

    @SuppressWarnings("rawtypes")
    public static synchronized TipoClienteFinder getInstance(Configuration conf) {
        if (null == finder)
            return new TipoClienteFinder(conf);
        return finder;
    }

    private static List<TipoCliente> list;
    private static TipoCliente searchKey;

    public class TipoClienteComparator implements Comparator<TipoCliente> {
        @Override
        public int compare(TipoCliente o1, TipoCliente o2) {
            return o1.getSkyTipocliente().compareTo(o2.getSkyTipocliente());
        }
    }

    private static TipoClienteComparator comparator;

    private void loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
        list = CachedFile.getTextFileAsObjectList(
                conf,
                DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.TIPO_CLIENTE_DIR).toUri().toString(),
                false,
                TipoCliente.class);
    }

    public TipoClienteFinder(Configuration conf) {
        searchKey = new TipoCliente();
        comparator = new TipoClienteComparator();

        try {
            loadCachedFile(conf);
        } catch (IllegalArgumentException | CommonsException e) {
            throw new RuntimeException(e);
        }

        Collections.sort(list, comparator);
    }

    public TipoCliente find(String skyTipoCliente) {
        if (StringUtils.isEmpty(skyTipoCliente))
            return null;

        searchKey.setSkyTipocliente(skyTipoCliente);

        if (list.size() == 0)
            return null;

        int pos = Collections.binarySearch(list, searchKey, comparator);
        return (pos >= 0) ? list.get(pos) : null;
    }
}
