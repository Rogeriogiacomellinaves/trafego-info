package br.com.tim.mapreduce.joinbasecan;

import java.io.IOException;

import br.com.tim.mapreduce.finders.*;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.joinbasecan.model.BaseCandidataPrePosValue;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanValue;
import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Regras;

public class TraftarPosBscs9JoinBaseCanReducer extends Reducer<TraftarPosBscs9JoinBaseCanKey, TraftarPosBscs9JoinBaseCanValue, NullWritable, TraftarPosBscs9>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9JoinBaseCanReducer.class);
	
	private BaseCandidataPrePosValue inBaseCan;
	
	private TraftarPosBscs9 outValue;
	
	private static AplicacoesVasFinder aplicacoesVasFinder;
	private static CentralVolteFinder centralVolteFinder; 
	private static PacoteFinder pacoteFinder; 
	private static CNEstadoFinder cnEstadoFinder;
	private static PlanoTarifarioFinder planoTarifarioFinder;
	private static TipoClienteFinder tipoClienteFinder;
	
	private boolean isRep = false;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		inBaseCan = new BaseCandidataPrePosValue();
		
		outValue = new TraftarPosBscs9();
		
		aplicacoesVasFinder = AplicacoesVasFinder.getInstance(context.getConfiguration());
		centralVolteFinder = new CentralVolteFinder(context);
		pacoteFinder = PacoteFinder.getInstance(context.getConfiguration());
		cnEstadoFinder = CNEstadoFinder.getInstance(context.getConfiguration());
		planoTarifarioFinder = PlanoTarifarioFinder.getInstance(context.getConfiguration());
		tipoClienteFinder = TipoClienteFinder.getInstance(context.getConfiguration());
		isRep = context.getConfiguration().getBoolean(TraftarPosBscs9Constants.IS_REPROCESS, false);
		
	}
	
	@Override
	protected void reduce(TraftarPosBscs9JoinBaseCanKey key, Iterable<TraftarPosBscs9JoinBaseCanValue> values, Context context) throws IOException, InterruptedException {
		
		inBaseCan.clean();
		outValue.clean();
		
		for( TraftarPosBscs9JoinBaseCanValue value : values ) {
			
			if ( value.get() instanceof BaseCandidataPrePosValue ) {
				context.getCounter("REDUCER", "BASECAN ARRIVED").increment(1L);
				inBaseCan.clone(value.getBaseCandidataPrePosValue());
			}
			
			if ( value.get() instanceof TraftarPosBscs9 ) {
				outValue = value.getTraftarPosBscs9();
				
				outValue = TraftarPosBscs9Regras.enrichTrafTar(outValue, 
						inBaseCan, 
						aplicacoesVasFinder, 
						centralVolteFinder, 
						pacoteFinder, 
						cnEstadoFinder, 
						planoTarifarioFinder,
						tipoClienteFinder,
						isRep);
				
				context.getCounter("REDUCER", "TRAFTAR ARRIVED AND WRITTEN").increment(1L);
				context.write(NullWritable.get(), outValue);
			}
			
		}
		
	}
	
}
