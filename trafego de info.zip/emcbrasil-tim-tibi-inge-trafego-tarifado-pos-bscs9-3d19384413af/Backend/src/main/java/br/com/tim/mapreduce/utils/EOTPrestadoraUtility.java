package br.com.tim.mapreduce.utils;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.model.Bdo;
import br.com.tim.mapreduce.model.EOTPrestadora;
import br.com.tim.model.Cadup;
import br.com.tim.utils.DateUtil;
import br.com.tim.utils.MapFile;

public class EOTPrestadoraUtility {

	private static final Logger log = Logger.getLogger(EOTPrestadoraUtility.class);

	private static Date dataFimVigencia = DateUtil.parseDate("9999-12-31 23:59:59", "yyyy-MM-dd HH:mm:ss");

	/**
	 * This method is responsible for finding Eot Prestadora via CADUP.
	 * 
	 * @param cadupMap
	 *            CADUP MapFile
	 * @param eotMap
	 *            EOT PRESTADORA Map object
	 * @param cadupKey
	 *            CADUP key
	 * @param phoneNumberMCDU
	 *            Phone number MCDU
	 * @param cdrDate
	 *            CDR Date
	 * @return EotPrestadora object
	 */
	public static EOTPrestadora getEotPrestadoraFromCadup(Map<String, List<Cadup>> cadupMap, Map<String, List<EOTPrestadora>> eotMap, String cadupKey, int phoneNumberMCDU, Date cdrDate) {
		try {
			List<Cadup> cadups = cadupMap.get(cadupKey);
			if (cadups != null && cadups.size() > 0) {
				for (Cadup cadup : cadups) {
					int initialMCDU = Integer.parseInt(cadup.getMcduInicial());
					int finalMCDU = Integer.parseInt(cadup.getMcduFinal());

					if (phoneNumberMCDU >= initialMCDU && phoneNumberMCDU <= finalMCDU && cdrDate.after(cadup.getDataVigenciaInicial()) && cdrDate.before(cadup.getDataVigenciaFinal())) {
						if (cadup.getEmpresaReceptora() != null) {
							return eotMap.get(cadup.getEmpresaReceptora()).get(0);
						}
					}
				}
			}
			return null;
		} catch (Exception e) {
			log.error("Error getting Eot from CADUP: ", e);
			return null;
		}
	}

	/**
	 * This method is responsible for making the join with Bdo and Eot Prestadora.<br>
	 * 
	 * @param cadups
	 * @param conf
	 * @param mcdu
	 * @return Entity Eot Prestadora
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static EOTPrestadora getEotJoinCadupAndEot(List<Cadup> cadups, Map<String, List<EOTPrestadora>> eotGrupo, Configuration conf, int mcdu) throws IOException, ClassNotFoundException {

		int mcduInicial = 0;
		int mcduFinal = 0;

		if (cadups != null && cadups.size() > 0 && !cadups.isEmpty()) {
			for (Cadup cdp : cadups) {
				mcduInicial = Integer.parseInt(cdp.getMcduInicial());
				mcduFinal = Integer.parseInt(cdp.getMcduFinal());

				if (mcdu >= mcduInicial && mcdu <= mcduFinal && cdp.getDataVigenciaFinal().equals(dataFimVigencia)) {
					if (cdp.getEmpresaReceptora() != null) {
						EOTPrestadora eot = eotGrupo.get(cdp.getEmpresaReceptora()).get(0);
						return eot;
					}
				}
			}
		}
		return null;
	}

	/**
	 * This method is responsible for finding Eot Prestadora via BDO.
	 * 
	 * @param bdoMap
	 *            BDO MapFile
	 * @param eotMap
	 *            EOT PRESTADOR Map
	 * @param bdoKey
	 *            BDO Key
	 * @param cdrDate
	 *            CDR Date
	 * @return EotPrestadora object
	 */
	public static EOTPrestadora getEotPrestadoraFromBDO(MapFile bdoMap, Map<String, List<EOTPrestadora>> eotMap, String bdoKey, Date cdrDate) {
		List<Bdo> bdos = bdoMap.getValueAsList(bdoKey, Bdo.class);
		return getEotPrestadoraFromBDO(bdos, eotMap, cdrDate);
	}

	/**
	 * This method is responsible for finding Eot Prestadora via a list of BDOs.
	 * 
	 * @param bdoMap
	 *            BDO MapFile
	 * @param eotMap
	 *            EOT PRESTADOR Map
	 * @param bdoKey
	 *            BDO Key
	 * @param cdrDate
	 *            CDR Date
	 * @return EotPrestadora object
	 */
	public static EOTPrestadora getEotPrestadoraFromBDO(List<Bdo> bdos, Map<String, List<EOTPrestadora>> eotMap, Date cdrDate) {

		try {

			Bdo bdoCDRDate = null;
			for (Bdo bdo : bdos) {
				if (null == bdoCDRDate && cdrDate.after(bdo.getDataInicioJanela())) {
					bdoCDRDate = bdo;
				} else {
					if (bdoCDRDate != null) {
						if (bdoCDRDate.getDataInicioJanela().before(bdo.getDataInicioJanela()) && cdrDate.after(bdo.getDataInicioJanela()))
							bdoCDRDate = bdo;
					}
				}
			}
			if (null != bdoCDRDate) {
				if (bdoCDRDate.getTipoOperacao().equals(Bdo.TIPO_OPERACAO_D)) {
					return null;
				} else {
					if (null != bdoCDRDate.getEot()) {
						return eotMap.get(bdoCDRDate.getEot()).get(0);
					}
				}
			}
			return null;

		} catch (Exception e) {
			log.error("Error getting Eot from BDO: ", e);
			return null;
		}
	}
}