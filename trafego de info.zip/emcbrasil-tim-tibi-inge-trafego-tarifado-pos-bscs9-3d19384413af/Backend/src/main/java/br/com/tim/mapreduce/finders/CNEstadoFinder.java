package br.com.tim.mapreduce.finders;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Reducer;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.model.CNEstado;
import br.com.tim.utils.CachedFile;

public class CNEstadoFinder {
	
	private static CNEstadoFinder finder;
	
	@SuppressWarnings("rawtypes")
	public static synchronized CNEstadoFinder getInstance(Configuration conf) {
		if ( null == finder )
			return new CNEstadoFinder(conf);
		return finder;
	}
	
	private static List< CNEstado > list;
	private static CNEstado searchKey;
	private static CNEstado nullCn;

	public class CNEstadoComparator implements Comparator< CNEstado > {
		@Override
		public int compare( CNEstado o1, CNEstado o2 ) {		
			return o1.getCn().compareTo(o2.getCn());
		}
	}
	
	private static CNEstadoComparator comparator;
	
	private List< CNEstado > loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
		return CachedFile.getTextFileAsObjectList(
				conf, 
				DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.PATH_CN_ESTADO),
				false, 
				CNEstado.class );
	}
	
	@SuppressWarnings("rawtypes")
	public CNEstadoFinder( Configuration conf ) {
		searchKey = new CNEstado();
		comparator = new CNEstadoComparator();
		searchKey = new CNEstado();
		nullCn = null;
		
		try {
			list = loadCachedFile(conf);
		} catch ( IllegalArgumentException | CommonsException e ) {
			throw new RuntimeException( e );
		}
		
		Collections.sort( list, comparator );
	}
	
	public CNEstado find(String cn) {
		searchKey.setCn(cn);
		
		if ( list.size() == 0 ) return nullCn;
		
		int pos = Collections.binarySearch( list, searchKey, comparator );
		return ( pos >= 0 ) ? list.get( pos ) : nullCn;
	}
	
}
