package br.com.tim.mapreduce.joinbdo_a;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.joinbasecan.TraftarPosBscs9Mapper;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoAValue;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;
import br.com.tim.mapreduce.model.Bdo;

public class BdoMapper<T> extends Mapper<T, Text, TraftarPosBscs9JoinBdoAKey, TraftarPosBscs9JoinBdoAValue>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9Mapper.class);
	
	private TraftarPosBscs9JoinBdoAKey outKey;
	private TraftarPosBscs9JoinBdoAValue outValue;
	
	private Bdo outBdo;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		outKey = new TraftarPosBscs9JoinBdoAKey();
		outValue = new TraftarPosBscs9JoinBdoAValue();
		
		outBdo = new Bdo();
		
	}
	
	@Override
	protected void map(T key, Text value, Context context) throws IOException, InterruptedException {
		
		outKey.clean();
		outBdo.clean();
		
		String line = value.toString();
		
		if ( StringUtils.isBlank(line) ) return;
		
		outBdo.parseFromText(line);
		
		outKey.set(outBdo);
		outValue.set(outBdo);
		
		context.getCounter("MAPPER", "BDO WRITTEN").increment(1L);
		context.write(outKey, outValue);
		
	}
	
}
