package br.com.tim.mapreduce.joinbasecan;

import java.io.IOException;
import java.util.Date;

import br.com.tim.mapreduce.finders.CecCicloFaturamentoFinder;
import br.com.tim.mapreduce.finders.PeakOffPeakFinder;
import br.com.tim.mapreduce.finders.TipoClienteFinder;
import br.com.tim.mapreduce.model.CecCicloFaturamento;
import br.com.tim.mapreduce.model.PeakOffPeak;
import br.com.tim.mapreduce.model.TipoCliente;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import br.com.tim.mapreduce.joinbasecan.model.BaseCandidataPrePosValue;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;
import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanValue;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;

public class BaseCandidataPrePosMapper<T> extends Mapper<T, Text, TraftarPosBscs9JoinBaseCanKey, TraftarPosBscs9JoinBaseCanValue>{

	private Logger LOG = Logger.getLogger(BaseCandidataPrePosMapper.class);
	
	private TraftarPosBscs9JoinBaseCanKey outKey;
	private TraftarPosBscs9JoinBaseCanValue outValue;
	
	private BaseCandidataPrePosValue baseCan;
	private CecCicloFaturamentoFinder cecCicloFaturamentoFinder;
	private CecCicloFaturamento cecCicloFaturamento;

	private long baseCanDate;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		this.outKey = new TraftarPosBscs9JoinBaseCanKey();
		this.outValue = new TraftarPosBscs9JoinBaseCanValue();
		
		this.baseCan = new BaseCandidataPrePosValue();
		
		this.baseCanDate = context.getConfiguration().getLong(TraftarPosBscs9Constants.BASECAN_REF_DATE, 0L);

		cecCicloFaturamentoFinder = new CecCicloFaturamentoFinder(context.getConfiguration());

	}
	
	@Override
	protected void map(T key, Text value, Context context) throws IOException, InterruptedException {
		cecCicloFaturamento = null;

		this.outKey.clean();
		this.baseCan.clean();
		
		String line = value.toString();
		
		if ( StringUtils.isBlank(line) ) return;
		
		this.baseCan.setFromText(line, this.baseCanDate);

		setDescricaoDataCorteFatura();

		this.outKey.set(this.baseCan);
		this.outValue.set(this.baseCan);
		
		context.getCounter("MAPPER", "BASECAN WRITTEN").increment(1L);
		context.write(this.outKey, this.outValue);
		
	}

	private void setDescricaoDataCorteFatura() {
		cecCicloFaturamento = cecCicloFaturamentoFinder.find(baseCan.getCodCicloFatOltp());
		if (cecCicloFaturamento != null)
			baseCan.setDescricaoDataCorteFatura(cecCicloFaturamento.getDescricaoCicloFaturamento());
	}


}
