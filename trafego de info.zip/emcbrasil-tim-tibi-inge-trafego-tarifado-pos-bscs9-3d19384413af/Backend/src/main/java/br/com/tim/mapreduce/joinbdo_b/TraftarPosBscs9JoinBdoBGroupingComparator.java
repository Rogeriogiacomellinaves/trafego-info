package br.com.tim.mapreduce.joinbdo_b;

import org.apache.hadoop.io.WritableComparator;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;

public class TraftarPosBscs9JoinBdoBGroupingComparator extends WritableComparator {

	public TraftarPosBscs9JoinBdoBGroupingComparator	() {
        super(TraftarPosBscs9JoinBdoBKey.class, true);
    }
	
	@Override
	public int compare(Object a, Object b) {
		TraftarPosBscs9JoinBdoBKey key1 = (TraftarPosBscs9JoinBdoBKey) a;
		TraftarPosBscs9JoinBdoBKey key2 = (TraftarPosBscs9JoinBdoBKey) b;
		return key1.compareTo(key2);
	}

}
