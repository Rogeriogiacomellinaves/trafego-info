package br.com.tim.mapreduce.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.DateUtil;

public class EOTPrestadora {

	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	private String skyEot;
	private String codigo;
	private String nomeFantasia;
	private String razaoSocial;
	private String csp;
	private String tipoServico;
	private String modalidadeBanda;
	private String areaPrestacao;
	private String holding;
	private Date dataInsertDw;

	public EOTPrestadora() {
	}

	public EOTPrestadora(String skyEot, String codigo, String nomeFantasia, String razaoSocial, String csp, String tipoServico, String modalidadeBanda, String areaPrestacao, String holding,
			Date dataInsertDw) {
		this.skyEot = skyEot;
		this.codigo = codigo;
		this.nomeFantasia = nomeFantasia;
		this.razaoSocial = razaoSocial;
		this.csp = csp;
		this.tipoServico = tipoServico;
		this.modalidadeBanda = modalidadeBanda;
		this.areaPrestacao = areaPrestacao;
		this.holding = holding;
		this.dataInsertDw = dataInsertDw;
	}

	public String getSkyEot() {
		return skyEot;
	}

	public void setSkyEot(String skyEot) {
		this.skyEot = skyEot;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getCsp() {
		return csp;
	}

	public void setCsp(String csp) {
		this.csp = csp;
	}

	public String getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(String tipoServico) {
		this.tipoServico = tipoServico;
	}

	public String getModalidadeBanda() {
		return modalidadeBanda;
	}

	public void setModalidadeBanda(String modalidadeBanda) {
		this.modalidadeBanda = modalidadeBanda;
	}

	public String getAreaPrestacao() {
		return areaPrestacao;
	}

	public void setAreaPrestacao(String areaPrestacao) {
		this.areaPrestacao = areaPrestacao;
	}

	public String getHolding() {
		return holding;
	}

	public void setHolding(String holding) {
		this.holding = holding;
	}

	public Date getDataInsertDw() {
		return dataInsertDw;
	}

	public void setDataInsertDw(Date dataInsertDw) {
		this.dataInsertDw = dataInsertDw;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EotPrestadora [skyEot=");
		builder.append(skyEot);
		builder.append("codigo=");
		builder.append(codigo);
		builder.append(", nomeFantasia=");
		builder.append(nomeFantasia);
		builder.append(", razaoSocial=");
		builder.append(razaoSocial);
		builder.append(", csp=");
		builder.append(csp);
		builder.append(", tipoServico=");
		builder.append(tipoServico);
		builder.append(", modalidadeBanda=");
		builder.append(modalidadeBanda);
		builder.append(", areaPrestacao=");
		builder.append(areaPrestacao);
		builder.append(", holding=");
		builder.append(holding);
		builder.append(", DataInsertDw=");
		builder.append(dataInsertDw);
		builder.append("]");
		return builder.toString();
	}

	public static EOTPrestadora parseFromText(String text) {

		if (text != null && !text.trim().isEmpty()) {
			String[] cols = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);
			int i = 0;
			return new EOTPrestadora(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], DateUtil.parseDate(cols[i++], sdf));
		}

		return null;
	}
}