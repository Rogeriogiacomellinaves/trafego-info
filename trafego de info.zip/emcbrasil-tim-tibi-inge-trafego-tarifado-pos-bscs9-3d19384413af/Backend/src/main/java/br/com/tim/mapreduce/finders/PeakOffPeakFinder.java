package br.com.tim.mapreduce.finders;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.model.PeakOffPeak;
import br.com.tim.mapreduce.model.TipoCliente;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.utils.CachedFile;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PeakOffPeakFinder {

    private static PeakOffPeakFinder finder;

    @SuppressWarnings("rawtypes")
    public static synchronized PeakOffPeakFinder getInstance(Configuration conf) {
        if (null == finder)
            return new PeakOffPeakFinder(conf);
        return finder;
    }

    private static List<PeakOffPeak> list;
    private static PeakOffPeak searchKey;

    public class PeakOffPeakComparator implements Comparator<PeakOffPeak> {
        @Override
        public int compare(PeakOffPeak o1, PeakOffPeak o2) {
            return o1.getTtCode().compareTo(o2.getTtCode());
        }
    }

    private static PeakOffPeakComparator comparator;

    private void loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
        list = CachedFile.getTextFileAsObjectList(
                conf,
                DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.FULL_PEAK_OFF_PEAK_FILE_NAME_INPUT).toUri().toString(),
                false,
                PeakOffPeak.class);
    }

    public PeakOffPeakFinder(Configuration conf) {
        searchKey = new PeakOffPeak();
        comparator = new PeakOffPeakComparator();

        try {
            loadCachedFile(conf);
        } catch (IllegalArgumentException | CommonsException e) {
            throw new RuntimeException(e);
        }

        Collections.sort(list, comparator);
    }

    public PeakOffPeak find(String ttCode) {
        if (StringUtils.isEmpty(ttCode))
            return null;

        searchKey.setTtCode(ttCode);

        if (list.size() == 0)
            return null;

        int pos = Collections.binarySearch(list, searchKey, comparator);
        return (pos >= 0) ? list.get(pos) : null;
    }
}
