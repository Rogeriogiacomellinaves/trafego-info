package br.com.tim.mapreduce.model;

import br.com.tim.utils.CommonsConstants;
import org.apache.commons.lang3.StringUtils;

public class TipoCliente {

    private String skyTipocliente;
    private String sglTipoClienteOltp;

    private static final int SKY_TIPO_CLIENTE = 0, SGL_TIPO_CLIENTE_OLTP = 1;

    public static TipoCliente parseFromText(String text) {
        TipoCliente result = new TipoCliente();
        String[] values = StringUtils.splitByWholeSeparatorPreserveAllTokens(
                text, CommonsConstants.FILE_FIELD_SEPARATOR);

        result.skyTipocliente = values[SKY_TIPO_CLIENTE];
        result.sglTipoClienteOltp = values[SGL_TIPO_CLIENTE_OLTP];

        return result;
    }

    public String getSkyTipocliente() {
        return skyTipocliente;
    }

    public void setSkyTipocliente(String skyTipocliente) {
        this.skyTipocliente = skyTipocliente;
    }

    public String getSglTipoClienteOltp() {
        return sglTipoClienteOltp;
    }

    public void setSglTipoClienteOltp(String sglTipoClienteOltp) {
        this.sglTipoClienteOltp = sglTipoClienteOltp;
    }
}
