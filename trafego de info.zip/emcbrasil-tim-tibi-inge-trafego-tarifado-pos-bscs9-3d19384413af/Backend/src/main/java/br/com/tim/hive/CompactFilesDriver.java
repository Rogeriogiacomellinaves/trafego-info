package br.com.tim.hive;

import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.Constants;
import br.com.tim.utils.FormatDateEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.joda.time.LocalDate;
import org.joda.time.base.AbstractPartial;

import java.io.*;
import java.sql.SQLException;
import java.util.zip.GZIPOutputStream;


public class CompactFilesDriver extends Configured implements Tool  {

	protected static final Logger log = Logger.getLogger(CompactFilesDriver.class);

	private Configuration conf;
	private FileSystem fs;
	private String[] args;
	private String homePath;
	private boolean deleteSource;
	private static final String HOME = "homePath";

	public static void main(String[] args) throws Exception {

		CompactFilesDriver driver = new CompactFilesDriver();
		driver.args = args;
		int exitCode = ToolRunner.run(driver, args);
		log.info("Exit code: " + exitCode);
		log.info("Finish process");
		System.exit(exitCode);
	}

	@Override
	public int run(String[] args) {
		try {

			init();

			execute();

			return CommonsConstants.SUCCESS;

		} catch (Exception ex) {
			log.error(ex.getMessage() + "\n --- Return Code : " + CommonsConstants.ERROR, ex);
			return CommonsConstants.ERROR;
		}
	}

	private void init() throws  Exception{
		log.info("START CONFIGURATION");
		conf = new Configuration();
		conf.addResource(new Path(System.getProperty(CommonsConstants.PROJECT_CONFIGURATION)));
		conf.addResource(new Path(System.getProperty(CommonsConstants.ENVIRONMENT_CONFIGURATION)));
		configLog(conf);

		fs = FileSystem.newInstance(conf);
		homePath = System.getProperty(HOME);
		deleteSource = conf.getBoolean("delete-source",false);
		Path path = new Path(this.getConf().get("input-path"));
		if (!fs.exists(path)){
			throw new Exception("Input path is empty");
		}

		buildDate();
		buildReferenceDate();
		log.info("END CONFIGURATION");
	}

	private void buildReferenceDate() throws HiveIngestionInitializationException {
		try{
			int minusDays = conf.getInt(Constants.PARAM_MINUS_DAY,1);

			LocalDate dateRef = getReprocessDay();
			if (null == dateRef){
				dateRef = LocalDate.now().minusDays(minusDays);
			}

			addParam(TraftarPosBscs9Constants.PARAM_DATA_REF_PARTICAO,dateRef,FormatDateEnum.YYYYMMDD,FormatDateEnum.YYYY_MM_DD);
			log.info("Date Reference is " + dateRef.toString(FormatDateEnum.YYYY_MM_DD.getDateFormat()));

		}catch(Exception e){
			throw new HiveIngestionInitializationException(e);
		}
	}

	private void buildDate() throws Exception{

			int minusDays = this.getConf().getInt(Constants.PARAM_MINUS_DAY,1);
			LocalDate dateRef = getReprocessDay();
			if (null == dateRef){
				dateRef = LocalDate.now().minusDays(minusDays);
			}
			log.info("DATE REFERENCE IS " + dateRef.toString(FormatDateEnum.YYYY_MM_DD.getDateFormat()));
			LocalDate end = dateRef;
			LocalDate init = end.withDayOfMonth(1);

			addParam("param-init",init,FormatDateEnum.YYYYMMDD,FormatDateEnum.YYYY_MM_DD);
			addParam("param-end",end,FormatDateEnum.YYYYMMDD,FormatDateEnum.YYYY_MM_DD);
	}

	protected LocalDate getReprocessDay(){
		if (ArrayUtils.isNotEmpty(this.getArgs())){
			String param = this.getArgs()[0];
			if (StringUtils.startsWithIgnoreCase(param,Constants.REPROCESS_DAY)){
				log.info("TYPE PROCESS IS REPROCESS");
				return  FormatDateEnum.YYYY_MM_DD.getDateFormat().parseLocalDate(StringUtils.substringAfter(param,"="));
			}
		}
		return null;
	}

	public void addParam(String prefix, AbstractPartial data, FormatDateEnum ... formats) throws SQLException {
		for (FormatDateEnum format : formats){
			this.getConf().set(prefix+"-"+format.getText(),data.toString(format.getDateFormat()));
		}
	}

	protected void execute() throws Exception {
		Path inputPath = new Path(this.getConf().get("input-path"));
		Path outputPath = new Path(this.getConf().get("output-path"));
		if (!fs.exists(inputPath)){
		   throw new Exception("Input path is empty");
		}

		File stagingLocalFile = new File(this.homePath.replace("..",""),"staging");
		File stagingInputLocalFile = new File(stagingLocalFile,"input");
		File stagingOutputLocalFile = new File(stagingLocalFile,"output");
		File outputFileName = new File(getConf().get("output-fileName"));

		FileUtils.deleteDirectory(stagingLocalFile);

		log.info("Creating " + stagingInputLocalFile);
		stagingInputLocalFile.mkdirs();

		log.info("Creating " + stagingOutputLocalFile);
		stagingOutputLocalFile.mkdirs();

		FileStatus[] files = fs.globStatus(new Path(inputPath,"*"));
		for (FileStatus f : files){
			log.info("Copying file " + f.toString() + " from HDFS to " + stagingInputLocalFile);
			fs.copyToLocalFile(deleteSource,f.getPath(),new Path(stagingInputLocalFile.getPath()));
		}

		if (ArrayUtils.isEmpty(files)){
            log.warn("No files to process.");
            System.exit(CommonsConstants.SUCCESS);
		}


		createTarFile(stagingInputLocalFile,stagingOutputLocalFile,outputFileName);
		Path src = new Path(stagingOutputLocalFile.getPath(),outputFileName.getName());
		log.info("Copying " + src + " to " + outputPath);
		fs.copyFromLocalFile(deleteSource,true,new Path(stagingOutputLocalFile.getPath(),outputFileName.getName()),outputPath);

		log.info("Removing " + stagingLocalFile);
		FileUtils.deleteDirectory(stagingLocalFile);

	}

	public String[] getArgs() {
		return args;
	}

	@Override
	public Configuration getConf() {
		return conf;
	}

	public FileSystem getFs() {
		return fs;
	}

	protected static void configLog(Configuration config){
		String logConfig = config.get("log-config");
		logConfig = logConfig.replace(config.get("process-id"),
				config.get("process-id").toLowerCase().replace(CommonsConstants.UNDERLINE, CommonsConstants.HIFEN));

		PropertyConfigurator.configure(new ByteArrayInputStream(logConfig.getBytes()));
	}

	private void createTarFile(File source , File dest, File fileName){
		log.info("Creating tar.gz");
		TarArchiveOutputStream tarOs = null;
		try {
			FileOutputStream fos = new FileOutputStream(new File(dest.getPath(),fileName.getName()).getPath());
			GZIPOutputStream gos = new GZIPOutputStream(new BufferedOutputStream(fos));
			tarOs = new TarArchiveOutputStream(gos);
			addFilesToTarGZ(source.getPath(), tarOs);
		} catch (IOException e) {
			log.error(e);
		}finally{
			try {
				tarOs.close();
			} catch (IOException e) {
				log.error(e);
			}
		}
	}

	public void addFilesToTarGZ(String filePath, TarArchiveOutputStream tarArchive) throws IOException {
		File file = new File(filePath);

		if(file.isDirectory()){
			for(File f : file.listFiles()){
				if (!FilenameUtils.isExtension(f.getName(),"crc")){
					log.info("Adding file to tar " + f.getPath());
					addFilesToTarGZ(f.getAbsolutePath(), tarArchive);
				}
			}
		}else{
			String entryName = file.getName();
			log.info("Adding file to tar " + file.getPath());
			tarArchive.putArchiveEntry(new TarArchiveEntry(file, entryName));
			FileInputStream fis = new FileInputStream(file);
			BufferedInputStream bis = new BufferedInputStream(fis);
			IOUtils.copy(bis, tarArchive);
			tarArchive.closeArchiveEntry();
			bis.close();
		}
	}
}
