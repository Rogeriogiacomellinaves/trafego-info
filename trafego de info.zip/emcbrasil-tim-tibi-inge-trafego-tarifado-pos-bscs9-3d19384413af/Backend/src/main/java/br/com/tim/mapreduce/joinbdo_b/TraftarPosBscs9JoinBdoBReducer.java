package br.com.tim.mapreduce.joinbdo_b;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBValue;
import br.com.tim.mapreduce.model.Bdo;
import br.com.tim.mapreduce.model.EOTPrestadora;
import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Regras;
import br.com.tim.model.Cadup;
import br.com.tim.utils.CachedFile;

public class TraftarPosBscs9JoinBdoBReducer extends Reducer<TraftarPosBscs9JoinBdoBKey, TraftarPosBscs9JoinBdoBValue, NullWritable, TraftarPosBscs9>{

	private Logger LOG = Logger.getLogger(TraftarPosBscs9JoinBdoBReducer.class);
	
	private List<Bdo> bdos;
	
	private static Map<String, List<Cadup>> cadupMap;
	private static Map<String, List<EOTPrestadora>> eotMap;
	
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		
		bdos = new ArrayList<Bdo>();
		
		try {
			cadupMap = CachedFile.getMapFromTextFile(
									context.getConfiguration(), 
									context.getConfiguration().get(TraftarPosBscs9Constants.CADUP_DIR), 
									92000, 
									Cadup.class );

			eotMap = CachedFile.getMapFromObjectList(
									CachedFile.getTextFileAsObjectList(
											context.getConfiguration(), 
											context.getConfiguration().get(TraftarPosBscs9Constants.EOT_PRESTADORA_DIR), 
											false, 
											EOTPrestadora.class), 
											"codigo" );
		} catch (CommonsException e) {
			LOG.error("Error setting up the Reducer...", e);
			throw new IOException(e);
		}
		
	}
	
	@Override
	protected void reduce(TraftarPosBscs9JoinBdoBKey key, Iterable<TraftarPosBscs9JoinBdoBValue> values, Context context) throws IOException, InterruptedException {
		
		bdos.clear();
		
		for ( TraftarPosBscs9JoinBdoBValue value : values ) {
			
			if ( value.get() instanceof Bdo ) {
				context.getCounter("REDUCER", "BDO ARRIVED").increment(1L);
				bdos.add(new Bdo(value.getBDOValue()));
			}
			
			if ( value.get() instanceof TraftarPosBscs9 ) {
				context.getCounter("REDUCER", "TRAFTAR ARRIVED").increment(1L);
				TraftarPosBscs9 traftar = value.getTraftarPosBscs9();
				
				if ( key.getNumTelefoneB().startsWith("DADOS") )
					context.getCounter("REDUCER", "TRAFTAR W/O BDO WRITTEN").increment(1L);
				else
					context.getCounter("REDUCER", "TRAFTAR WITH BDO WRITTEN").increment(1L);
				
				traftar = TraftarPosBscs9Regras.enrichTrafTarB(traftar, bdos, eotMap, cadupMap);
				
				context.write(NullWritable.get(), traftar);
				
			}
			
		}
		
	}
	
}
