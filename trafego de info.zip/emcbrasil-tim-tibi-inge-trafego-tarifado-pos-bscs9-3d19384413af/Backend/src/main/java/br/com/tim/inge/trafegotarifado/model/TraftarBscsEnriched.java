package br.com.tim.inge.trafegotarifado.model;

/**
 * 
 * Utilizar classe br.com.tim.mapreduce.model.TraftarPosBscs9
 *
 */
@Deprecated
public interface TraftarBscsEnriched extends TraftarBscs {

	public String getTipoTrafego();

	public String getTipoServico();

	public String getDDDOrigemChamada();

	public String getDDDNumeroB();

	public String getNumeroBNormalizado();

	public String getGrupoTrafego();

	public String getTipoDestinoChamada();

	public String getTipoOrigemChamada();

	public String getDDDTelefonePagador();

}