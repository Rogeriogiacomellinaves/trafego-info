package br.com.tim.mapreduce.joinbdo_b;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import br.com.tim.driverutils.DriverUtility;
import br.com.tim.driverutils.DriverUtils;
import br.com.tim.driverutils.Entry;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;
import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBValue;
import br.com.tim.mapreduce.joinbdo_b.TraftarPosBscs9Mapper;
import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.mr.GenericMetricsDriver;
import br.com.tim.mr.utils.ValueOnlyTextOutputFormat;
import br.com.tim.utils.CommonsConstants;

public class TraftarPosBscs9JoinBdoBDriver extends GenericMetricsDriver {

	protected static Logger LOG = Logger.getLogger(TraftarPosBscs9JoinBdoBDriver.class);
	protected static String[] argsDates;
	protected FileSystem fs;
	
	private static final DateTimeFormatter DTF_yyyy_MM_dd = DateTimeFormat.forPattern("yyyy-MM-dd");
	private static final DateTimeFormatter DTF_ddMMyyyy = DateTimeFormat.forPattern("ddMMyyyy");
	
	public static final String TOTAL = "total";
	
	private String timestamp = CommonsConstants.EMPTY;
	
	public DateTime datProcess, lastDate;
	
	private Path jobOutputPath;
	
	public static void main(String[] args) throws Exception {
		LOG.info("====================================== BEGIN JOB ======================================");
		TraftarPosBscs9JoinBdoBDriver driver = new TraftarPosBscs9JoinBdoBDriver();
		argsDates = args;
		int exitCode = ToolRunner.run(driver, args);
		LOG.info("Exit code: " + exitCode);
		LOG.info("====================================== END JOB ======================================");
		System.exit(exitCode);
	}

	@Override
	protected void configure() throws Exception {

		Configuration config = this.job.getConfiguration();
		fs = FileSystem.get(config);
		
		job.setJarByClass(getClass());
		
		timestamp = LocalDateTime.now().toString(DateTimeFormat.forPattern("yyyyMMddHHmmss"));
		
		// Chamada para configurar os Input Paths
		addInputPaths(config, job, argsDates);
		
		jobOutputPath = new Path(config.get(TraftarPosBscs9Constants.TRAFTAR_POS_BSCS9_OUTPUT));
		deleteOutputPaths(jobOutputPath);
		LOG.info("OutputPath: " + jobOutputPath.toString());
		
		FileOutputFormat.setOutputPath(job, jobOutputPath);
		LazyOutputFormat.setOutputFormatClass(job, ValueOnlyTextOutputFormat.class);
		
		job.setMapOutputKeyClass(TraftarPosBscs9JoinBdoBKey.class);
		job.setMapOutputValueClass(TraftarPosBscs9JoinBdoBValue.class);

		job.setReducerClass(TraftarPosBscs9JoinBdoBReducer.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(TraftarPosBscs9.class);
		job.setGroupingComparatorClass(TraftarPosBscs9JoinBdoBGroupingComparator.class);
		job.setSortComparatorClass(TraftarPosBscs9JoinBdoBSortComparator.class);
		job.setPartitionerClass(TraftarPosBscs9JoinBdoBPartitioner.class);

	}
	
	
	/**
	 * MÃ©todo para realizaÃ§Ã£o a limpeza dos outputPaths
	 * @param outputPath
	 * @throws IOException
	 */
	private void deleteOutputPaths(Path outputPath) throws IOException {
		if (fs.exists(outputPath)) {
			fs.delete(outputPath, true);
			LOG.info("OutputPath deleted: " + outputPath.toString());
		}
	}
	
	
	/**
	 * MÃ©todo reponsÃ¡vel por verificar os parÃ¢metros de entrada e setar os inputs
	 * @param config, job, args
	 * @throws Exception
	 */
	private void addInputPaths(Configuration config, Job job, String[] args) throws Exception {
		Entry[] entries = getInputs(config, args.length > 0);
		DriverUtils.addInputPaths(args, config, this.job, 1, entries);
	}

	/**
	 * Chamada do mÃ©todo addInputPath com as devidas configuraÃ§Ãµes de format class
	 * @throws IOException
	 */
	protected Entry[] getInputs(Configuration conf, boolean rep) throws IOException {

		Entry bscs9EntryDirectory = new Entry(TraftarPosBscs9Constants.TRAFTAR_POS_BSCS9_DIRECTORY, TraftarPosBscs9Constants.TRAFTAR_POS_BSCS9_DIRECTORY_INPUT, true, CombineTextInputFormat.class, TraftarPosBscs9Mapper.class);
		
		Entry bdoEntry = new Entry(TraftarPosBscs9Constants.BDO,
				TraftarPosBscs9Constants.BDO_FACT_INPUT, true, CombineTextInputFormat.class, BdoMapper.class);
		
		return new Entry[] {bscs9EntryDirectory, bdoEntry};
		
	}
	
	@Override
	protected void postExecutionSteps() throws Exception {
		
		Configuration conf = job.getConfiguration();
		FileSystem fs = FileSystem.get(conf);
		
		Path hiveInputPath = new Path(conf.get(TraftarPosBscs9Constants.TRAFTAR_POS_BSCS9_HIVE_INPUT), timestamp);
		
		if ( fs.exists(hiveInputPath) )
			fs.delete(hiveInputPath, true);
		
		DriverUtility.copy(fs, hiveInputPath, jobOutputPath, "part*");
		
		LOG.info("HIVE Input Extract: " + hiveInputPath.toUri());
	
		Path gpdbInputPath = new Path(conf.get(TraftarPosBscs9Constants.TRAFTAR_POS_BSCS9_GPDB_INPUT), timestamp);
		
		if ( fs.exists(gpdbInputPath) )
			fs.delete(gpdbInputPath, true);
		
		DriverUtility.move(fs, gpdbInputPath, jobOutputPath, "part*");
		
		LOG.info("GPDB Input Extract: " + gpdbInputPath.toUri());
		
	}

	
}
