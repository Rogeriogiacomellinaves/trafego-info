package br.com.tim.mapreduce.joinbdo.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.WritableComparable;

import com.google.common.base.Strings;

import br.com.tim.mapreduce.model.Bdo;
import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Regras;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.GenericParserUtility;

public class TraftarPosBscs9JoinBdoAKey implements WritableComparable<TraftarPosBscs9JoinBdoAKey> {

	private String numTelefoneA;
	private int ordem;
	
	public TraftarPosBscs9JoinBdoAKey() {
		this.clean();
	}
	
	public void clean() {
		this.numTelefoneA = CommonsConstants.EMPTY;
		this.ordem = 0;
	}
	
	public void set(Bdo bdo) {
		this.numTelefoneA = bdo.getNumeroTelefone();
		this.ordem = 1;
	}
	
	public void set(TraftarPosBscs9 traftar) {
		if ( StringUtils.isBlank(traftar.getSPNumberAddress()) ) {
			this.numTelefoneA = "DADOS" + (int) (Math.random() * 100000000);
		} else {
			this.numTelefoneA = TraftarPosBscs9Regras.getNumTelefonePagador(traftar);
		}
		this.ordem = 2;
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.numTelefoneA);
		out.writeInt(this.ordem);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.numTelefoneA = in.readUTF();
		this.ordem = in.readInt();
	}

	@Override
	public int compareTo(TraftarPosBscs9JoinBdoAKey o) {
		return GenericParserUtility.compare(this.numTelefoneA, o.numTelefoneA);
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numTelefoneA == null) ? 0 : numTelefoneA.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TraftarPosBscs9JoinBdoAKey other = (TraftarPosBscs9JoinBdoAKey) obj;
		if (numTelefoneA == null) {
			if (other.numTelefoneA != null)
				return false;
		} else if (!numTelefoneA.equals(other.numTelefoneA))
			return false;
		return true;
	}

	public String getNumTelefoneA() {
		return numTelefoneA;
	}

	public int getOrdem() {
		return ordem;
	}

}
