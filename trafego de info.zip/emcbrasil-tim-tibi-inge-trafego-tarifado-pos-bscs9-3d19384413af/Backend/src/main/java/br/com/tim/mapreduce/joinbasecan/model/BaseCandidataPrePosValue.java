package br.com.tim.mapreduce.joinbasecan.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Date;

import org.apache.calcite.avatica.proto.Common;
import org.apache.hadoop.io.Writable;

import br.com.tim.mapreduce.model.DwFBaseCandidataPrePos;
import br.com.tim.utils.CommonsConstants;

public class BaseCandidataPrePosValue implements Writable {

	private String codContratoOltp;
	private String numTelefone;
	private String skyPacote;
	private String codCicloFatOltp;
	private String flgBaseComercial;
	private Date refDate;
	private String skyPlanoTarifarioAnt;
	private String skyTipoCliente;

	private String descricaoDataCorteFatura;

	public BaseCandidataPrePosValue() {
		this.refDate = new Date();
		this.clean();
	}

	public void setFromText(String text, Long refDate) {
		String columns[] = text.split(CommonsConstants.FILE_SPLIT_REGEX, -1);

		this.codContratoOltp = columns[DwFBaseCandidataPrePos.cod_contrato_oltp.ordinal()];
		this.numTelefone = columns[DwFBaseCandidataPrePos.num_telefone.ordinal()];
		this.skyPacote = columns[DwFBaseCandidataPrePos.sky_pacote.ordinal()];
		this.codCicloFatOltp = columns[DwFBaseCandidataPrePos.cod_ciclo_fat_oltp.ordinal()];
		this.flgBaseComercial = columns[DwFBaseCandidataPrePos.flg_base_comercial.ordinal()];
		this.refDate.setTime(refDate);
		this.skyPlanoTarifarioAnt = columns[DwFBaseCandidataPrePos.sky_plano_tarifario_ant.ordinal()];
		this.skyTipoCliente = columns[DwFBaseCandidataPrePos.sky_tipo_cliente.ordinal()];
	}

	public void clean() {
		this.codContratoOltp = CommonsConstants.EMPTY;
		this.numTelefone = CommonsConstants.EMPTY;
		this.skyPacote = CommonsConstants.EMPTY;
		this.codCicloFatOltp = CommonsConstants.EMPTY;
		this.flgBaseComercial = CommonsConstants.EMPTY;
		this.refDate.setTime(0L);
		this.skyPlanoTarifarioAnt = CommonsConstants.EMPTY;
		this.descricaoDataCorteFatura = CommonsConstants.EMPTY;
		this.skyTipoCliente = CommonsConstants.EMPTY;
	}

	public void clone(BaseCandidataPrePosValue o) {
		this.codContratoOltp = o.codContratoOltp;
		this.numTelefone = o.numTelefone;
		this.skyPacote = o.skyPacote;
		this.codCicloFatOltp = o.codCicloFatOltp;
		this.flgBaseComercial = o.flgBaseComercial;
		this.refDate.setTime(o.refDate.getTime());
		this.skyPlanoTarifarioAnt = o.skyPlanoTarifarioAnt;
		this.descricaoDataCorteFatura = o.descricaoDataCorteFatura;
		this.skyTipoCliente = o.skyTipoCliente;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(codContratoOltp);
		out.writeUTF(numTelefone);
		out.writeUTF(skyPacote);
		out.writeUTF(codCicloFatOltp);
		out.writeUTF(flgBaseComercial);
		out.writeLong(refDate.getTime());
		out.writeUTF(skyPlanoTarifarioAnt);
		out.writeUTF(descricaoDataCorteFatura);
		out.writeUTF(skyTipoCliente);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.codContratoOltp = in.readUTF();
		this.numTelefone = in.readUTF();
		this.skyPacote = in.readUTF();
		this.codCicloFatOltp = in.readUTF();
		this.flgBaseComercial = in.readUTF();
		this.refDate.setTime(in.readLong());
		this.skyPlanoTarifarioAnt = in.readUTF();
		this.descricaoDataCorteFatura = in.readUTF();
		this.skyTipoCliente = in.readUTF();
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public String getNumTelefone() {
		return numTelefone;
	}

	public String getSkyPacote() {
		return skyPacote;
	}

	public String getCodCicloFatOltp() {
		return codCicloFatOltp;
	}

	public String getFlgBaseComercial() {
		return flgBaseComercial;
	}

	public Date getRefDate() {
		return refDate;
	}

	public String getSkyPlanoTarifarioAnt() {
		return skyPlanoTarifarioAnt;
	}

	public void setSkyPlanoTarifarioAnt(String skyPlanoTarifarioAnt) {
		this.skyPlanoTarifarioAnt = skyPlanoTarifarioAnt;
	}

	public String getDescricaoDataCorteFatura() {
		return descricaoDataCorteFatura;
	}

	public void setDescricaoDataCorteFatura(String descricaoDataCorteFatura) {
		this.descricaoDataCorteFatura = descricaoDataCorteFatura;
	}

	public String getSkyTipoCliente() {
		return skyTipoCliente;
	}

	public void setSkyTipoCliente(String skyTipoCliente) {
		this.skyTipoCliente = skyTipoCliente;
	}

}
