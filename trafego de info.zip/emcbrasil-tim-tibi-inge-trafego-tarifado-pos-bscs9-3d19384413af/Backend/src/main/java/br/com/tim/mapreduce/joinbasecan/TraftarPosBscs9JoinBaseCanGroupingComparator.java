package br.com.tim.mapreduce.joinbasecan;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import br.com.tim.mapreduce.joinbasecan.model.TraftarPosBscs9JoinBaseCanKey;

public class TraftarPosBscs9JoinBaseCanGroupingComparator extends WritableComparator {

	public TraftarPosBscs9JoinBaseCanGroupingComparator	() {
        super(TraftarPosBscs9JoinBaseCanKey.class, true);
    }
	
	@SuppressWarnings("rawtypes")
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		TraftarPosBscs9JoinBaseCanKey key1 = (TraftarPosBscs9JoinBaseCanKey) a;
		TraftarPosBscs9JoinBaseCanKey key2 = (TraftarPosBscs9JoinBaseCanKey) b;
		
		return key1.compareTo(key2);
	}

}
