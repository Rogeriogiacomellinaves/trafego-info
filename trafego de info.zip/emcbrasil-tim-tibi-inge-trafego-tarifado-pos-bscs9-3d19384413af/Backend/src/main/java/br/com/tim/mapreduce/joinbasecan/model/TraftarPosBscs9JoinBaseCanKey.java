package br.com.tim.mapreduce.joinbasecan.model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

import br.com.tim.mapreduce.model.TraftarPosBscs9;
import br.com.tim.utils.CommonsConstants;
import br.com.tim.utils.GenericParserUtility;

public class TraftarPosBscs9JoinBaseCanKey implements WritableComparable<TraftarPosBscs9JoinBaseCanKey> {

	private String codContratoOltp;
	private int ordem;
	
	public TraftarPosBscs9JoinBaseCanKey() {
		this.clean();
	}
	
	public void set(BaseCandidataPrePosValue base) {
		this.codContratoOltp = base.getCodContratoOltp();
		this.ordem = 1;
	}
	
	public void set(TraftarPosBscs9 traftar) {
		this.codContratoOltp = traftar.getCustInfoContractId();
		this.ordem = 2;
	}
	
	public void clean() {
		this.codContratoOltp = CommonsConstants.EMPTY;
		this.ordem = 0;
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.codContratoOltp);
		out.writeInt(this.ordem);
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		this.codContratoOltp = in.readUTF();
		this.ordem = in.readInt();
	}
	
	@Override
	public int compareTo(TraftarPosBscs9JoinBaseCanKey o) {
		return GenericParserUtility.compare(this.codContratoOltp, o.codContratoOltp);
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codContratoOltp == null) ? 0 : codContratoOltp.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TraftarPosBscs9JoinBaseCanKey other = (TraftarPosBscs9JoinBaseCanKey) obj;
		if (codContratoOltp == null) {
			if (other.codContratoOltp != null)
				return false;
		} else if (!codContratoOltp.equals(other.codContratoOltp))
			return false;
		return true;
	}

	public String getCodContratoOltp() {
		return codContratoOltp;
	}

	public int getOrdem() {
		return ordem;
	}
	
}
