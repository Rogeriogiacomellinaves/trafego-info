package br.com.tim.mapreduce.finders;

import br.com.tim.driverutils.DriverUtils;
import br.com.tim.exception.CommonsException;
import br.com.tim.mapreduce.model.CecCicloFaturamento;
import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.model.PlanoTarifario;
import br.com.tim.utils.CachedFile;
import br.com.tim.utils.SequenceCachedFile;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CecCicloFaturamentoFinder {

	private static CecCicloFaturamentoFinder finder;

	private static final String TIM_BRASIL_VENC_DIA_20 = "TIM BRASIL - VENC. DIA 20 - CP";
	private static final String TIM_BRASIL_VENCI_DIA_07 = "TIM BRASIL - VENC. DIA 07 - CS";

	@SuppressWarnings("rawtypes")
	public static synchronized CecCicloFaturamentoFinder getInstance(Configuration conf) {
		if ( null == finder )
			return new CecCicloFaturamentoFinder(conf);
		return finder;
	}

	private static List< CecCicloFaturamento > list;
	private static CecCicloFaturamento searchKey;

	public class CecCicloFaturamentoComparator implements Comparator<CecCicloFaturamento> {
		@Override
		public int compare( CecCicloFaturamento o1, CecCicloFaturamento o2 ) {
			int r =  o1.getIdentificadorCicloFaturamento().compareTo(o2.getIdentificadorCicloFaturamento());
			return r;
		}
	}

	private static CecCicloFaturamentoComparator comparator;

	private void loadCachedFile(Configuration conf) throws IllegalArgumentException, CommonsException {
		list = SequenceCachedFile.getSequenceFileAsObjectList(
				conf,
				DriverUtils.getAuxiliaryPath(conf, TraftarPosBscs9Constants.CEC_CICLO_FATURAMENTO_INPUT).toString(),
				false,
				CecCicloFaturamento.class );
	}

	@SuppressWarnings("rawtypes")
	public CecCicloFaturamentoFinder(Configuration conf ) {
		searchKey = new CecCicloFaturamento();
		comparator = new CecCicloFaturamentoComparator();
		
		try {
			loadCachedFile(conf);
		} catch ( IllegalArgumentException | CommonsException e ) {
			throw new RuntimeException( e );
		}
		
		Collections.sort( list, comparator );
	}
	
	public CecCicloFaturamento find(String numCicloFaturamento) {
		searchKey.setIdentificadorCicloFaturamento(numCicloFaturamento);
		CecCicloFaturamento found = null;
		
		if ( list.size() == 0 ) return null;
		
		int pos = Collections.binarySearch( list, searchKey, comparator );

		if (pos >= 0) {
			found = list.get(pos);

			if (StringUtils.isNotBlank(found.getDescricaoCicloFaturamento()) &&
					(found.getDescricaoCicloFaturamento().contains(TIM_BRASIL_VENC_DIA_20) ||
							found.getDescricaoCicloFaturamento().contains(TIM_BRASIL_VENCI_DIA_07)))
				return found;
		}

		return null;
	}
	
}
