package br.com.tim.inge.trafegotarifado.model;

import java.io.DataInput;

import java.io.DataOutput;

import java.io.IOException;

import java.text.ParseException;

import java.util.Date;

import br.com.tim.mapreduce.utils.TraftarPosBscs9Constants;
import br.com.tim.utils.CommonsConstants;

/**
 * 
 * Utilizar classe br.com.tim.mapreduce.model.TraftarPosBscs9
 *
 */
@Deprecated
public class TraftarBscs9 implements TraftarBscs {

	public String num_rowid_ogg;

	public String cod_ogg;

	public String tpo_operacao_ogg;

	public String dat_ogg;

	public String nom_sistema_ogg;

	public String nom_interface_ogg;

	public String aggreg_info_aggreg_purpose;

	public String aggreg_info_agg_trans_id;

	public String aggreg_info_applied_pack_id;

	public String aggreg_info_rec_counter;

	public String aggreg_info_summary_id;

	public String alt_rated_amount;

	public String alt_rated_currency;

	public String alt_tariff_clicks_volume;

	public String alt_tmcode;

	public String an_pack_an_package_id_list;

	public String an_pack_orig_an_pack_id_list;

	public String bal_audit_data_account_id;

	public String bal_audit_data_account_type;

	public String bal_audit_data_account_type_id;

	public String bal_audit_dat_balance_accum;

	public String bal_audit_dat_balance_prod_id;

	public String bal_audit_dat_balance_type;

	public String bal_audit_dat_bal_after_chg;

	public String bal_audit_dat_bal_before_chg;

	public String bal_audit_dat_bundl_prod_id;

	public String bal_audit_dat_contract_id;

	public String bal_audit_dat_offer_seqno;

	public String bal_audit_dat_offer_sncode;

	public String bal_audit_dat_prep_credit_ind;

	public String bal_audit_dat_purchase_seq_no;

	public String bal_audit_dat_shacc_packid;

	public String bal_audit_dat_user_profile_id;

	public String bop_info_bop_package_id;

	public String bop_info_bop_package_pkey;

	public String bop_info_bop_package_version;

	public String bop_info_detail_billed_ind;

	public String bop_info_detail_bop_altern_ind;

	public String bop_info_detail_contracted_ind;

	public String bop_info_detail_sequence_rp;

	public String bop_info_detail_sequence_sp;

	public String bop_tariff_info_day_catcode;

	public String bop_tariff_info_egcode;

	public String bop_tariff_info_egversion;

	public String bop_tariff_info_gvcode;

	public String bop_tariff_info_rpcode;

	public String bop_tariff_info_rpversion;

	public String bop_tariff_info_sncode;

	public String bop_tariff_info_spcode;

	public String bop_tariff_info_time_band_code;

	public String bop_tariff_info_tmcode;

	public String bop_tariff_info_tmversion;

	public String bop_tariff_info_tm_used_type;

	public String bop_tariff_info_twcode;

	public String bop_tariff_info_usage_ind;

	public String bop_tariff_info_zncode;

	public String bop_tariff_info_zpcode;

	public String bpartn_sum_info_time_slice_lb;

	public String bpartn_sum_info_time_slice_rb;

	public String bundle_info_bundle_purchase_id;

	public String bundle_info_bundle_purch_ind;

	public String bundle_info_contract_id;

	public String bundle_info_purchase_seq_no;

	public String bundle_info_sequence_number;

	public String bundle_info_sncode;

	public String bundle_info_state;

	public String bundle_info_termination;

	public String bundle_info_user_profile_id;

	public String bundle_info_valid_from;

	public String bundle_info_valid_to;

	public String bundle_info_version;

	public String bundle_usg_bundle_covered_usg;

	public String business_info_bs_id;

	public String business_info_bs_version;

	public String business_info_charge_item_id;

	public String business_info_charge_party_id;

	public String business_info_c_p_field_ref;

	public String business_info_o_p_field_ref;

	public String business_info_pre_bs_id;

	public String business_info_pre_bs_version;

	public String bus_partner_info_tax_mode;

	public String call_dest;

	public String call_type;

	public String camel_dest_addr_user_prof_id;

	public String camel_msc_address;

	public String camel_msc_addr_user_prof_id;

	public String camel_reference_number;

	public String camel_srv_addr_user_prof_id;

	public String charge_info_cash_flow_direct;

	public String charge_info_disable_tax;

	public String charging_characteristics;

	public String consumer_info_address;

	public String consumer_info_contract_id;

	public String consumer_info_numbering_plan;

	public String content_advised_charge_ind;

	public String content_authorisation_code;

	public String content_content_charging_point;

	public String content_contract_pkey;

	public String content_desc_suppress;

	public String content_paid_ind;

	public String content_payment_method;

	public String content_provider_address;

	public String content_provider_carrier_code;

	public String content_provider_clir;

	public String content_provider_iac;

	public String content_provider_modif_ind;

	public String content_provider_network_code;

	public String content_provid_dynamic_address;

	public String content_provid_local_pref_len;

	public String content_provid_numbering_plan;

	public String content_provid_other_location;

	public String content_provid_type_of_number;

	public String content_provid_user_profile_id;

	public String content_refund_ind;

	public String content_short_desc;

	public String content_transaction_id;

	public String control_data_record_age;

	public String cug_info_cug_id;

	public String cug_info_cug_index;

	public String customer_info_contract_type_id;

	public String customer_info_contraggrpack_id;

	public String customer_info_reco_ind;

	public String cust_info_address;

	public String cust_info_alternate_tmcode;

	public String cust_info_an_package_id_list;

	public String cust_info_bill_cycle;

	public String cust_info_bu_address;

	public String cust_info_bu_numbering_plan;

	public String cust_info_charging_engine;

	public String cust_info_contract_id;

	public String cust_info_customer_id;

	public String cust_info_delete_after_billing;

	public String cust_info_dn_id;

	public String cust_info_main_msisdn;

	public String cust_info_numbering_plan;

	public String cust_info_port_id;

	public String cust_info_serv_bid_id;

	public String cust_info_sim_number;

	public String cust_info_sim_sernumber;

	public String cust_info_subs_code;

	public String cust_info_subs_tag;

	public String cust_info_user_profile_id;

	public String data_volume;

	public String data_volume_umcode;

	public String desc_prod_usage_long_desc;

	public String destination_field_id;

	public String downlink_volume_umcode;

	public String downlink_volume_volume;

	public String duration_umcode;

	public String duration_volume;

	public String entry_date_offset;

	public String entry_date_timestamp;

	public String event_info_event_type;

	public String event_status_info_message_id;

	public String event_umcode;

	public String event_volume;

	public String export_file;

	public String ext_balance_amnt_amount;

	public String follow_up_call_type;

	public String for_amount_amount;

	public String for_amount_currency;

	public String for_amount_gross_ind;

	public String for_amount_tax;

	public String for_freechrg_amount;

	public String for_freechrg_currency;

	public String for_freechrg_gross_ind;

	public String for_freechrg_tax;

	public String free_charge_amount;

	public String free_charge_amount_non_rpc;

	public String free_charge_currency;

	public String free_charge_curr_non_rpc;

	public String free_charge_gross_ind;

	public String free_charge_gross_ind_nrpc;

	public String free_charge_tax;

	public String free_charge_tax_nrpc;

	public String free_clicks_umcode;

	public String free_clicks_volume;

	public String free_rated_volume_umcode;

	public String free_rated_volume_volume;

	public String free_rounded_volume_umcode;

	public String free_rounded_volume_volume;

	public String free_units_info_account_key;

	public String free_units_info_account_origin;

	public String free_units_info_acc_hist_id;

	public String free_units_info_appl_method;

	public String free_units_info_chg_red_quota;

	public String free_units_info_discount_rate;

	public String free_units_info_discount_type;

	public String free_units_info_freeunitoption;

	public String free_units_info_fup_seq;

	public String free_units_info_fu_pack_id;

	public String free_units_info_part_creator;

	public String free_units_info_previous_seqno;

	public String free_units_info_seqno;

	public String free_units_info_version;

	public String home_network_code;

	public String hscsd_info_aiur;

	public String hscsd_info_channels_max;

	public String hscsd_info_channels_used;

	public String hscsd_info_coding_acc;

	public String hscsd_info_coding_used;

	public String hscsd_info_fnur;

	public String hscsd_info_init_party;

	public String imp_party1_address;

	public String imp_party1_alternate_tmcode;

	public String imp_party1_an_package_id_list;

	public String imp_party1_bill_cycle;

	public String imp_party1_numbering_plan;

	public String imp_party1_user_profile_id;

	public String imp_party2_address;

	public String imp_party2_alternate_tmcode;

	public String imp_party2_an_package_id_list;

	public String imp_party2_bill_cycle;

	public String imp_party2_numbering_plan;

	public String imp_party2_user_profile_id;

	public String imp_party3_address;

	public String imp_party3_alternate_tmcode;

	public String imp_party3_an_package_id_list;

	public String imp_party3_bill_cycle;

	public String imp_party3_numbering_plan;

	public String imp_party3_user_profile_id;

	public String imp_party4_address;

	public String imp_party4_alternate_tmcode;

	public String imp_party4_an_package_id_list;

	public String imp_party4_bill_cycle;

	public String imp_party4_numbering_plan;

	public String imp_party4_parent_contract_id;

	public String imp_party4_user_profile_id;

	public String imp_party5_address;

	public String imp_party5_alternate_tmcode;

	public String imp_party5_an_package_id_list;

	public String imp_party5_bill_cycle;

	public String imp_party5_numbering_plan;

	public String imp_party5_parent_contract_id;

	public String imp_party5_user_profile_id;

	public String initial_start_time_timestamp;

	public String initial_start_time_time_offset;

	public String lcs_qos_deliv_horizontal_accur;

	public String lcs_qos_deliv_tracking_frequen;

	public String lcs_qos_deliv_tracking_period;

	public String lcs_qos_deliv_vertical_accur;

	public String lcs_qos_info_age_of_location;

	public String lcs_qos_info_position_method;

	public String lcs_qos_info_response_time;

	public String lcs_qos_info_response_time_cat;

	public String lcs_qos_req_horizontal_accur;

	public String lcs_qos_req_tracking_frequency;

	public String lcs_qos_req_tracking_period;

	public String lcs_qos_req_vertical_accur;

	public String ldc_info_carrier_code;

	public String ldc_info_contract_pkey;

	public String ldc_info_home_net_ind;

	public String lec_info_contract_pkey;

	public String lec_info_home_net_ind;

	public String lzlist;

	public String mc_info_code;

	public String mc_info_ind;

	public String mc_info_micro_cell_information;

	public String mc_scalefactor;

	public String messages_umcode;

	public String messages_volume;

	public String micro_cell_imcscalefactortype;

	public String micro_cell_mc_code;

	public String micro_cell_mc_pkey;

	public String micro_cell_mc_type;

	public String micro_cell_scalefactor;

	public String network_init_context_ind;

	public String net_element_home_bid_id;

	public String net_element_network_code;

	public String net_element_netw_element_id;

	public String net_element_user_profile_id;

	public String normed_net_elem_address;

	public String normed_net_elem_int_acc_code;

	public String normed_net_elem_number_plan;

	public String normed_rtd_num_address;

	public String normed_rtd_num_int_acc_code;

	public String normed_rtd_num_number_plan;

	public String normtrkgrp_in_address;

	public String normtrkgrp_in_numberingplan;

	public String normtrkgrp_out_address;

	public String normtrkgrp_out_numberingplan;

	public String number_of_rejections;

	public String offer_offer_seqno;

	public String offer_offer_sncode;

	public String origin_field_id;

	public String orig_entry_date_timestamp;

	public String orig_entry_date_timezone_id;

	public String orig_entry_date_timezone_pkey;

	public String orig_entry_date_time_offset;

	public String or_flag;

	public String o_p_normed_num_address;

	public String o_p_normed_num_int_acc_code;

	public String o_p_normed_num_number_plan;

	public String o_p_number_address;

	public String o_p_number_backup_address;

	public String o_p_number_carrier_code;

	public String o_p_number_clir;

	public String o_p_number_numbering_plan;

	public String o_p_number_other_location;

	public String o_p_number_type_of_number;

	public String o_p_number_user_profile_id;

	public String o_p_pubid_address;

	public String o_p_pubid_numbering_plan;

	public String o_p_pubid_type_of_number;

	public String price_plan_info_chrgplanid;

	public String price_plan_info_evalquantity;

	public String price_plan_info_threshold;

	public String promo_info_b_number_cat;

	public String qos_negot_delay;

	public String qos_negot_mean_throughput;

	public String qos_negot_peak_throughput;

	public String qos_negot_precedence;

	public String qos_negot_reliability;

	public String qos_profile;

	public String qos_req_delay;

	public String qos_req_mean_throughput;

	public String qos_req_peak_throughput;

	public String qos_req_precedence;

	public String qos_req_reliability;

	public String rated_clicks_umcode;

	public String rated_clicks_volume;

	public String rated_flat_amnt_gross_ind_nrpc;

	public String rated_flat_amnt_orig_currency;

	public String rated_flat_amnt_orig_gross_ind;

	public String rated_flat_amnt_tax_nrpc;

	public String rated_flat_amount;

	public String rated_flat_amount_currency;

	public String rated_flat_amount_gross_ind;

	public String rated_flat_amount_non_rpc;

	public String rated_flat_amount_non_rpc_curr;

	public String rated_flat_amount_orig_amount;

	public String rated_flat_amount_orig_tax;

	public String rated_flat_amount_tax;

	public String rated_volume;

	public String rated_volume_umcode;

	public String recipient_net_address;

	public String recipient_net_numbering_plan;

	public String record_id_call_id;

	public String record_id_cdr_id;

	public String record_id_cdr_sub_id;

	public String record_id_event_ref;

	public String record_id_orig_cdr_id;

	public String record_id_rap_sequence_num;

	public String record_id_rerate_seqno;

	public String record_id_shaacc_unique_id;

	public String record_id_tap_sequence_num;

	public String record_id_udr_file_id;

	public String record_type_record_category;

	public String record_type_summary_ind;

	public String refer_contr_contract_id;

	public String refer_contr_reference_type;

	public String rejected_base_part;

	public String reject_reason_code;

	public String remark;

	public String rerate_info_rerate_reason_id;

	public String rerate_info_rerate_record_type;

	public String rerate_info_rerate_request_id;

	public String rerate_info_urh_id;

	public String rounded_volume;

	public String rounded_volume_umcode;

	public String routing_network_code;

	public String routing_number_backup_address;

	public String routing_user_profile_id;

	public String scu_id_address;

	public String scu_id_user_profile_id;

	public String scu_info_priority_code;

	public String service_action_code;

	public String service_guaranteed_bit_rate;

	public String service_hscsd_ind;

	public String service_ims_signalling_context;

	public String service_logic_code;

	public String service_max_bit_rate;

	public String service_service_type;

	public String service_used_service;

	public String service_user_protocol_ind;

	public String service_vas_code;

	public String serv_pdp_addr_apn_split_ind;

	public String sgsn_addresses;

	public String spec_num_info_apply_free_units;

	public String start_time_charge_offset;

	public String start_time_charge_timestamp;

	public String start_time_offset;

	public String start_time_timestamp;

	public String sum_reference_single_id;

	public String s_pdp_address;

	public String s_pdp_carrier_code;

	public String s_pdp_clir;

	public String s_pdp_intern_access_code;

	public String s_pdp_modification_ind;

	public String s_pdp_network_code;

	public String s_pdp_numbering_plan;

	public String s_pdp_type_of_number;

	public String s_pdp_user_profile_id;

	public String s_p_equipment_class_mark;

	public String s_p_equipment_number;

	public String s_p_home_id_description;

	public String s_p_home_id_home_bid_id;

	public String s_p_home_id_name;

	public String s_p_home_id_network;

	public String s_p_home_loc_address;

	public String s_p_home_loc_numbering_plan;

	public String s_p_location_address;

	public String s_p_location_numbering_plan;

	public String s_p_loc_serving_bid_id;

	public String s_p_loc_serving_location;

	public String s_p_number_address;

	public String s_p_number_home_bid_id;

	public String s_p_number_network_code;

	public String s_p_number_numbering_plan;

	public String s_p_number_user_profile_id;

	public String s_p_port_address;

	public String s_p_port_numbering_plan;

	public String s_p_port_user_profile_id;

	public String tariff_detail_chgbl_quantity;

	public String tariff_detail_ext_chrg_udmcode;

	public String tariff_detail_interconnect_ind;

	public String tariff_detail_rate_type_id;

	public String tariff_detail_rtx_charge_type;

	public String tariff_detail_ttcode;

	public String tariff_info_catalogue_id;

	public String tariff_info_catalogue_vers;

	public String tariff_info_ctlg_elm_id;

	public String tariff_info_egcode;

	public String tariff_info_egversion;

	public String tariff_info_gvcode;

	public String tariff_info_pricelist_id;

	public String tariff_info_pricelist_pkey;

	public String tariff_info_pricelist_vers;

	public String tariff_info_price_def_vers;

	public String tariff_info_rpcode;

	public String tariff_info_rpversion;

	public String tariff_info_sncode;

	public String tariff_info_spcode;

	public String tariff_info_time_band_code;

	public String tariff_info_tmcode;

	public String tariff_info_tmversion;

	public String tariff_info_tm_used_type;

	public String tariff_info_twcode;

	public String tariff_info_usage_ind;

	public String tariff_info_zncode;

	public String tariff_info_zpcode;

	public String tariff_info_zpcode_day_catcode;

	public String tax_info_serv_cat;

	public String tax_info_serv_code;

	public String tax_info_serv_type;

	public String techn_info_fixed_mobile_ind;

	public String techn_info_home_terminated_ind;

	public String techn_info_prepay_ind;

	public String techn_info_pre_rated_ind;

	public String techn_info_rev_charging_ind;

	public String techn_info_sccode;

	public String techn_info_termination_ind;

	public String trunk_group_in_address;

	public String trunk_group_in_numberingplan;

	public String trunk_group_in_typeofnumber;

	public String trunk_group_out_address;

	public String trunk_group_out_numberingplan;

	public String trunk_group_out_typeofnumber;

	public String t_p_number_user_profile_id;

	public String udr_basepart_id;

	public String udr_chargepart_id;

	public String uds_base_part_id;

	public String uds_charge_part_id;

	public String uds_free_unit_part_id;

	public String uds_promotion_part_id;

	public String uds_record_id;

	public String uds_stream_id;

	public String umts_qos_negot_allc_retn_prior;

	public String umts_qos_negot_delay;

	public String umts_qos_negot_delivery_order;

	public String umts_qos_negot_erroneous_sdus;

	public String umts_qos_negot_handl_priority;

	public String umts_qos_negot_max_size_sdu;

	public String umts_qos_negot_rate_downlink;

	public String umts_qos_negot_rate_uplink;

	public String umts_qos_negot_residual_ber;

	public String umts_qos_negot_sdu_err_ratio;

	public String umts_qos_negot_traffic_class;

	public String umts_qos_req_allc_retn_prior;

	public String umts_qos_req_delay;

	public String umts_qos_req_delivery_order;

	public String umts_qos_req_erroneous_sdus;

	public String umts_qos_req_handl_priority;

	public String umts_qos_req_max_size_sdu;

	public String umts_qos_req_rate_downlink;

	public String umts_qos_req_rate_uplink;

	public String umts_qos_req_residual_ber;

	public String umts_qos_req_sdu_error_ratio;

	public String umts_qos_req_traffic_class;

	public String unbilledamtpaymresp_customerid;

	public String unbilled_amount_amount;

	public String unbilled_amount_currency;

	public String unbilled_amount_gross_ind;

	public String unbilled_amount_tax;

	public String uplink_volume_umcode;

	public String uplink_volume_volume;

	public String vpn_info_vpn_call_type;

	public String vpn_number_address;

	public String vpn_number_carrier_code;

	public String vpn_number_clir;

	public String vpn_number_dynamic_address;

	public String vpn_number_int_access_code;

	public String vpn_number_local_prefix_len;

	public String vpn_number_modification_ind;

	public String vpn_number_network_code;

	public String vpn_number_numbering_plan;

	public String vpn_number_type_of_number;

	public String vpn_number_user_profile_id;

	public String xfile_base_charge_amount;

	public String xfile_base_charge_currency;

	public String xfile_base_charge_gross_ind;

	public String xfile_base_charge_tax;

	public String xfile_call_type;

	public String xfile_charge_amount;

	public String xfile_charge_currency;

	public String xfile_charge_gross_ind;

	public String xfile_charge_tax;

	public String xfile_day_category_code;

	public String xfile_discount_amount;

	public String xfile_discount_currency;

	public String xfile_ic_charge_amount;

	public String xfile_ic_charge_currency;

	public String xfile_ic_charge_gross_ind;

	public String xfile_ic_charge_tax;

	public String xfile_ind;

	public String xfile_time_band_code;

	public String zero_rated_volume_umcode;

	public String zero_rated_volume_volume;

	public String zero_rounded_volume_umcode;

	public String zero_rounded_volume_volume;

	public String bal_audit_dat_valid_from;

	public String bal_audit_dat_valid_to;

	public String chrgaggrinfo_request_id;

	public String cust_info_customer_group;

	public String cust_info_parent_contract_id;

	public String imp_party1_parent_contract_id;

	public String imp_party2_parent_contract_id;

	public String imp_party3_parent_contract_id;

	public String net_element_address;

	public String net_element_numbering_plan;

	public String net_element_type_of_number;

	public String rated_flat_amnt_orig_disc_amnt;

	public String rated_flat_amount_disc_amount;

	public String reject_filter_id;

	public String routing_address;

	public String routing_numbering_plan;

	public String routing_type_of_number;

	public String tariff_detail_pricgalternpkey;

	public String tariff_detail_pricingalternid;

	public String t_p_number_address;

	public String t_p_number_numbering_plan;

	public String t_p_number_type_of_number;

	public String unbilled_amount_billing_acc;

	public String unbilled_amount_compl_cond_id;

	public String entry_date_sim_offset;

	public String entry_date_sim_timestamp;

	public String fu_pack_id_clone;

	public String micro_cell_mc_shdes;

	public String o_p_number_anonym_ind;

	public String o_p_subs_address;

	public String o_p_subs_carrier_code;

	public String o_p_subs_clir;

	public String o_p_subs_dynamic_address;

	public String o_p_subs_iac;

	public String o_p_subs_local_prefix_len;

	public String o_p_subs_modification_ind;

	public String o_p_subs_network_code;

	public String o_p_subs_numbering_plan;

	public String o_p_subs_type_of_number;

	public String record_id_ext_call_id;

	public String record_id_ext_file_id;

	public String redirected_address;

	public String redirected_carrier_code;

	public String redirected_clir;

	public String redirected_dynamic_address;

	public String redirected_iac;

	public String redirected_local_prefix_len;

	public String redirected_modification_ind;

	public String redirected_network_code;

	public String redirected_numbering_plan;

	public String redirected_type_of_number;

	public String srvcode;

	public String start_time_original_offset;

	public String start_time_original_time;

	public String s_p_location_area_code;

	public String tariff_info_zodes;

	public String tariff_info_zpdes;

	public String techn_info_call_nature;

	public String techn_info_charged_party;

	public String techn_info_lng_dist_carrier_cd;

	public String translated_address;

	public String translated_carrier_code;

	public String translated_clir;

	public String translated_dynamic_address;

	public String translated_iac;

	public String translated_local_prefix_len;

	public String translated_modification_ind;

	public String translated_network_code;

	public String translated_numbering_plan;

	public String translated_type_of_number;

	public String valid_from_smart_bberry;

	public String valid_from_smart_dsl;

	public String valid_from_smart_sms;

	public String valid_from_smart_web;

	public String xfile_charge_roam_scenario_id;

	public String xfile_charge_umcode;

	public String xfile_charge_volume;

	public String late_call_config_id;

	public String late_call_expiration_date;

	public String late_call_grace_time;

	public String mcprincing_value;

	public String mc_balance;

	public String mc_fup_indicator;

	public String mc_limited;

	public String mc_original_amount;

	public String mc_pricing_mech;

	public String mc_used_units;

	public String load_date_offset;

	public String load_date_timestamp;

	public String record_id_uct_ctrl;

	public String cob_type2_a_party_type;

	public String cob_type2_b_party_type;

	public String cob_type2_callnature;

	public String cob_type2_cnl_a_party;

	public String cob_type2_cnl_b_party;

	public String cob_type2_eot_a;

	public String cob_type2_eot_b;

	public String cob_type2_onnet_ind;

	public String cob_type2_originidentification;

	public String cob_type2_recordtype;

	public String cob_type2_tfi;

	public String imp2_valid_from_smart_bberry;

	public String imp2_valid_from_smart_dsl;

	public String imp2_valid_from_smart_sms;

	public String imp2_valid_from_smart_web;

	public String imp_party1_comm_name_1;

	public String imp_party1_comm_spec_rate_1;

	public String imp_party1_comm_spec_rate_2;

	public String imp_party2_comm_name_1;

	public String imp_party2_comm_spec_rate_1;

	public String imp_party2_comm_spec_rate_2;

	public String rated_flat_amnt_orig_mc_amnt;

	public String s_p_number_translated_address;

	public String row_id;

	public String loteid;

	public String arquivo;

	public String arquivots;

	public String currentdate;

	private static StringBuilder sb = new StringBuilder();

	public TraftarBscs9() {

		clean();

	}

	public void clean() {

		this.num_rowid_ogg = CommonsConstants.EMPTY;

		this.cod_ogg = CommonsConstants.EMPTY;

		this.tpo_operacao_ogg = CommonsConstants.EMPTY;

		this.dat_ogg = CommonsConstants.EMPTY;

		this.nom_sistema_ogg = CommonsConstants.EMPTY;

		this.nom_interface_ogg = CommonsConstants.EMPTY;

		this.aggreg_info_aggreg_purpose = CommonsConstants.EMPTY;

		this.aggreg_info_agg_trans_id = CommonsConstants.EMPTY;

		this.aggreg_info_applied_pack_id = CommonsConstants.EMPTY;

		this.aggreg_info_rec_counter = CommonsConstants.EMPTY;

		this.aggreg_info_summary_id = CommonsConstants.EMPTY;

		this.alt_rated_amount = CommonsConstants.EMPTY;

		this.alt_rated_currency = CommonsConstants.EMPTY;

		this.alt_tariff_clicks_volume = CommonsConstants.EMPTY;

		this.alt_tmcode = CommonsConstants.EMPTY;

		this.an_pack_an_package_id_list = CommonsConstants.EMPTY;

		this.an_pack_orig_an_pack_id_list = CommonsConstants.EMPTY;

		this.bal_audit_data_account_id = CommonsConstants.EMPTY;

		this.bal_audit_data_account_type = CommonsConstants.EMPTY;

		this.bal_audit_data_account_type_id = CommonsConstants.EMPTY;

		this.bal_audit_dat_balance_accum = CommonsConstants.EMPTY;

		this.bal_audit_dat_balance_prod_id = CommonsConstants.EMPTY;

		this.bal_audit_dat_balance_type = CommonsConstants.EMPTY;

		this.bal_audit_dat_bal_after_chg = CommonsConstants.EMPTY;

		this.bal_audit_dat_bal_before_chg = CommonsConstants.EMPTY;

		this.bal_audit_dat_bundl_prod_id = CommonsConstants.EMPTY;

		this.bal_audit_dat_contract_id = CommonsConstants.EMPTY;

		this.bal_audit_dat_offer_seqno = CommonsConstants.EMPTY;

		this.bal_audit_dat_offer_sncode = CommonsConstants.EMPTY;

		this.bal_audit_dat_prep_credit_ind = CommonsConstants.EMPTY;

		this.bal_audit_dat_purchase_seq_no = CommonsConstants.EMPTY;

		this.bal_audit_dat_shacc_packid = CommonsConstants.EMPTY;

		this.bal_audit_dat_user_profile_id = CommonsConstants.EMPTY;

		this.bop_info_bop_package_id = CommonsConstants.EMPTY;

		this.bop_info_bop_package_pkey = CommonsConstants.EMPTY;

		this.bop_info_bop_package_version = CommonsConstants.EMPTY;

		this.bop_info_detail_billed_ind = CommonsConstants.EMPTY;

		this.bop_info_detail_bop_altern_ind = CommonsConstants.EMPTY;

		this.bop_info_detail_contracted_ind = CommonsConstants.EMPTY;

		this.bop_info_detail_sequence_rp = CommonsConstants.EMPTY;

		this.bop_info_detail_sequence_sp = CommonsConstants.EMPTY;

		this.bop_tariff_info_day_catcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_egcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_egversion = CommonsConstants.EMPTY;

		this.bop_tariff_info_gvcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_rpcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_rpversion = CommonsConstants.EMPTY;

		this.bop_tariff_info_sncode = CommonsConstants.EMPTY;

		this.bop_tariff_info_spcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_time_band_code = CommonsConstants.EMPTY;

		this.bop_tariff_info_tmcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_tmversion = CommonsConstants.EMPTY;

		this.bop_tariff_info_tm_used_type = CommonsConstants.EMPTY;

		this.bop_tariff_info_twcode = CommonsConstants.EMPTY;

		this.bop_tariff_info_usage_ind = CommonsConstants.EMPTY;

		this.bop_tariff_info_zncode = CommonsConstants.EMPTY;

		this.bop_tariff_info_zpcode = CommonsConstants.EMPTY;

		this.bpartn_sum_info_time_slice_lb = CommonsConstants.EMPTY;

		this.bpartn_sum_info_time_slice_rb = CommonsConstants.EMPTY;

		this.bundle_info_bundle_purchase_id = CommonsConstants.EMPTY;

		this.bundle_info_bundle_purch_ind = CommonsConstants.EMPTY;

		this.bundle_info_contract_id = CommonsConstants.EMPTY;

		this.bundle_info_purchase_seq_no = CommonsConstants.EMPTY;

		this.bundle_info_sequence_number = CommonsConstants.EMPTY;

		this.bundle_info_sncode = CommonsConstants.EMPTY;

		this.bundle_info_state = CommonsConstants.EMPTY;

		this.bundle_info_termination = CommonsConstants.EMPTY;

		this.bundle_info_user_profile_id = CommonsConstants.EMPTY;

		this.bundle_info_valid_from = CommonsConstants.EMPTY;

		this.bundle_info_valid_to = CommonsConstants.EMPTY;

		this.bundle_info_version = CommonsConstants.EMPTY;

		this.bundle_usg_bundle_covered_usg = CommonsConstants.EMPTY;

		this.business_info_bs_id = CommonsConstants.EMPTY;

		this.business_info_bs_version = CommonsConstants.EMPTY;

		this.business_info_charge_item_id = CommonsConstants.EMPTY;

		this.business_info_charge_party_id = CommonsConstants.EMPTY;

		this.business_info_c_p_field_ref = CommonsConstants.EMPTY;

		this.business_info_o_p_field_ref = CommonsConstants.EMPTY;

		this.business_info_pre_bs_id = CommonsConstants.EMPTY;

		this.business_info_pre_bs_version = CommonsConstants.EMPTY;

		this.bus_partner_info_tax_mode = CommonsConstants.EMPTY;

		this.call_dest = CommonsConstants.EMPTY;

		this.call_type = CommonsConstants.EMPTY;

		this.camel_dest_addr_user_prof_id = CommonsConstants.EMPTY;

		this.camel_msc_address = CommonsConstants.EMPTY;

		this.camel_msc_addr_user_prof_id = CommonsConstants.EMPTY;

		this.camel_reference_number = CommonsConstants.EMPTY;

		this.camel_srv_addr_user_prof_id = CommonsConstants.EMPTY;

		this.charge_info_cash_flow_direct = CommonsConstants.EMPTY;

		this.charge_info_disable_tax = CommonsConstants.EMPTY;

		this.charging_characteristics = CommonsConstants.EMPTY;

		this.consumer_info_address = CommonsConstants.EMPTY;

		this.consumer_info_contract_id = CommonsConstants.EMPTY;

		this.consumer_info_numbering_plan = CommonsConstants.EMPTY;

		this.content_advised_charge_ind = CommonsConstants.EMPTY;

		this.content_authorisation_code = CommonsConstants.EMPTY;

		this.content_content_charging_point = CommonsConstants.EMPTY;

		this.content_contract_pkey = CommonsConstants.EMPTY;

		this.content_desc_suppress = CommonsConstants.EMPTY;

		this.content_paid_ind = CommonsConstants.EMPTY;

		this.content_payment_method = CommonsConstants.EMPTY;

		this.content_provider_address = CommonsConstants.EMPTY;

		this.content_provider_carrier_code = CommonsConstants.EMPTY;

		this.content_provider_clir = CommonsConstants.EMPTY;

		this.content_provider_iac = CommonsConstants.EMPTY;

		this.content_provider_modif_ind = CommonsConstants.EMPTY;

		this.content_provider_network_code = CommonsConstants.EMPTY;

		this.content_provid_dynamic_address = CommonsConstants.EMPTY;

		this.content_provid_local_pref_len = CommonsConstants.EMPTY;

		this.content_provid_numbering_plan = CommonsConstants.EMPTY;

		this.content_provid_other_location = CommonsConstants.EMPTY;

		this.content_provid_type_of_number = CommonsConstants.EMPTY;

		this.content_provid_user_profile_id = CommonsConstants.EMPTY;

		this.content_refund_ind = CommonsConstants.EMPTY;

		this.content_short_desc = CommonsConstants.EMPTY;

		this.content_transaction_id = CommonsConstants.EMPTY;

		this.control_data_record_age = CommonsConstants.EMPTY;

		this.cug_info_cug_id = CommonsConstants.EMPTY;

		this.cug_info_cug_index = CommonsConstants.EMPTY;

		this.customer_info_contract_type_id = CommonsConstants.EMPTY;

		this.customer_info_contraggrpack_id = CommonsConstants.EMPTY;

		this.customer_info_reco_ind = CommonsConstants.EMPTY;

		this.cust_info_address = CommonsConstants.EMPTY;

		this.cust_info_alternate_tmcode = CommonsConstants.EMPTY;

		this.cust_info_an_package_id_list = CommonsConstants.EMPTY;

		this.cust_info_bill_cycle = CommonsConstants.EMPTY;

		this.cust_info_bu_address = CommonsConstants.EMPTY;

		this.cust_info_bu_numbering_plan = CommonsConstants.EMPTY;

		this.cust_info_charging_engine = CommonsConstants.EMPTY;

		this.cust_info_contract_id = CommonsConstants.EMPTY;

		this.cust_info_customer_id = CommonsConstants.EMPTY;

		this.cust_info_delete_after_billing = CommonsConstants.EMPTY;

		this.cust_info_dn_id = CommonsConstants.EMPTY;

		this.cust_info_main_msisdn = CommonsConstants.EMPTY;

		this.cust_info_numbering_plan = CommonsConstants.EMPTY;

		this.cust_info_port_id = CommonsConstants.EMPTY;

		this.cust_info_serv_bid_id = CommonsConstants.EMPTY;

		this.cust_info_sim_number = CommonsConstants.EMPTY;

		this.cust_info_sim_sernumber = CommonsConstants.EMPTY;

		this.cust_info_subs_code = CommonsConstants.EMPTY;

		this.cust_info_subs_tag = CommonsConstants.EMPTY;

		this.cust_info_user_profile_id = CommonsConstants.EMPTY;

		this.data_volume = CommonsConstants.EMPTY;

		this.data_volume_umcode = CommonsConstants.EMPTY;

		this.desc_prod_usage_long_desc = CommonsConstants.EMPTY;

		this.destination_field_id = CommonsConstants.EMPTY;

		this.downlink_volume_umcode = CommonsConstants.EMPTY;

		this.downlink_volume_volume = CommonsConstants.EMPTY;

		this.duration_umcode = CommonsConstants.EMPTY;

		this.duration_volume = CommonsConstants.EMPTY;

		this.entry_date_offset = CommonsConstants.EMPTY;

		this.entry_date_timestamp = CommonsConstants.EMPTY;

		this.event_info_event_type = CommonsConstants.EMPTY;

		this.event_status_info_message_id = CommonsConstants.EMPTY;

		this.event_umcode = CommonsConstants.EMPTY;

		this.event_volume = CommonsConstants.EMPTY;

		this.export_file = CommonsConstants.EMPTY;

		this.ext_balance_amnt_amount = CommonsConstants.EMPTY;

		this.follow_up_call_type = CommonsConstants.EMPTY;

		this.for_amount_amount = CommonsConstants.EMPTY;

		this.for_amount_currency = CommonsConstants.EMPTY;

		this.for_amount_gross_ind = CommonsConstants.EMPTY;

		this.for_amount_tax = CommonsConstants.EMPTY;

		this.for_freechrg_amount = CommonsConstants.EMPTY;

		this.for_freechrg_currency = CommonsConstants.EMPTY;

		this.for_freechrg_gross_ind = CommonsConstants.EMPTY;

		this.for_freechrg_tax = CommonsConstants.EMPTY;

		this.free_charge_amount = CommonsConstants.EMPTY;

		this.free_charge_amount_non_rpc = CommonsConstants.EMPTY;

		this.free_charge_currency = CommonsConstants.EMPTY;

		this.free_charge_curr_non_rpc = CommonsConstants.EMPTY;

		this.free_charge_gross_ind = CommonsConstants.EMPTY;

		this.free_charge_gross_ind_nrpc = CommonsConstants.EMPTY;

		this.free_charge_tax = CommonsConstants.EMPTY;

		this.free_charge_tax_nrpc = CommonsConstants.EMPTY;

		this.free_clicks_umcode = CommonsConstants.EMPTY;

		this.free_clicks_volume = CommonsConstants.EMPTY;

		this.free_rated_volume_umcode = CommonsConstants.EMPTY;

		this.free_rated_volume_volume = CommonsConstants.EMPTY;

		this.free_rounded_volume_umcode = CommonsConstants.EMPTY;

		this.free_rounded_volume_volume = CommonsConstants.EMPTY;

		this.free_units_info_account_key = CommonsConstants.EMPTY;

		this.free_units_info_account_origin = CommonsConstants.EMPTY;

		this.free_units_info_acc_hist_id = CommonsConstants.EMPTY;

		this.free_units_info_appl_method = CommonsConstants.EMPTY;

		this.free_units_info_chg_red_quota = CommonsConstants.EMPTY;

		this.free_units_info_discount_rate = CommonsConstants.EMPTY;

		this.free_units_info_discount_type = CommonsConstants.EMPTY;

		this.free_units_info_freeunitoption = CommonsConstants.EMPTY;

		this.free_units_info_fup_seq = CommonsConstants.EMPTY;

		this.free_units_info_fu_pack_id = CommonsConstants.EMPTY;

		this.free_units_info_part_creator = CommonsConstants.EMPTY;

		this.free_units_info_previous_seqno = CommonsConstants.EMPTY;

		this.free_units_info_seqno = CommonsConstants.EMPTY;

		this.free_units_info_version = CommonsConstants.EMPTY;

		this.home_network_code = CommonsConstants.EMPTY;

		this.hscsd_info_aiur = CommonsConstants.EMPTY;

		this.hscsd_info_channels_max = CommonsConstants.EMPTY;

		this.hscsd_info_channels_used = CommonsConstants.EMPTY;

		this.hscsd_info_coding_acc = CommonsConstants.EMPTY;

		this.hscsd_info_coding_used = CommonsConstants.EMPTY;

		this.hscsd_info_fnur = CommonsConstants.EMPTY;

		this.hscsd_info_init_party = CommonsConstants.EMPTY;

		this.imp_party1_address = CommonsConstants.EMPTY;

		this.imp_party1_alternate_tmcode = CommonsConstants.EMPTY;

		this.imp_party1_an_package_id_list = CommonsConstants.EMPTY;

		this.imp_party1_bill_cycle = CommonsConstants.EMPTY;

		this.imp_party1_numbering_plan = CommonsConstants.EMPTY;

		this.imp_party1_user_profile_id = CommonsConstants.EMPTY;

		this.imp_party2_address = CommonsConstants.EMPTY;

		this.imp_party2_alternate_tmcode = CommonsConstants.EMPTY;

		this.imp_party2_an_package_id_list = CommonsConstants.EMPTY;

		this.imp_party2_bill_cycle = CommonsConstants.EMPTY;

		this.imp_party2_numbering_plan = CommonsConstants.EMPTY;

		this.imp_party2_user_profile_id = CommonsConstants.EMPTY;

		this.imp_party3_address = CommonsConstants.EMPTY;

		this.imp_party3_alternate_tmcode = CommonsConstants.EMPTY;

		this.imp_party3_an_package_id_list = CommonsConstants.EMPTY;

		this.imp_party3_bill_cycle = CommonsConstants.EMPTY;

		this.imp_party3_numbering_plan = CommonsConstants.EMPTY;

		this.imp_party3_user_profile_id = CommonsConstants.EMPTY;

		this.imp_party4_address = CommonsConstants.EMPTY;

		this.imp_party4_alternate_tmcode = CommonsConstants.EMPTY;

		this.imp_party4_an_package_id_list = CommonsConstants.EMPTY;

		this.imp_party4_bill_cycle = CommonsConstants.EMPTY;

		this.imp_party4_numbering_plan = CommonsConstants.EMPTY;

		this.imp_party4_parent_contract_id = CommonsConstants.EMPTY;

		this.imp_party4_user_profile_id = CommonsConstants.EMPTY;

		this.imp_party5_address = CommonsConstants.EMPTY;

		this.imp_party5_alternate_tmcode = CommonsConstants.EMPTY;

		this.imp_party5_an_package_id_list = CommonsConstants.EMPTY;

		this.imp_party5_bill_cycle = CommonsConstants.EMPTY;

		this.imp_party5_numbering_plan = CommonsConstants.EMPTY;

		this.imp_party5_parent_contract_id = CommonsConstants.EMPTY;

		this.imp_party5_user_profile_id = CommonsConstants.EMPTY;

		this.initial_start_time_timestamp = CommonsConstants.EMPTY;

		this.initial_start_time_time_offset = CommonsConstants.EMPTY;

		this.lcs_qos_deliv_horizontal_accur = CommonsConstants.EMPTY;

		this.lcs_qos_deliv_tracking_frequen = CommonsConstants.EMPTY;

		this.lcs_qos_deliv_tracking_period = CommonsConstants.EMPTY;

		this.lcs_qos_deliv_vertical_accur = CommonsConstants.EMPTY;

		this.lcs_qos_info_age_of_location = CommonsConstants.EMPTY;

		this.lcs_qos_info_position_method = CommonsConstants.EMPTY;

		this.lcs_qos_info_response_time = CommonsConstants.EMPTY;

		this.lcs_qos_info_response_time_cat = CommonsConstants.EMPTY;

		this.lcs_qos_req_horizontal_accur = CommonsConstants.EMPTY;

		this.lcs_qos_req_tracking_frequency = CommonsConstants.EMPTY;

		this.lcs_qos_req_tracking_period = CommonsConstants.EMPTY;

		this.lcs_qos_req_vertical_accur = CommonsConstants.EMPTY;

		this.ldc_info_carrier_code = CommonsConstants.EMPTY;

		this.ldc_info_contract_pkey = CommonsConstants.EMPTY;

		this.ldc_info_home_net_ind = CommonsConstants.EMPTY;

		this.lec_info_contract_pkey = CommonsConstants.EMPTY;

		this.lec_info_home_net_ind = CommonsConstants.EMPTY;

		this.lzlist = CommonsConstants.EMPTY;

		this.mc_info_code = CommonsConstants.EMPTY;

		this.mc_info_ind = CommonsConstants.EMPTY;

		this.mc_info_micro_cell_information = CommonsConstants.EMPTY;

		this.mc_scalefactor = CommonsConstants.EMPTY;

		this.messages_umcode = CommonsConstants.EMPTY;

		this.messages_volume = CommonsConstants.EMPTY;

		this.micro_cell_imcscalefactortype = CommonsConstants.EMPTY;

		this.micro_cell_mc_code = CommonsConstants.EMPTY;

		this.micro_cell_mc_pkey = CommonsConstants.EMPTY;

		this.micro_cell_mc_type = CommonsConstants.EMPTY;

		this.micro_cell_scalefactor = CommonsConstants.EMPTY;

		this.network_init_context_ind = CommonsConstants.EMPTY;

		this.net_element_home_bid_id = CommonsConstants.EMPTY;

		this.net_element_network_code = CommonsConstants.EMPTY;

		this.net_element_netw_element_id = CommonsConstants.EMPTY;

		this.net_element_user_profile_id = CommonsConstants.EMPTY;

		this.normed_net_elem_address = CommonsConstants.EMPTY;

		this.normed_net_elem_int_acc_code = CommonsConstants.EMPTY;

		this.normed_net_elem_number_plan = CommonsConstants.EMPTY;

		this.normed_rtd_num_address = CommonsConstants.EMPTY;

		this.normed_rtd_num_int_acc_code = CommonsConstants.EMPTY;

		this.normed_rtd_num_number_plan = CommonsConstants.EMPTY;

		this.normtrkgrp_in_address = CommonsConstants.EMPTY;

		this.normtrkgrp_in_numberingplan = CommonsConstants.EMPTY;

		this.normtrkgrp_out_address = CommonsConstants.EMPTY;

		this.normtrkgrp_out_numberingplan = CommonsConstants.EMPTY;

		this.number_of_rejections = CommonsConstants.EMPTY;

		this.offer_offer_seqno = CommonsConstants.EMPTY;

		this.offer_offer_sncode = CommonsConstants.EMPTY;

		this.origin_field_id = CommonsConstants.EMPTY;

		this.orig_entry_date_timestamp = CommonsConstants.EMPTY;

		this.orig_entry_date_timezone_id = CommonsConstants.EMPTY;

		this.orig_entry_date_timezone_pkey = CommonsConstants.EMPTY;

		this.orig_entry_date_time_offset = CommonsConstants.EMPTY;

		this.or_flag = CommonsConstants.EMPTY;

		this.o_p_normed_num_address = CommonsConstants.EMPTY;

		this.o_p_normed_num_int_acc_code = CommonsConstants.EMPTY;

		this.o_p_normed_num_number_plan = CommonsConstants.EMPTY;

		this.o_p_number_address = CommonsConstants.EMPTY;

		this.o_p_number_backup_address = CommonsConstants.EMPTY;

		this.o_p_number_carrier_code = CommonsConstants.EMPTY;

		this.o_p_number_clir = CommonsConstants.EMPTY;

		this.o_p_number_numbering_plan = CommonsConstants.EMPTY;

		this.o_p_number_other_location = CommonsConstants.EMPTY;

		this.o_p_number_type_of_number = CommonsConstants.EMPTY;

		this.o_p_number_user_profile_id = CommonsConstants.EMPTY;

		this.o_p_pubid_address = CommonsConstants.EMPTY;

		this.o_p_pubid_numbering_plan = CommonsConstants.EMPTY;

		this.o_p_pubid_type_of_number = CommonsConstants.EMPTY;

		this.price_plan_info_chrgplanid = CommonsConstants.EMPTY;

		this.price_plan_info_evalquantity = CommonsConstants.EMPTY;

		this.price_plan_info_threshold = CommonsConstants.EMPTY;

		this.promo_info_b_number_cat = CommonsConstants.EMPTY;

		this.qos_negot_delay = CommonsConstants.EMPTY;

		this.qos_negot_mean_throughput = CommonsConstants.EMPTY;

		this.qos_negot_peak_throughput = CommonsConstants.EMPTY;

		this.qos_negot_precedence = CommonsConstants.EMPTY;

		this.qos_negot_reliability = CommonsConstants.EMPTY;

		this.qos_profile = CommonsConstants.EMPTY;

		this.qos_req_delay = CommonsConstants.EMPTY;

		this.qos_req_mean_throughput = CommonsConstants.EMPTY;

		this.qos_req_peak_throughput = CommonsConstants.EMPTY;

		this.qos_req_precedence = CommonsConstants.EMPTY;

		this.qos_req_reliability = CommonsConstants.EMPTY;

		this.rated_clicks_umcode = CommonsConstants.EMPTY;

		this.rated_clicks_volume = CommonsConstants.EMPTY;

		this.rated_flat_amnt_gross_ind_nrpc = CommonsConstants.EMPTY;

		this.rated_flat_amnt_orig_currency = CommonsConstants.EMPTY;

		this.rated_flat_amnt_orig_gross_ind = CommonsConstants.EMPTY;

		this.rated_flat_amnt_tax_nrpc = CommonsConstants.EMPTY;

		this.rated_flat_amount = CommonsConstants.EMPTY;

		this.rated_flat_amount_currency = CommonsConstants.EMPTY;

		this.rated_flat_amount_gross_ind = CommonsConstants.EMPTY;

		this.rated_flat_amount_non_rpc = CommonsConstants.EMPTY;

		this.rated_flat_amount_non_rpc_curr = CommonsConstants.EMPTY;

		this.rated_flat_amount_orig_amount = CommonsConstants.EMPTY;

		this.rated_flat_amount_orig_tax = CommonsConstants.EMPTY;

		this.rated_flat_amount_tax = CommonsConstants.EMPTY;

		this.rated_volume = CommonsConstants.EMPTY;

		this.rated_volume_umcode = CommonsConstants.EMPTY;

		this.recipient_net_address = CommonsConstants.EMPTY;

		this.recipient_net_numbering_plan = CommonsConstants.EMPTY;

		this.record_id_call_id = CommonsConstants.EMPTY;

		this.record_id_cdr_id = CommonsConstants.EMPTY;

		this.record_id_cdr_sub_id = CommonsConstants.EMPTY;

		this.record_id_event_ref = CommonsConstants.EMPTY;

		this.record_id_orig_cdr_id = CommonsConstants.EMPTY;

		this.record_id_rap_sequence_num = CommonsConstants.EMPTY;

		this.record_id_rerate_seqno = CommonsConstants.EMPTY;

		this.record_id_shaacc_unique_id = CommonsConstants.EMPTY;

		this.record_id_tap_sequence_num = CommonsConstants.EMPTY;

		this.record_id_udr_file_id = CommonsConstants.EMPTY;

		this.record_type_record_category = CommonsConstants.EMPTY;

		this.record_type_summary_ind = CommonsConstants.EMPTY;

		this.refer_contr_contract_id = CommonsConstants.EMPTY;

		this.refer_contr_reference_type = CommonsConstants.EMPTY;

		this.rejected_base_part = CommonsConstants.EMPTY;

		this.reject_reason_code = CommonsConstants.EMPTY;

		this.remark = CommonsConstants.EMPTY;

		this.rerate_info_rerate_reason_id = CommonsConstants.EMPTY;

		this.rerate_info_rerate_record_type = CommonsConstants.EMPTY;

		this.rerate_info_rerate_request_id = CommonsConstants.EMPTY;

		this.rerate_info_urh_id = CommonsConstants.EMPTY;

		this.rounded_volume = CommonsConstants.EMPTY;

		this.rounded_volume_umcode = CommonsConstants.EMPTY;

		this.routing_network_code = CommonsConstants.EMPTY;

		this.routing_number_backup_address = CommonsConstants.EMPTY;

		this.routing_user_profile_id = CommonsConstants.EMPTY;

		this.scu_id_address = CommonsConstants.EMPTY;

		this.scu_id_user_profile_id = CommonsConstants.EMPTY;

		this.scu_info_priority_code = CommonsConstants.EMPTY;

		this.service_action_code = CommonsConstants.EMPTY;

		this.service_guaranteed_bit_rate = CommonsConstants.EMPTY;

		this.service_hscsd_ind = CommonsConstants.EMPTY;

		this.service_ims_signalling_context = CommonsConstants.EMPTY;

		this.service_logic_code = CommonsConstants.EMPTY;

		this.service_max_bit_rate = CommonsConstants.EMPTY;

		this.service_service_type = CommonsConstants.EMPTY;

		this.service_used_service = CommonsConstants.EMPTY;

		this.service_user_protocol_ind = CommonsConstants.EMPTY;

		this.service_vas_code = CommonsConstants.EMPTY;

		this.serv_pdp_addr_apn_split_ind = CommonsConstants.EMPTY;

		this.sgsn_addresses = CommonsConstants.EMPTY;

		this.spec_num_info_apply_free_units = CommonsConstants.EMPTY;

		this.start_time_charge_offset = CommonsConstants.EMPTY;

		this.start_time_charge_timestamp = CommonsConstants.EMPTY;

		this.start_time_offset = CommonsConstants.EMPTY;

		this.start_time_timestamp = CommonsConstants.EMPTY;

		this.sum_reference_single_id = CommonsConstants.EMPTY;

		this.s_pdp_address = CommonsConstants.EMPTY;

		this.s_pdp_carrier_code = CommonsConstants.EMPTY;

		this.s_pdp_clir = CommonsConstants.EMPTY;

		this.s_pdp_intern_access_code = CommonsConstants.EMPTY;

		this.s_pdp_modification_ind = CommonsConstants.EMPTY;

		this.s_pdp_network_code = CommonsConstants.EMPTY;

		this.s_pdp_numbering_plan = CommonsConstants.EMPTY;

		this.s_pdp_type_of_number = CommonsConstants.EMPTY;

		this.s_pdp_user_profile_id = CommonsConstants.EMPTY;

		this.s_p_equipment_class_mark = CommonsConstants.EMPTY;

		this.s_p_equipment_number = CommonsConstants.EMPTY;

		this.s_p_home_id_description = CommonsConstants.EMPTY;

		this.s_p_home_id_home_bid_id = CommonsConstants.EMPTY;

		this.s_p_home_id_name = CommonsConstants.EMPTY;

		this.s_p_home_id_network = CommonsConstants.EMPTY;

		this.s_p_home_loc_address = CommonsConstants.EMPTY;

		this.s_p_home_loc_numbering_plan = CommonsConstants.EMPTY;

		this.s_p_location_address = CommonsConstants.EMPTY;

		this.s_p_location_numbering_plan = CommonsConstants.EMPTY;

		this.s_p_loc_serving_bid_id = CommonsConstants.EMPTY;

		this.s_p_loc_serving_location = CommonsConstants.EMPTY;

		this.s_p_number_address = CommonsConstants.EMPTY;

		this.s_p_number_home_bid_id = CommonsConstants.EMPTY;

		this.s_p_number_network_code = CommonsConstants.EMPTY;

		this.s_p_number_numbering_plan = CommonsConstants.EMPTY;

		this.s_p_number_user_profile_id = CommonsConstants.EMPTY;

		this.s_p_port_address = CommonsConstants.EMPTY;

		this.s_p_port_numbering_plan = CommonsConstants.EMPTY;

		this.s_p_port_user_profile_id = CommonsConstants.EMPTY;

		this.tariff_detail_chgbl_quantity = CommonsConstants.EMPTY;

		this.tariff_detail_ext_chrg_udmcode = CommonsConstants.EMPTY;

		this.tariff_detail_interconnect_ind = CommonsConstants.EMPTY;

		this.tariff_detail_rate_type_id = CommonsConstants.EMPTY;

		this.tariff_detail_rtx_charge_type = CommonsConstants.EMPTY;

		this.tariff_detail_ttcode = CommonsConstants.EMPTY;

		this.tariff_info_catalogue_id = CommonsConstants.EMPTY;

		this.tariff_info_catalogue_vers = CommonsConstants.EMPTY;

		this.tariff_info_ctlg_elm_id = CommonsConstants.EMPTY;

		this.tariff_info_egcode = CommonsConstants.EMPTY;

		this.tariff_info_egversion = CommonsConstants.EMPTY;

		this.tariff_info_gvcode = CommonsConstants.EMPTY;

		this.tariff_info_pricelist_id = CommonsConstants.EMPTY;

		this.tariff_info_pricelist_pkey = CommonsConstants.EMPTY;

		this.tariff_info_pricelist_vers = CommonsConstants.EMPTY;

		this.tariff_info_price_def_vers = CommonsConstants.EMPTY;

		this.tariff_info_rpcode = CommonsConstants.EMPTY;

		this.tariff_info_rpversion = CommonsConstants.EMPTY;

		this.tariff_info_sncode = CommonsConstants.EMPTY;

		this.tariff_info_spcode = CommonsConstants.EMPTY;

		this.tariff_info_time_band_code = CommonsConstants.EMPTY;

		this.tariff_info_tmcode = CommonsConstants.EMPTY;

		this.tariff_info_tmversion = CommonsConstants.EMPTY;

		this.tariff_info_tm_used_type = CommonsConstants.EMPTY;

		this.tariff_info_twcode = CommonsConstants.EMPTY;

		this.tariff_info_usage_ind = CommonsConstants.EMPTY;

		this.tariff_info_zncode = CommonsConstants.EMPTY;

		this.tariff_info_zpcode = CommonsConstants.EMPTY;

		this.tariff_info_zpcode_day_catcode = CommonsConstants.EMPTY;

		this.tax_info_serv_cat = CommonsConstants.EMPTY;

		this.tax_info_serv_code = CommonsConstants.EMPTY;

		this.tax_info_serv_type = CommonsConstants.EMPTY;

		this.techn_info_fixed_mobile_ind = CommonsConstants.EMPTY;

		this.techn_info_home_terminated_ind = CommonsConstants.EMPTY;

		this.techn_info_prepay_ind = CommonsConstants.EMPTY;

		this.techn_info_pre_rated_ind = CommonsConstants.EMPTY;

		this.techn_info_rev_charging_ind = CommonsConstants.EMPTY;

		this.techn_info_sccode = CommonsConstants.EMPTY;

		this.techn_info_termination_ind = CommonsConstants.EMPTY;

		this.trunk_group_in_address = CommonsConstants.EMPTY;

		this.trunk_group_in_numberingplan = CommonsConstants.EMPTY;

		this.trunk_group_in_typeofnumber = CommonsConstants.EMPTY;

		this.trunk_group_out_address = CommonsConstants.EMPTY;

		this.trunk_group_out_numberingplan = CommonsConstants.EMPTY;

		this.trunk_group_out_typeofnumber = CommonsConstants.EMPTY;

		this.t_p_number_user_profile_id = CommonsConstants.EMPTY;

		this.udr_basepart_id = CommonsConstants.EMPTY;

		this.udr_chargepart_id = CommonsConstants.EMPTY;

		this.uds_base_part_id = CommonsConstants.EMPTY;

		this.uds_charge_part_id = CommonsConstants.EMPTY;

		this.uds_free_unit_part_id = CommonsConstants.EMPTY;

		this.uds_promotion_part_id = CommonsConstants.EMPTY;

		this.uds_record_id = CommonsConstants.EMPTY;

		this.uds_stream_id = CommonsConstants.EMPTY;

		this.umts_qos_negot_allc_retn_prior = CommonsConstants.EMPTY;

		this.umts_qos_negot_delay = CommonsConstants.EMPTY;

		this.umts_qos_negot_delivery_order = CommonsConstants.EMPTY;

		this.umts_qos_negot_erroneous_sdus = CommonsConstants.EMPTY;

		this.umts_qos_negot_handl_priority = CommonsConstants.EMPTY;

		this.umts_qos_negot_max_size_sdu = CommonsConstants.EMPTY;

		this.umts_qos_negot_rate_downlink = CommonsConstants.EMPTY;

		this.umts_qos_negot_rate_uplink = CommonsConstants.EMPTY;

		this.umts_qos_negot_residual_ber = CommonsConstants.EMPTY;

		this.umts_qos_negot_sdu_err_ratio = CommonsConstants.EMPTY;

		this.umts_qos_negot_traffic_class = CommonsConstants.EMPTY;

		this.umts_qos_req_allc_retn_prior = CommonsConstants.EMPTY;

		this.umts_qos_req_delay = CommonsConstants.EMPTY;

		this.umts_qos_req_delivery_order = CommonsConstants.EMPTY;

		this.umts_qos_req_erroneous_sdus = CommonsConstants.EMPTY;

		this.umts_qos_req_handl_priority = CommonsConstants.EMPTY;

		this.umts_qos_req_max_size_sdu = CommonsConstants.EMPTY;

		this.umts_qos_req_rate_downlink = CommonsConstants.EMPTY;

		this.umts_qos_req_rate_uplink = CommonsConstants.EMPTY;

		this.umts_qos_req_residual_ber = CommonsConstants.EMPTY;

		this.umts_qos_req_sdu_error_ratio = CommonsConstants.EMPTY;

		this.umts_qos_req_traffic_class = CommonsConstants.EMPTY;

		this.unbilledamtpaymresp_customerid = CommonsConstants.EMPTY;

		this.unbilled_amount_amount = CommonsConstants.EMPTY;

		this.unbilled_amount_currency = CommonsConstants.EMPTY;

		this.unbilled_amount_gross_ind = CommonsConstants.EMPTY;

		this.unbilled_amount_tax = CommonsConstants.EMPTY;

		this.uplink_volume_umcode = CommonsConstants.EMPTY;

		this.uplink_volume_volume = CommonsConstants.EMPTY;

		this.vpn_info_vpn_call_type = CommonsConstants.EMPTY;

		this.vpn_number_address = CommonsConstants.EMPTY;

		this.vpn_number_carrier_code = CommonsConstants.EMPTY;

		this.vpn_number_clir = CommonsConstants.EMPTY;

		this.vpn_number_dynamic_address = CommonsConstants.EMPTY;

		this.vpn_number_int_access_code = CommonsConstants.EMPTY;

		this.vpn_number_local_prefix_len = CommonsConstants.EMPTY;

		this.vpn_number_modification_ind = CommonsConstants.EMPTY;

		this.vpn_number_network_code = CommonsConstants.EMPTY;

		this.vpn_number_numbering_plan = CommonsConstants.EMPTY;

		this.vpn_number_type_of_number = CommonsConstants.EMPTY;

		this.vpn_number_user_profile_id = CommonsConstants.EMPTY;

		this.xfile_base_charge_amount = CommonsConstants.EMPTY;

		this.xfile_base_charge_currency = CommonsConstants.EMPTY;

		this.xfile_base_charge_gross_ind = CommonsConstants.EMPTY;

		this.xfile_base_charge_tax = CommonsConstants.EMPTY;

		this.xfile_call_type = CommonsConstants.EMPTY;

		this.xfile_charge_amount = CommonsConstants.EMPTY;

		this.xfile_charge_currency = CommonsConstants.EMPTY;

		this.xfile_charge_gross_ind = CommonsConstants.EMPTY;

		this.xfile_charge_tax = CommonsConstants.EMPTY;

		this.xfile_day_category_code = CommonsConstants.EMPTY;

		this.xfile_discount_amount = CommonsConstants.EMPTY;

		this.xfile_discount_currency = CommonsConstants.EMPTY;

		this.xfile_ic_charge_amount = CommonsConstants.EMPTY;

		this.xfile_ic_charge_currency = CommonsConstants.EMPTY;

		this.xfile_ic_charge_gross_ind = CommonsConstants.EMPTY;

		this.xfile_ic_charge_tax = CommonsConstants.EMPTY;

		this.xfile_ind = CommonsConstants.EMPTY;

		this.xfile_time_band_code = CommonsConstants.EMPTY;

		this.zero_rated_volume_umcode = CommonsConstants.EMPTY;

		this.zero_rated_volume_volume = CommonsConstants.EMPTY;

		this.zero_rounded_volume_umcode = CommonsConstants.EMPTY;

		this.zero_rounded_volume_volume = CommonsConstants.EMPTY;

		this.bal_audit_dat_valid_from = CommonsConstants.EMPTY;

		this.bal_audit_dat_valid_to = CommonsConstants.EMPTY;

		this.chrgaggrinfo_request_id = CommonsConstants.EMPTY;

		this.cust_info_customer_group = CommonsConstants.EMPTY;

		this.cust_info_parent_contract_id = CommonsConstants.EMPTY;

		this.imp_party1_parent_contract_id = CommonsConstants.EMPTY;

		this.imp_party2_parent_contract_id = CommonsConstants.EMPTY;

		this.imp_party3_parent_contract_id = CommonsConstants.EMPTY;

		this.net_element_address = CommonsConstants.EMPTY;

		this.net_element_numbering_plan = CommonsConstants.EMPTY;

		this.net_element_type_of_number = CommonsConstants.EMPTY;

		this.rated_flat_amnt_orig_disc_amnt = CommonsConstants.EMPTY;

		this.rated_flat_amount_disc_amount = CommonsConstants.EMPTY;

		this.reject_filter_id = CommonsConstants.EMPTY;

		this.routing_address = CommonsConstants.EMPTY;

		this.routing_numbering_plan = CommonsConstants.EMPTY;

		this.routing_type_of_number = CommonsConstants.EMPTY;

		this.tariff_detail_pricgalternpkey = CommonsConstants.EMPTY;

		this.tariff_detail_pricingalternid = CommonsConstants.EMPTY;

		this.t_p_number_address = CommonsConstants.EMPTY;

		this.t_p_number_numbering_plan = CommonsConstants.EMPTY;

		this.t_p_number_type_of_number = CommonsConstants.EMPTY;

		this.unbilled_amount_billing_acc = CommonsConstants.EMPTY;

		this.unbilled_amount_compl_cond_id = CommonsConstants.EMPTY;

		this.entry_date_sim_offset = CommonsConstants.EMPTY;

		this.entry_date_sim_timestamp = CommonsConstants.EMPTY;

		this.fu_pack_id_clone = CommonsConstants.EMPTY;

		this.micro_cell_mc_shdes = CommonsConstants.EMPTY;

		this.o_p_number_anonym_ind = CommonsConstants.EMPTY;

		this.o_p_subs_address = CommonsConstants.EMPTY;

		this.o_p_subs_carrier_code = CommonsConstants.EMPTY;

		this.o_p_subs_clir = CommonsConstants.EMPTY;

		this.o_p_subs_dynamic_address = CommonsConstants.EMPTY;

		this.o_p_subs_iac = CommonsConstants.EMPTY;

		this.o_p_subs_local_prefix_len = CommonsConstants.EMPTY;

		this.o_p_subs_modification_ind = CommonsConstants.EMPTY;

		this.o_p_subs_network_code = CommonsConstants.EMPTY;

		this.o_p_subs_numbering_plan = CommonsConstants.EMPTY;

		this.o_p_subs_type_of_number = CommonsConstants.EMPTY;

		this.record_id_ext_call_id = CommonsConstants.EMPTY;

		this.record_id_ext_file_id = CommonsConstants.EMPTY;

		this.redirected_address = CommonsConstants.EMPTY;

		this.redirected_carrier_code = CommonsConstants.EMPTY;

		this.redirected_clir = CommonsConstants.EMPTY;

		this.redirected_dynamic_address = CommonsConstants.EMPTY;

		this.redirected_iac = CommonsConstants.EMPTY;

		this.redirected_local_prefix_len = CommonsConstants.EMPTY;

		this.redirected_modification_ind = CommonsConstants.EMPTY;

		this.redirected_network_code = CommonsConstants.EMPTY;

		this.redirected_numbering_plan = CommonsConstants.EMPTY;

		this.redirected_type_of_number = CommonsConstants.EMPTY;

		this.srvcode = CommonsConstants.EMPTY;

		this.start_time_original_offset = CommonsConstants.EMPTY;

		this.start_time_original_time = CommonsConstants.EMPTY;

		this.s_p_location_area_code = CommonsConstants.EMPTY;

		this.tariff_info_zodes = CommonsConstants.EMPTY;

		this.tariff_info_zpdes = CommonsConstants.EMPTY;

		this.techn_info_call_nature = CommonsConstants.EMPTY;

		this.techn_info_charged_party = CommonsConstants.EMPTY;

		this.techn_info_lng_dist_carrier_cd = CommonsConstants.EMPTY;

		this.translated_address = CommonsConstants.EMPTY;

		this.translated_carrier_code = CommonsConstants.EMPTY;

		this.translated_clir = CommonsConstants.EMPTY;

		this.translated_dynamic_address = CommonsConstants.EMPTY;

		this.translated_iac = CommonsConstants.EMPTY;

		this.translated_local_prefix_len = CommonsConstants.EMPTY;

		this.translated_modification_ind = CommonsConstants.EMPTY;

		this.translated_network_code = CommonsConstants.EMPTY;

		this.translated_numbering_plan = CommonsConstants.EMPTY;

		this.translated_type_of_number = CommonsConstants.EMPTY;

		this.valid_from_smart_bberry = CommonsConstants.EMPTY;

		this.valid_from_smart_dsl = CommonsConstants.EMPTY;

		this.valid_from_smart_sms = CommonsConstants.EMPTY;

		this.valid_from_smart_web = CommonsConstants.EMPTY;

		this.xfile_charge_roam_scenario_id = CommonsConstants.EMPTY;

		this.xfile_charge_umcode = CommonsConstants.EMPTY;

		this.xfile_charge_volume = CommonsConstants.EMPTY;

		this.late_call_config_id = CommonsConstants.EMPTY;

		this.late_call_expiration_date = CommonsConstants.EMPTY;

		this.late_call_grace_time = CommonsConstants.EMPTY;

		this.mcprincing_value = CommonsConstants.EMPTY;

		this.mc_balance = CommonsConstants.EMPTY;

		this.mc_fup_indicator = CommonsConstants.EMPTY;

		this.mc_limited = CommonsConstants.EMPTY;

		this.mc_original_amount = CommonsConstants.EMPTY;

		this.mc_pricing_mech = CommonsConstants.EMPTY;

		this.mc_used_units = CommonsConstants.EMPTY;

		this.load_date_offset = CommonsConstants.EMPTY;

		this.load_date_timestamp = CommonsConstants.EMPTY;

		this.record_id_uct_ctrl = CommonsConstants.EMPTY;

		this.cob_type2_a_party_type = CommonsConstants.EMPTY;

		this.cob_type2_b_party_type = CommonsConstants.EMPTY;

		this.cob_type2_callnature = CommonsConstants.EMPTY;

		this.cob_type2_cnl_a_party = CommonsConstants.EMPTY;

		this.cob_type2_cnl_b_party = CommonsConstants.EMPTY;

		this.cob_type2_eot_a = CommonsConstants.EMPTY;

		this.cob_type2_eot_b = CommonsConstants.EMPTY;

		this.cob_type2_onnet_ind = CommonsConstants.EMPTY;

		this.cob_type2_originidentification = CommonsConstants.EMPTY;

		this.cob_type2_recordtype = CommonsConstants.EMPTY;

		this.cob_type2_tfi = CommonsConstants.EMPTY;

		this.imp2_valid_from_smart_bberry = CommonsConstants.EMPTY;

		this.imp2_valid_from_smart_dsl = CommonsConstants.EMPTY;

		this.imp2_valid_from_smart_sms = CommonsConstants.EMPTY;

		this.imp2_valid_from_smart_web = CommonsConstants.EMPTY;

		this.imp_party1_comm_name_1 = CommonsConstants.EMPTY;

		this.imp_party1_comm_spec_rate_1 = CommonsConstants.EMPTY;

		this.imp_party1_comm_spec_rate_2 = CommonsConstants.EMPTY;

		this.imp_party2_comm_name_1 = CommonsConstants.EMPTY;

		this.imp_party2_comm_spec_rate_1 = CommonsConstants.EMPTY;

		this.imp_party2_comm_spec_rate_2 = CommonsConstants.EMPTY;

		this.rated_flat_amnt_orig_mc_amnt = CommonsConstants.EMPTY;

		this.s_p_number_translated_address = CommonsConstants.EMPTY;

		this.row_id = CommonsConstants.EMPTY;

		this.loteid = CommonsConstants.EMPTY;

		this.arquivo = CommonsConstants.EMPTY;

		this.arquivots = CommonsConstants.EMPTY;

		this.currentdate = CommonsConstants.EMPTY;

	}

	public void setTraftarBscs9_part1(String num_rowid_ogg, String cod_ogg, String tpo_operacao_ogg, String dat_ogg,
			String nom_sistema_ogg, String nom_interface_ogg,

			String aggreg_info_aggreg_purpose, String aggreg_info_agg_trans_id, String aggreg_info_applied_pack_id,
			String aggreg_info_rec_counter, String aggreg_info_summary_id,

			String alt_rated_amount, String alt_rated_currency, String alt_tariff_clicks_volume, String alt_tmcode,
			String an_pack_an_package_id_list, String an_pack_orig_an_pack_id_list,

			String bal_audit_data_account_id, String bal_audit_data_account_type, String bal_audit_data_account_type_id,
			String bal_audit_dat_balance_accum, String bal_audit_dat_balance_prod_id,

			String bal_audit_dat_balance_type, String bal_audit_dat_bal_after_chg, String bal_audit_dat_bal_before_chg,
			String bal_audit_dat_bundl_prod_id, String bal_audit_dat_contract_id,

			String bal_audit_dat_offer_seqno, String bal_audit_dat_offer_sncode, String bal_audit_dat_prep_credit_ind,
			String bal_audit_dat_purchase_seq_no, String bal_audit_dat_shacc_packid,

			String bal_audit_dat_user_profile_id, String bop_info_bop_package_id, String bop_info_bop_package_pkey,
			String bop_info_bop_package_version, String bop_info_detail_billed_ind,

			String bop_info_detail_bop_altern_ind, String bop_info_detail_contracted_ind,
			String bop_info_detail_sequence_rp, String bop_info_detail_sequence_sp, String bop_tariff_info_day_catcode,

			String bop_tariff_info_egcode, String bop_tariff_info_egversion, String bop_tariff_info_gvcode,
			String bop_tariff_info_rpcode, String bop_tariff_info_rpversion,

			String bop_tariff_info_sncode, String bop_tariff_info_spcode, String bop_tariff_info_time_band_code,
			String bop_tariff_info_tmcode, String bop_tariff_info_tmversion,

			String bop_tariff_info_tm_used_type, String bop_tariff_info_twcode, String bop_tariff_info_usage_ind,
			String bop_tariff_info_zncode, String bop_tariff_info_zpcode,

			String bpartn_sum_info_time_slice_lb, String bpartn_sum_info_time_slice_rb,
			String bundle_info_bundle_purchase_id, String bundle_info_bundle_purch_ind, String bundle_info_contract_id,

			String bundle_info_purchase_seq_no, String bundle_info_sequence_number, String bundle_info_sncode,
			String bundle_info_state, String bundle_info_termination,

			String bundle_info_user_profile_id, String bundle_info_valid_from, String bundle_info_valid_to,
			String bundle_info_version, String bundle_usg_bundle_covered_usg,

			String business_info_bs_id, String business_info_bs_version, String business_info_charge_item_id,
			String business_info_charge_party_id, String business_info_c_p_field_ref,

			String business_info_o_p_field_ref, String business_info_pre_bs_id, String business_info_pre_bs_version,
			String bus_partner_info_tax_mode, String call_dest, String call_type,

			String camel_dest_addr_user_prof_id, String camel_msc_address, String camel_msc_addr_user_prof_id,
			String camel_reference_number, String camel_srv_addr_user_prof_id,

			String charge_info_cash_flow_direct, String charge_info_disable_tax, String charging_characteristics,
			String consumer_info_address, String consumer_info_contract_id,

			String consumer_info_numbering_plan, String content_advised_charge_ind, String content_authorisation_code,
			String content_content_charging_point, String content_contract_pkey,

			String content_desc_suppress, String content_paid_ind, String content_payment_method,
			String content_provider_address, String content_provider_carrier_code, String content_provider_clir,

			String content_provider_iac, String content_provider_modif_ind, String content_provider_network_code,
			String content_provid_dynamic_address, String content_provid_local_pref_len,

			String content_provid_numbering_plan, String content_provid_other_location,
			String content_provid_type_of_number, String content_provid_user_profile_id, String content_refund_ind,

			String content_short_desc, String content_transaction_id, String control_data_record_age,
			String cug_info_cug_id, String cug_info_cug_index, String customer_info_contract_type_id,

			String customer_info_contraggrpack_id, String customer_info_reco_ind, String cust_info_address,
			String cust_info_alternate_tmcode, String cust_info_an_package_id_list,

			String cust_info_bill_cycle, String cust_info_bu_address, String cust_info_bu_numbering_plan,
			String cust_info_charging_engine, String cust_info_contract_id, String cust_info_customer_id,

			String cust_info_delete_after_billing, String cust_info_dn_id, String cust_info_main_msisdn,
			String cust_info_numbering_plan, String cust_info_port_id, String cust_info_serv_bid_id,

			String cust_info_sim_number, String cust_info_sim_sernumber, String cust_info_subs_code,
			String cust_info_subs_tag, String cust_info_user_profile_id, String data_volume,

			String data_volume_umcode, String desc_prod_usage_long_desc, String destination_field_id,
			String downlink_volume_umcode, String downlink_volume_volume, String duration_umcode,

			String duration_volume, String entry_date_offset, String entry_date_timestamp, String event_info_event_type,
			String event_status_info_message_id, String event_umcode, String event_volume,

			String export_file, String ext_balance_amnt_amount, String follow_up_call_type, String for_amount_amount,
			String for_amount_currency, String for_amount_gross_ind, String for_amount_tax,

			String for_freechrg_amount, String for_freechrg_currency, String for_freechrg_gross_ind,
			String for_freechrg_tax, String free_charge_amount, String free_charge_amount_non_rpc,

			String free_charge_currency, String free_charge_curr_non_rpc, String free_charge_gross_ind,
			String free_charge_gross_ind_nrpc, String free_charge_tax, String free_charge_tax_nrpc,

			String free_clicks_umcode, String free_clicks_volume, String free_rated_volume_umcode,
			String free_rated_volume_volume, String free_rounded_volume_umcode,

			String free_rounded_volume_volume, String free_units_info_account_key,
			String free_units_info_account_origin, String free_units_info_acc_hist_id,
			String free_units_info_appl_method,

			String free_units_info_chg_red_quota, String free_units_info_discount_rate,
			String free_units_info_discount_type, String free_units_info_freeunitoption, String free_units_info_fup_seq,

			String free_units_info_fu_pack_id, String free_units_info_part_creator,
			String free_units_info_previous_seqno, String free_units_info_seqno, String free_units_info_version,

			String home_network_code, String hscsd_info_aiur, String hscsd_info_channels_max,
			String hscsd_info_channels_used, String hscsd_info_coding_acc, String hscsd_info_coding_used,

			String hscsd_info_fnur, String hscsd_info_init_party, String imp_party1_address,
			String imp_party1_alternate_tmcode, String imp_party1_an_package_id_list, String imp_party1_bill_cycle,

			String imp_party1_numbering_plan, String imp_party1_user_profile_id, String imp_party2_address,
			String imp_party2_alternate_tmcode, String imp_party2_an_package_id_list,

			String imp_party2_bill_cycle, String imp_party2_numbering_plan, String imp_party2_user_profile_id,
			String imp_party3_address, String imp_party3_alternate_tmcode,

			String imp_party3_an_package_id_list, String imp_party3_bill_cycle, String imp_party3_numbering_plan,
			String imp_party3_user_profile_id, String imp_party4_address,

			String imp_party4_alternate_tmcode, String imp_party4_an_package_id_list, String imp_party4_bill_cycle,
			String imp_party4_numbering_plan, String imp_party4_parent_contract_id,

			String imp_party4_user_profile_id, String imp_party5_address, String imp_party5_alternate_tmcode,
			String imp_party5_an_package_id_list, String imp_party5_bill_cycle,

			String imp_party5_numbering_plan, String imp_party5_parent_contract_id, String imp_party5_user_profile_id,
			String initial_start_time_timestamp, String initial_start_time_time_offset,

			String lcs_qos_deliv_horizontal_accur, String lcs_qos_deliv_tracking_frequen,
			String lcs_qos_deliv_tracking_period, String lcs_qos_deliv_vertical_accur,

			String lcs_qos_info_age_of_location, String lcs_qos_info_position_method, String lcs_qos_info_response_time,
			String lcs_qos_info_response_time_cat, String lcs_qos_req_horizontal_accur,

			String lcs_qos_req_tracking_frequency, String lcs_qos_req_tracking_period,
			String lcs_qos_req_vertical_accur, String ldc_info_carrier_code, String ldc_info_contract_pkey,

			String ldc_info_home_net_ind, String lec_info_contract_pkey, String lec_info_home_net_ind) {

		this.num_rowid_ogg = num_rowid_ogg;

		this.cod_ogg = cod_ogg;

		this.tpo_operacao_ogg = tpo_operacao_ogg;

		this.dat_ogg = dat_ogg;

		this.nom_sistema_ogg = nom_sistema_ogg;

		this.nom_interface_ogg = nom_interface_ogg;

		this.aggreg_info_aggreg_purpose = aggreg_info_aggreg_purpose;

		this.aggreg_info_agg_trans_id = aggreg_info_agg_trans_id;

		this.aggreg_info_applied_pack_id = aggreg_info_applied_pack_id;

		this.aggreg_info_rec_counter = aggreg_info_rec_counter;

		this.aggreg_info_summary_id = aggreg_info_summary_id;

		this.alt_rated_amount = alt_rated_amount;

		this.alt_rated_currency = alt_rated_currency;

		this.alt_tariff_clicks_volume = alt_tariff_clicks_volume;

		this.alt_tmcode = alt_tmcode;

		this.an_pack_an_package_id_list = an_pack_an_package_id_list;

		this.an_pack_orig_an_pack_id_list = an_pack_orig_an_pack_id_list;

		this.bal_audit_data_account_id = bal_audit_data_account_id;

		this.bal_audit_data_account_type = bal_audit_data_account_type;

		this.bal_audit_data_account_type_id = bal_audit_data_account_type_id;

		this.bal_audit_dat_balance_accum = bal_audit_dat_balance_accum;

		this.bal_audit_dat_balance_prod_id = bal_audit_dat_balance_prod_id;

		this.bal_audit_dat_balance_type = bal_audit_dat_balance_type;

		this.bal_audit_dat_bal_after_chg = bal_audit_dat_bal_after_chg;

		this.bal_audit_dat_bal_before_chg = bal_audit_dat_bal_before_chg;

		this.bal_audit_dat_bundl_prod_id = bal_audit_dat_bundl_prod_id;

		this.bal_audit_dat_contract_id = bal_audit_dat_contract_id;

		this.bal_audit_dat_offer_seqno = bal_audit_dat_offer_seqno;

		this.bal_audit_dat_offer_sncode = bal_audit_dat_offer_sncode;

		this.bal_audit_dat_prep_credit_ind = bal_audit_dat_prep_credit_ind;

		this.bal_audit_dat_purchase_seq_no = bal_audit_dat_purchase_seq_no;

		this.bal_audit_dat_shacc_packid = bal_audit_dat_shacc_packid;

		this.bal_audit_dat_user_profile_id = bal_audit_dat_user_profile_id;

		this.bop_info_bop_package_id = bop_info_bop_package_id;

		this.bop_info_bop_package_pkey = bop_info_bop_package_pkey;

		this.bop_info_bop_package_version = bop_info_bop_package_version;

		this.bop_info_detail_billed_ind = bop_info_detail_billed_ind;

		this.bop_info_detail_bop_altern_ind = bop_info_detail_bop_altern_ind;

		this.bop_info_detail_contracted_ind = bop_info_detail_contracted_ind;

		this.bop_info_detail_sequence_rp = bop_info_detail_sequence_rp;

		this.bop_info_detail_sequence_sp = bop_info_detail_sequence_sp;

		this.bop_tariff_info_day_catcode = bop_tariff_info_day_catcode;

		this.bop_tariff_info_egcode = bop_tariff_info_egcode;

		this.bop_tariff_info_egversion = bop_tariff_info_egversion;

		this.bop_tariff_info_gvcode = bop_tariff_info_gvcode;

		this.bop_tariff_info_rpcode = bop_tariff_info_rpcode;

		this.bop_tariff_info_rpversion = bop_tariff_info_rpversion;

		this.bop_tariff_info_sncode = bop_tariff_info_sncode;

		this.bop_tariff_info_spcode = bop_tariff_info_spcode;

		this.bop_tariff_info_time_band_code = bop_tariff_info_time_band_code;

		this.bop_tariff_info_tmcode = bop_tariff_info_tmcode;

		this.bop_tariff_info_tmversion = bop_tariff_info_tmversion;

		this.bop_tariff_info_tm_used_type = bop_tariff_info_tm_used_type;

		this.bop_tariff_info_twcode = bop_tariff_info_twcode;

		this.bop_tariff_info_usage_ind = bop_tariff_info_usage_ind;

		this.bop_tariff_info_zncode = bop_tariff_info_zncode;

		this.bop_tariff_info_zpcode = bop_tariff_info_zpcode;

		this.bpartn_sum_info_time_slice_lb = bpartn_sum_info_time_slice_lb;

		this.bpartn_sum_info_time_slice_rb = bpartn_sum_info_time_slice_rb;

		this.bundle_info_bundle_purchase_id = bundle_info_bundle_purchase_id;

		this.bundle_info_bundle_purch_ind = bundle_info_bundle_purch_ind;

		this.bundle_info_contract_id = bundle_info_contract_id;

		this.bundle_info_purchase_seq_no = bundle_info_purchase_seq_no;

		this.bundle_info_sequence_number = bundle_info_sequence_number;

		this.bundle_info_sncode = bundle_info_sncode;

		this.bundle_info_state = bundle_info_state;

		this.bundle_info_termination = bundle_info_termination;

		this.bundle_info_user_profile_id = bundle_info_user_profile_id;

		this.bundle_info_valid_from = bundle_info_valid_from;

		this.bundle_info_valid_to = bundle_info_valid_to;

		this.bundle_info_version = bundle_info_version;

		this.bundle_usg_bundle_covered_usg = bundle_usg_bundle_covered_usg;

		this.business_info_bs_id = business_info_bs_id;

		this.business_info_bs_version = business_info_bs_version;

		this.business_info_charge_item_id = business_info_charge_item_id;

		this.business_info_charge_party_id = business_info_charge_party_id;

		this.business_info_c_p_field_ref = business_info_c_p_field_ref;

		this.business_info_o_p_field_ref = business_info_o_p_field_ref;

		this.business_info_pre_bs_id = business_info_pre_bs_id;

		this.business_info_pre_bs_version = business_info_pre_bs_version;

		this.bus_partner_info_tax_mode = bus_partner_info_tax_mode;

		this.call_dest = call_dest;

		this.call_type = call_type;

		this.camel_dest_addr_user_prof_id = camel_dest_addr_user_prof_id;

		this.camel_msc_address = camel_msc_address;

		this.camel_msc_addr_user_prof_id = camel_msc_addr_user_prof_id;

		this.camel_reference_number = camel_reference_number;

		this.camel_srv_addr_user_prof_id = camel_srv_addr_user_prof_id;

		this.charge_info_cash_flow_direct = charge_info_cash_flow_direct;

		this.charge_info_disable_tax = charge_info_disable_tax;

		this.charging_characteristics = charging_characteristics;

		this.consumer_info_address = consumer_info_address;

		this.consumer_info_contract_id = consumer_info_contract_id;

		this.consumer_info_numbering_plan = consumer_info_numbering_plan;

		this.content_advised_charge_ind = content_advised_charge_ind;

		this.content_authorisation_code = content_authorisation_code;

		this.content_content_charging_point = content_content_charging_point;

		this.content_contract_pkey = content_contract_pkey;

		this.content_desc_suppress = content_desc_suppress;

		this.content_paid_ind = content_paid_ind;

		this.content_payment_method = content_payment_method;

		this.content_provider_address = content_provider_address;

		this.content_provider_carrier_code = content_provider_carrier_code;

		this.content_provider_clir = content_provider_clir;

		this.content_provider_iac = content_provider_iac;

		this.content_provider_modif_ind = content_provider_modif_ind;

		this.content_provider_network_code = content_provider_network_code;

		this.content_provid_dynamic_address = content_provid_dynamic_address;

		this.content_provid_local_pref_len = content_provid_local_pref_len;

		this.content_provid_numbering_plan = content_provid_numbering_plan;

		this.content_provid_other_location = content_provid_other_location;

		this.content_provid_type_of_number = content_provid_type_of_number;

		this.content_provid_user_profile_id = content_provid_user_profile_id;

		this.content_refund_ind = content_refund_ind;

		this.content_short_desc = content_short_desc;

		this.content_transaction_id = content_transaction_id;

		this.control_data_record_age = control_data_record_age;

		this.cug_info_cug_id = cug_info_cug_id;

		this.cug_info_cug_index = cug_info_cug_index;

		this.customer_info_contract_type_id = customer_info_contract_type_id;

		this.customer_info_contraggrpack_id = customer_info_contraggrpack_id;

		this.customer_info_reco_ind = customer_info_reco_ind;

		this.cust_info_address = cust_info_address;

		this.cust_info_alternate_tmcode = cust_info_alternate_tmcode;

		this.cust_info_an_package_id_list = cust_info_an_package_id_list;

		this.cust_info_bill_cycle = cust_info_bill_cycle;

		this.cust_info_bu_address = cust_info_bu_address;

		this.cust_info_bu_numbering_plan = cust_info_bu_numbering_plan;

		this.cust_info_charging_engine = cust_info_charging_engine;

		this.cust_info_contract_id = cust_info_contract_id;

		this.cust_info_customer_id = cust_info_customer_id;

		this.cust_info_delete_after_billing = cust_info_delete_after_billing;

		this.cust_info_dn_id = cust_info_dn_id;

		this.cust_info_main_msisdn = cust_info_main_msisdn;

		this.cust_info_numbering_plan = cust_info_numbering_plan;

		this.cust_info_port_id = cust_info_port_id;

		this.cust_info_serv_bid_id = cust_info_serv_bid_id;

		this.cust_info_sim_number = cust_info_sim_number;

		this.cust_info_sim_sernumber = cust_info_sim_sernumber;

		this.cust_info_subs_code = cust_info_subs_code;

		this.cust_info_subs_tag = cust_info_subs_tag;

		this.cust_info_user_profile_id = cust_info_user_profile_id;

		this.data_volume = data_volume;

		this.data_volume_umcode = data_volume_umcode;

		this.desc_prod_usage_long_desc = desc_prod_usage_long_desc;

		this.destination_field_id = destination_field_id;

		this.downlink_volume_umcode = downlink_volume_umcode;

		this.downlink_volume_volume = downlink_volume_volume;

		this.duration_umcode = duration_umcode;

		this.duration_volume = duration_volume;

		this.entry_date_offset = entry_date_offset;

		this.entry_date_timestamp = entry_date_timestamp;

		this.event_info_event_type = event_info_event_type;

		this.event_status_info_message_id = event_status_info_message_id;

		this.event_umcode = event_umcode;

		this.event_volume = event_volume;

		this.export_file = export_file;

		this.ext_balance_amnt_amount = ext_balance_amnt_amount;

		this.follow_up_call_type = follow_up_call_type;

		this.for_amount_amount = for_amount_amount;

		this.for_amount_currency = for_amount_currency;

		this.for_amount_gross_ind = for_amount_gross_ind;

		this.for_amount_tax = for_amount_tax;

		this.for_freechrg_amount = for_freechrg_amount;

		this.for_freechrg_currency = for_freechrg_currency;

		this.for_freechrg_gross_ind = for_freechrg_gross_ind;

		this.for_freechrg_tax = for_freechrg_tax;

		this.free_charge_amount = free_charge_amount;

		this.free_charge_amount_non_rpc = free_charge_amount_non_rpc;

		this.free_charge_currency = free_charge_currency;

		this.free_charge_curr_non_rpc = free_charge_curr_non_rpc;

		this.free_charge_gross_ind = free_charge_gross_ind;

		this.free_charge_gross_ind_nrpc = free_charge_gross_ind_nrpc;

		this.free_charge_tax = free_charge_tax;

		this.free_charge_tax_nrpc = free_charge_tax_nrpc;

		this.free_clicks_umcode = free_clicks_umcode;

		this.free_clicks_volume = free_clicks_volume;

		this.free_rated_volume_umcode = free_rated_volume_umcode;

		this.free_rated_volume_volume = free_rated_volume_volume;

		this.free_rounded_volume_umcode = free_rounded_volume_umcode;

		this.free_rounded_volume_volume = free_rounded_volume_volume;

		this.free_units_info_account_key = free_units_info_account_key;

		this.free_units_info_account_origin = free_units_info_account_origin;

		this.free_units_info_acc_hist_id = free_units_info_acc_hist_id;

		this.free_units_info_appl_method = free_units_info_appl_method;

		this.free_units_info_chg_red_quota = free_units_info_chg_red_quota;

		this.free_units_info_discount_rate = free_units_info_discount_rate;

		this.free_units_info_discount_type = free_units_info_discount_type;

		this.free_units_info_freeunitoption = free_units_info_freeunitoption;

		this.free_units_info_fup_seq = free_units_info_fup_seq;

		this.free_units_info_fu_pack_id = free_units_info_fu_pack_id;

		this.free_units_info_part_creator = free_units_info_part_creator;

		this.free_units_info_previous_seqno = free_units_info_previous_seqno;

		this.free_units_info_seqno = free_units_info_seqno;

		this.free_units_info_version = free_units_info_version;

		this.home_network_code = home_network_code;

		this.hscsd_info_aiur = hscsd_info_aiur;

		this.hscsd_info_channels_max = hscsd_info_channels_max;

		this.hscsd_info_channels_used = hscsd_info_channels_used;

		this.hscsd_info_coding_acc = hscsd_info_coding_acc;

		this.hscsd_info_coding_used = hscsd_info_coding_used;

		this.hscsd_info_fnur = hscsd_info_fnur;

		this.hscsd_info_init_party = hscsd_info_init_party;

		this.imp_party1_address = imp_party1_address;

		this.imp_party1_alternate_tmcode = imp_party1_alternate_tmcode;

		this.imp_party1_an_package_id_list = imp_party1_an_package_id_list;

		this.imp_party1_bill_cycle = imp_party1_bill_cycle;

		this.imp_party1_numbering_plan = imp_party1_numbering_plan;

		this.imp_party1_user_profile_id = imp_party1_user_profile_id;

		this.imp_party2_address = imp_party2_address;

		this.imp_party2_alternate_tmcode = imp_party2_alternate_tmcode;

		this.imp_party2_an_package_id_list = imp_party2_an_package_id_list;

		this.imp_party2_bill_cycle = imp_party2_bill_cycle;

		this.imp_party2_numbering_plan = imp_party2_numbering_plan;

		this.imp_party2_user_profile_id = imp_party2_user_profile_id;

		this.imp_party3_address = imp_party3_address;

		this.imp_party3_alternate_tmcode = imp_party3_alternate_tmcode;

		this.imp_party3_an_package_id_list = imp_party3_an_package_id_list;

		this.imp_party3_bill_cycle = imp_party3_bill_cycle;

		this.imp_party3_numbering_plan = imp_party3_numbering_plan;

		this.imp_party3_user_profile_id = imp_party3_user_profile_id;

		this.imp_party4_address = imp_party4_address;

		this.imp_party4_alternate_tmcode = imp_party4_alternate_tmcode;

		this.imp_party4_an_package_id_list = imp_party4_an_package_id_list;

		this.imp_party4_bill_cycle = imp_party4_bill_cycle;

		this.imp_party4_numbering_plan = imp_party4_numbering_plan;

		this.imp_party4_parent_contract_id = imp_party4_parent_contract_id;

		this.imp_party4_user_profile_id = imp_party4_user_profile_id;

		this.imp_party5_address = imp_party5_address;

		this.imp_party5_alternate_tmcode = imp_party5_alternate_tmcode;

		this.imp_party5_an_package_id_list = imp_party5_an_package_id_list;

		this.imp_party5_bill_cycle = imp_party5_bill_cycle;

		this.imp_party5_numbering_plan = imp_party5_numbering_plan;

		this.imp_party5_parent_contract_id = imp_party5_parent_contract_id;

		this.imp_party5_user_profile_id = imp_party5_user_profile_id;

		this.initial_start_time_timestamp = initial_start_time_timestamp;

		this.initial_start_time_time_offset = initial_start_time_time_offset;

		this.lcs_qos_deliv_horizontal_accur = lcs_qos_deliv_horizontal_accur;

		this.lcs_qos_deliv_tracking_frequen = lcs_qos_deliv_tracking_frequen;

		this.lcs_qos_deliv_tracking_period = lcs_qos_deliv_tracking_period;

		this.lcs_qos_deliv_vertical_accur = lcs_qos_deliv_vertical_accur;

		this.lcs_qos_info_age_of_location = lcs_qos_info_age_of_location;

		this.lcs_qos_info_position_method = lcs_qos_info_position_method;

		this.lcs_qos_info_response_time = lcs_qos_info_response_time;

		this.lcs_qos_info_response_time_cat = lcs_qos_info_response_time_cat;

		this.lcs_qos_req_horizontal_accur = lcs_qos_req_horizontal_accur;

		this.lcs_qos_req_tracking_frequency = lcs_qos_req_tracking_frequency;

		this.lcs_qos_req_tracking_period = lcs_qos_req_tracking_period;

		this.lcs_qos_req_vertical_accur = lcs_qos_req_vertical_accur;

		this.ldc_info_carrier_code = ldc_info_carrier_code;

		this.ldc_info_contract_pkey = ldc_info_contract_pkey;

		this.ldc_info_home_net_ind = ldc_info_home_net_ind;

		this.lec_info_contract_pkey = lec_info_contract_pkey;

		this.lec_info_home_net_ind = lec_info_home_net_ind;

	}

	/**
	 * 
	 * 
	 * O layout do começo do arquivo enviado pelo GG foi alterado.
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @param num_rowid_ogg
	 * 
	 * 
	 *                          removido
	 * 
	 * 
	 * @param cod_ogg
	 * 
	 * 
	 *                          removido
	 * 
	 * 
	 * @param tpo_operacao_ogg
	 * 
	 * 
	 *                          sem alteração
	 * 
	 * 
	 * @param nom_sistema_ogg
	 * 
	 * 
	 *                          alterado de ordem com a coluna dat_ogg
	 * 
	 * 
	 * @param dat_ogg
	 * 
	 * 
	 *                          alterado de ordem com a coluna nom_sistema_ogg
	 * 
	 * 
	 * @param nom_interface_off
	 * 
	 * 
	 *                          removido
	 * 
	 * 
	 */

	public void setTraftarBscs9_part1_fromDirectory(String tpo_operacao_ogg, String nom_sistema_ogg, String dat_ogg,
			String aggreg_info_aggreg_purpose, String aggreg_info_agg_trans_id,

			String aggreg_info_applied_pack_id, String aggreg_info_rec_counter, String aggreg_info_summary_id,
			String alt_rated_amount, String alt_rated_currency, String alt_tariff_clicks_volume,

			String alt_tmcode, String an_pack_an_package_id_list, String an_pack_orig_an_pack_id_list,
			String bal_audit_data_account_id, String bal_audit_data_account_type,

			String bal_audit_data_account_type_id, String bal_audit_dat_balance_accum,
			String bal_audit_dat_balance_prod_id, String bal_audit_dat_balance_type, String bal_audit_dat_bal_after_chg,

			String bal_audit_dat_bal_before_chg, String bal_audit_dat_bundl_prod_id, String bal_audit_dat_contract_id,
			String bal_audit_dat_offer_seqno, String bal_audit_dat_offer_sncode,

			String bal_audit_dat_prep_credit_ind, String bal_audit_dat_purchase_seq_no,
			String bal_audit_dat_shacc_packid, String bal_audit_dat_user_profile_id, String bop_info_bop_package_id,

			String bop_info_bop_package_pkey, String bop_info_bop_package_version, String bop_info_detail_billed_ind,
			String bop_info_detail_bop_altern_ind, String bop_info_detail_contracted_ind,

			String bop_info_detail_sequence_rp, String bop_info_detail_sequence_sp, String bop_tariff_info_day_catcode,
			String bop_tariff_info_egcode, String bop_tariff_info_egversion,

			String bop_tariff_info_gvcode, String bop_tariff_info_rpcode, String bop_tariff_info_rpversion,
			String bop_tariff_info_sncode, String bop_tariff_info_spcode,

			String bop_tariff_info_time_band_code, String bop_tariff_info_tmcode, String bop_tariff_info_tmversion,
			String bop_tariff_info_tm_used_type, String bop_tariff_info_twcode,

			String bop_tariff_info_usage_ind, String bop_tariff_info_zncode, String bop_tariff_info_zpcode,
			String bpartn_sum_info_time_slice_lb, String bpartn_sum_info_time_slice_rb,

			String bundle_info_bundle_purchase_id, String bundle_info_bundle_purch_ind, String bundle_info_contract_id,
			String bundle_info_purchase_seq_no, String bundle_info_sequence_number,

			String bundle_info_sncode, String bundle_info_state, String bundle_info_termination,
			String bundle_info_user_profile_id, String bundle_info_valid_from, String bundle_info_valid_to,

			String bundle_info_version, String bundle_usg_bundle_covered_usg, String business_info_bs_id,
			String business_info_bs_version, String business_info_charge_item_id,

			String business_info_charge_party_id, String business_info_c_p_field_ref,
			String business_info_o_p_field_ref, String business_info_pre_bs_id, String business_info_pre_bs_version,

			String bus_partner_info_tax_mode, String call_dest, String call_type, String camel_dest_addr_user_prof_id,
			String camel_msc_address, String camel_msc_addr_user_prof_id,

			String camel_reference_number, String camel_srv_addr_user_prof_id, String charge_info_cash_flow_direct,
			String charge_info_disable_tax, String charging_characteristics,

			String consumer_info_address, String consumer_info_contract_id, String consumer_info_numbering_plan,
			String content_advised_charge_ind, String content_authorisation_code,

			String content_content_charging_point, String content_contract_pkey, String content_desc_suppress,
			String content_paid_ind, String content_payment_method, String content_provider_address,

			String content_provider_carrier_code, String content_provider_clir, String content_provider_iac,
			String content_provider_modif_ind, String content_provider_network_code,

			String content_provid_dynamic_address, String content_provid_local_pref_len,
			String content_provid_numbering_plan, String content_provid_other_location,

			String content_provid_type_of_number, String content_provid_user_profile_id, String content_refund_ind,
			String content_short_desc, String content_transaction_id,

			String control_data_record_age, String cug_info_cug_id, String cug_info_cug_index,
			String customer_info_contract_type_id, String customer_info_contraggrpack_id,

			String customer_info_reco_ind, String cust_info_address, String cust_info_alternate_tmcode,
			String cust_info_an_package_id_list, String cust_info_bill_cycle, String cust_info_bu_address,

			String cust_info_bu_numbering_plan, String cust_info_charging_engine, String cust_info_contract_id,
			String cust_info_customer_id, String cust_info_delete_after_billing,

			String cust_info_dn_id, String cust_info_main_msisdn, String cust_info_numbering_plan,
			String cust_info_port_id, String cust_info_serv_bid_id, String cust_info_sim_number,

			String cust_info_sim_sernumber, String cust_info_subs_code, String cust_info_subs_tag,
			String cust_info_user_profile_id, String data_volume, String data_volume_umcode,

			String desc_prod_usage_long_desc, String destination_field_id, String downlink_volume_umcode,
			String downlink_volume_volume, String duration_umcode, String duration_volume,

			String entry_date_offset, String entry_date_timestamp, String event_info_event_type,
			String event_status_info_message_id, String event_umcode, String event_volume, String export_file,

			String ext_balance_amnt_amount, String follow_up_call_type, String for_amount_amount,
			String for_amount_currency, String for_amount_gross_ind, String for_amount_tax,

			String for_freechrg_amount, String for_freechrg_currency, String for_freechrg_gross_ind,
			String for_freechrg_tax, String free_charge_amount, String free_charge_amount_non_rpc,

			String free_charge_currency, String free_charge_curr_non_rpc, String free_charge_gross_ind,
			String free_charge_gross_ind_nrpc, String free_charge_tax, String free_charge_tax_nrpc,

			String free_clicks_umcode, String free_clicks_volume, String free_rated_volume_umcode,
			String free_rated_volume_volume, String free_rounded_volume_umcode,

			String free_rounded_volume_volume, String free_units_info_account_key,
			String free_units_info_account_origin, String free_units_info_acc_hist_id,
			String free_units_info_appl_method,

			String free_units_info_chg_red_quota, String free_units_info_discount_rate,
			String free_units_info_discount_type, String free_units_info_freeunitoption, String free_units_info_fup_seq,

			String free_units_info_fu_pack_id, String free_units_info_part_creator,
			String free_units_info_previous_seqno, String free_units_info_seqno, String free_units_info_version,

			String home_network_code, String hscsd_info_aiur, String hscsd_info_channels_max,
			String hscsd_info_channels_used, String hscsd_info_coding_acc, String hscsd_info_coding_used,

			String hscsd_info_fnur, String hscsd_info_init_party, String imp_party1_address,
			String imp_party1_alternate_tmcode, String imp_party1_an_package_id_list, String imp_party1_bill_cycle,

			String imp_party1_numbering_plan, String imp_party1_user_profile_id, String imp_party2_address,
			String imp_party2_alternate_tmcode, String imp_party2_an_package_id_list,

			String imp_party2_bill_cycle, String imp_party2_numbering_plan, String imp_party2_user_profile_id,
			String imp_party3_address, String imp_party3_alternate_tmcode,

			String imp_party3_an_package_id_list, String imp_party3_bill_cycle, String imp_party3_numbering_plan,
			String imp_party3_user_profile_id, String imp_party4_address,

			String imp_party4_alternate_tmcode, String imp_party4_an_package_id_list, String imp_party4_bill_cycle,
			String imp_party4_numbering_plan, String imp_party4_parent_contract_id,

			String imp_party4_user_profile_id, String imp_party5_address, String imp_party5_alternate_tmcode,
			String imp_party5_an_package_id_list, String imp_party5_bill_cycle,

			String imp_party5_numbering_plan, String imp_party5_parent_contract_id, String imp_party5_user_profile_id,
			String initial_start_time_timestamp, String initial_start_time_time_offset,

			String lcs_qos_deliv_horizontal_accur, String lcs_qos_deliv_tracking_frequen,
			String lcs_qos_deliv_tracking_period, String lcs_qos_deliv_vertical_accur,

			String lcs_qos_info_age_of_location, String lcs_qos_info_position_method, String lcs_qos_info_response_time,
			String lcs_qos_info_response_time_cat, String lcs_qos_req_horizontal_accur,

			String lcs_qos_req_tracking_frequency, String lcs_qos_req_tracking_period,
			String lcs_qos_req_vertical_accur, String ldc_info_carrier_code, String ldc_info_contract_pkey,

			String ldc_info_home_net_ind, String lec_info_contract_pkey, String lec_info_home_net_ind) {

		this.setTraftarBscs9_part1("", "", tpo_operacao_ogg, dat_ogg, nom_sistema_ogg, "", aggreg_info_aggreg_purpose,
				aggreg_info_agg_trans_id, aggreg_info_applied_pack_id, aggreg_info_rec_counter,

				aggreg_info_summary_id, alt_rated_amount, alt_rated_currency, alt_tariff_clicks_volume, alt_tmcode,
				an_pack_an_package_id_list, an_pack_orig_an_pack_id_list, bal_audit_data_account_id,

				bal_audit_data_account_type, bal_audit_data_account_type_id, bal_audit_dat_balance_accum,
				bal_audit_dat_balance_prod_id, bal_audit_dat_balance_type, bal_audit_dat_bal_after_chg,

				bal_audit_dat_bal_before_chg, bal_audit_dat_bundl_prod_id, bal_audit_dat_contract_id,
				bal_audit_dat_offer_seqno, bal_audit_dat_offer_sncode, bal_audit_dat_prep_credit_ind,

				bal_audit_dat_purchase_seq_no, bal_audit_dat_shacc_packid, bal_audit_dat_user_profile_id,
				bop_info_bop_package_id, bop_info_bop_package_pkey, bop_info_bop_package_version,

				bop_info_detail_billed_ind, bop_info_detail_bop_altern_ind, bop_info_detail_contracted_ind,
				bop_info_detail_sequence_rp, bop_info_detail_sequence_sp, bop_tariff_info_day_catcode,

				bop_tariff_info_egcode, bop_tariff_info_egversion, bop_tariff_info_gvcode, bop_tariff_info_rpcode,
				bop_tariff_info_rpversion, bop_tariff_info_sncode, bop_tariff_info_spcode,

				bop_tariff_info_time_band_code, bop_tariff_info_tmcode, bop_tariff_info_tmversion,
				bop_tariff_info_tm_used_type, bop_tariff_info_twcode, bop_tariff_info_usage_ind,

				bop_tariff_info_zncode, bop_tariff_info_zpcode, bpartn_sum_info_time_slice_lb,
				bpartn_sum_info_time_slice_rb, bundle_info_bundle_purchase_id, bundle_info_bundle_purch_ind,

				bundle_info_contract_id, bundle_info_purchase_seq_no, bundle_info_sequence_number, bundle_info_sncode,
				bundle_info_state, bundle_info_termination, bundle_info_user_profile_id,

				bundle_info_valid_from, bundle_info_valid_to, bundle_info_version, bundle_usg_bundle_covered_usg,
				business_info_bs_id, business_info_bs_version, business_info_charge_item_id,

				business_info_charge_party_id, business_info_c_p_field_ref, business_info_o_p_field_ref,
				business_info_pre_bs_id, business_info_pre_bs_version, bus_partner_info_tax_mode, call_dest,

				call_type, camel_dest_addr_user_prof_id, camel_msc_address, camel_msc_addr_user_prof_id,
				camel_reference_number, camel_srv_addr_user_prof_id, charge_info_cash_flow_direct,

				charge_info_disable_tax, charging_characteristics, consumer_info_address, consumer_info_contract_id,
				consumer_info_numbering_plan, content_advised_charge_ind,

				content_authorisation_code, content_content_charging_point, content_contract_pkey,
				content_desc_suppress, content_paid_ind, content_payment_method, content_provider_address,

				content_provider_carrier_code, content_provider_clir, content_provider_iac, content_provider_modif_ind,
				content_provider_network_code, content_provid_dynamic_address,

				content_provid_local_pref_len, content_provid_numbering_plan, content_provid_other_location,
				content_provid_type_of_number, content_provid_user_profile_id, content_refund_ind,

				content_short_desc, content_transaction_id, control_data_record_age, cug_info_cug_id,
				cug_info_cug_index, customer_info_contract_type_id, customer_info_contraggrpack_id,

				customer_info_reco_ind, cust_info_address, cust_info_alternate_tmcode, cust_info_an_package_id_list,
				cust_info_bill_cycle, cust_info_bu_address, cust_info_bu_numbering_plan,

				cust_info_charging_engine, cust_info_contract_id, cust_info_customer_id, cust_info_delete_after_billing,
				cust_info_dn_id, cust_info_main_msisdn, cust_info_numbering_plan,

				cust_info_port_id, cust_info_serv_bid_id, cust_info_sim_number, cust_info_sim_sernumber,
				cust_info_subs_code, cust_info_subs_tag, cust_info_user_profile_id, data_volume,

				data_volume_umcode, desc_prod_usage_long_desc, destination_field_id, downlink_volume_umcode,
				downlink_volume_volume, duration_umcode, duration_volume, entry_date_offset,

				entry_date_timestamp, event_info_event_type, event_status_info_message_id, event_umcode, event_volume,
				export_file, ext_balance_amnt_amount, follow_up_call_type, for_amount_amount,

				for_amount_currency, for_amount_gross_ind, for_amount_tax, for_freechrg_amount, for_freechrg_currency,
				for_freechrg_gross_ind, for_freechrg_tax, free_charge_amount,

				free_charge_amount_non_rpc, free_charge_currency, free_charge_curr_non_rpc, free_charge_gross_ind,
				free_charge_gross_ind_nrpc, free_charge_tax, free_charge_tax_nrpc,

				free_clicks_umcode, free_clicks_volume, free_rated_volume_umcode, free_rated_volume_volume,
				free_rounded_volume_umcode, free_rounded_volume_volume, free_units_info_account_key,

				free_units_info_account_origin, free_units_info_acc_hist_id, free_units_info_appl_method,
				free_units_info_chg_red_quota, free_units_info_discount_rate, free_units_info_discount_type,

				free_units_info_freeunitoption, free_units_info_fup_seq, free_units_info_fu_pack_id,
				free_units_info_part_creator, free_units_info_previous_seqno, free_units_info_seqno,

				free_units_info_version, home_network_code, hscsd_info_aiur, hscsd_info_channels_max,
				hscsd_info_channels_used, hscsd_info_coding_acc, hscsd_info_coding_used, hscsd_info_fnur,

				hscsd_info_init_party, imp_party1_address, imp_party1_alternate_tmcode, imp_party1_an_package_id_list,
				imp_party1_bill_cycle, imp_party1_numbering_plan, imp_party1_user_profile_id,

				imp_party2_address, imp_party2_alternate_tmcode, imp_party2_an_package_id_list, imp_party2_bill_cycle,
				imp_party2_numbering_plan, imp_party2_user_profile_id, imp_party3_address,

				imp_party3_alternate_tmcode, imp_party3_an_package_id_list, imp_party3_bill_cycle,
				imp_party3_numbering_plan, imp_party3_user_profile_id, imp_party4_address,

				imp_party4_alternate_tmcode, imp_party4_an_package_id_list, imp_party4_bill_cycle,
				imp_party4_numbering_plan, imp_party4_parent_contract_id, imp_party4_user_profile_id,

				imp_party5_address, imp_party5_alternate_tmcode, imp_party5_an_package_id_list, imp_party5_bill_cycle,
				imp_party5_numbering_plan, imp_party5_parent_contract_id,

				imp_party5_user_profile_id, initial_start_time_timestamp, initial_start_time_time_offset,
				lcs_qos_deliv_horizontal_accur, lcs_qos_deliv_tracking_frequen, lcs_qos_deliv_tracking_period,

				lcs_qos_deliv_vertical_accur, lcs_qos_info_age_of_location, lcs_qos_info_position_method,
				lcs_qos_info_response_time, lcs_qos_info_response_time_cat, lcs_qos_req_horizontal_accur,

				lcs_qos_req_tracking_frequency, lcs_qos_req_tracking_period, lcs_qos_req_vertical_accur,
				ldc_info_carrier_code, ldc_info_contract_pkey, ldc_info_home_net_ind, lec_info_contract_pkey,

				lec_info_home_net_ind);

	}

	public void setTraftarBscs9_part2(String lzlist, String mc_info_code, String mc_info_ind,
			String mc_info_micro_cell_information, String mc_scalefactor, String messages_umcode,

			String messages_volume, String micro_cell_imcscalefactortype, String micro_cell_mc_code,
			String micro_cell_mc_pkey, String micro_cell_mc_type, String micro_cell_scalefactor,

			String network_init_context_ind, String net_element_home_bid_id, String net_element_network_code,
			String net_element_netw_element_id, String net_element_user_profile_id,

			String normed_net_elem_address, String normed_net_elem_int_acc_code, String normed_net_elem_number_plan,
			String normed_rtd_num_address, String normed_rtd_num_int_acc_code,

			String normed_rtd_num_number_plan, String normtrkgrp_in_address, String normtrkgrp_in_numberingplan,
			String normtrkgrp_out_address, String normtrkgrp_out_numberingplan,

			String number_of_rejections, String offer_offer_seqno, String offer_offer_sncode, String origin_field_id,
			String orig_entry_date_timestamp, String orig_entry_date_timezone_id,

			String orig_entry_date_timezone_pkey, String orig_entry_date_time_offset, String or_flag,
			String o_p_normed_num_address, String o_p_normed_num_int_acc_code,

			String o_p_normed_num_number_plan, String o_p_number_address, String o_p_number_backup_address,
			String o_p_number_carrier_code, String o_p_number_clir, String o_p_number_numbering_plan,

			String o_p_number_other_location, String o_p_number_type_of_number, String o_p_number_user_profile_id,
			String o_p_pubid_address, String o_p_pubid_numbering_plan,

			String o_p_pubid_type_of_number, String price_plan_info_chrgplanid, String price_plan_info_evalquantity,
			String price_plan_info_threshold, String promo_info_b_number_cat,

			String qos_negot_delay, String qos_negot_mean_throughput, String qos_negot_peak_throughput,
			String qos_negot_precedence, String qos_negot_reliability, String qos_profile,

			String qos_req_delay, String qos_req_mean_throughput, String qos_req_peak_throughput,
			String qos_req_precedence, String qos_req_reliability, String rated_clicks_umcode,

			String rated_clicks_volume, String rated_flat_amnt_gross_ind_nrpc, String rated_flat_amnt_orig_currency,
			String rated_flat_amnt_orig_gross_ind, String rated_flat_amnt_tax_nrpc,

			String rated_flat_amount, String rated_flat_amount_currency, String rated_flat_amount_gross_ind,
			String rated_flat_amount_non_rpc, String rated_flat_amount_non_rpc_curr,

			String rated_flat_amount_orig_amount, String rated_flat_amount_orig_tax, String rated_flat_amount_tax,
			String rated_volume, String rated_volume_umcode, String recipient_net_address,

			String recipient_net_numbering_plan, String record_id_call_id, String record_id_cdr_id,
			String record_id_cdr_sub_id, String record_id_event_ref, String record_id_orig_cdr_id,

			String record_id_rap_sequence_num, String record_id_rerate_seqno, String record_id_shaacc_unique_id,
			String record_id_tap_sequence_num, String record_id_udr_file_id,

			String record_type_record_category, String record_type_summary_ind, String refer_contr_contract_id,
			String refer_contr_reference_type, String rejected_base_part, String reject_reason_code,

			String remark, String rerate_info_rerate_reason_id, String rerate_info_rerate_record_type,
			String rerate_info_rerate_request_id, String rerate_info_urh_id, String rounded_volume,

			String rounded_volume_umcode, String routing_network_code, String routing_number_backup_address,
			String routing_user_profile_id, String scu_id_address, String scu_id_user_profile_id,

			String scu_info_priority_code, String service_action_code, String service_guaranteed_bit_rate,
			String service_hscsd_ind, String service_ims_signalling_context, String service_logic_code,

			String service_max_bit_rate, String service_service_type, String service_used_service,
			String service_user_protocol_ind, String service_vas_code, String serv_pdp_addr_apn_split_ind,

			String sgsn_addresses, String spec_num_info_apply_free_units, String start_time_charge_offset,
			String start_time_charge_timestamp, String start_time_offset, String start_time_timestamp,

			String sum_reference_single_id, String s_pdp_address, String s_pdp_carrier_code, String s_pdp_clir,
			String s_pdp_intern_access_code, String s_pdp_modification_ind,

			String s_pdp_network_code, String s_pdp_numbering_plan, String s_pdp_type_of_number,
			String s_pdp_user_profile_id, String s_p_equipment_class_mark, String s_p_equipment_number,

			String s_p_home_id_description, String s_p_home_id_home_bid_id, String s_p_home_id_name,
			String s_p_home_id_network, String s_p_home_loc_address, String s_p_home_loc_numbering_plan,

			String s_p_location_address, String s_p_location_numbering_plan, String s_p_loc_serving_bid_id,
			String s_p_loc_serving_location, String s_p_number_address, String s_p_number_home_bid_id,

			String s_p_number_network_code, String s_p_number_numbering_plan, String s_p_number_user_profile_id,
			String s_p_port_address, String s_p_port_numbering_plan,

			String s_p_port_user_profile_id, String tariff_detail_chgbl_quantity, String tariff_detail_ext_chrg_udmcode,
			String tariff_detail_interconnect_ind, String tariff_detail_rate_type_id,

			String tariff_detail_rtx_charge_type, String tariff_detail_ttcode, String tariff_info_catalogue_id,
			String tariff_info_catalogue_vers, String tariff_info_ctlg_elm_id,

			String tariff_info_egcode, String tariff_info_egversion, String tariff_info_gvcode,
			String tariff_info_pricelist_id, String tariff_info_pricelist_pkey, String tariff_info_pricelist_vers,

			String tariff_info_price_def_vers, String tariff_info_rpcode, String tariff_info_rpversion,
			String tariff_info_sncode, String tariff_info_spcode, String tariff_info_time_band_code,

			String tariff_info_tmcode, String tariff_info_tmversion, String tariff_info_tm_used_type,
			String tariff_info_twcode, String tariff_info_usage_ind, String tariff_info_zncode,

			String tariff_info_zpcode, String tariff_info_zpcode_day_catcode, String tax_info_serv_cat,
			String tax_info_serv_code, String tax_info_serv_type, String techn_info_fixed_mobile_ind,

			String techn_info_home_terminated_ind, String techn_info_prepay_ind, String techn_info_pre_rated_ind,
			String techn_info_rev_charging_ind, String techn_info_sccode,

			String techn_info_termination_ind, String trunk_group_in_address, String trunk_group_in_numberingplan,
			String trunk_group_in_typeofnumber, String trunk_group_out_address,

			String trunk_group_out_numberingplan, String trunk_group_out_typeofnumber,
			String t_p_number_user_profile_id, String udr_basepart_id, String udr_chargepart_id,
			String uds_base_part_id,

			String uds_charge_part_id, String uds_free_unit_part_id, String uds_promotion_part_id, String uds_record_id,
			String uds_stream_id, String umts_qos_negot_allc_retn_prior,

			String umts_qos_negot_delay, String umts_qos_negot_delivery_order, String umts_qos_negot_erroneous_sdus,
			String umts_qos_negot_handl_priority, String umts_qos_negot_max_size_sdu,

			String umts_qos_negot_rate_downlink, String umts_qos_negot_rate_uplink, String umts_qos_negot_residual_ber,
			String umts_qos_negot_sdu_err_ratio, String umts_qos_negot_traffic_class,

			String umts_qos_req_allc_retn_prior, String umts_qos_req_delay, String umts_qos_req_delivery_order,
			String umts_qos_req_erroneous_sdus, String umts_qos_req_handl_priority,

			String umts_qos_req_max_size_sdu, String umts_qos_req_rate_downlink, String umts_qos_req_rate_uplink,
			String umts_qos_req_residual_ber, String umts_qos_req_sdu_error_ratio,

			String umts_qos_req_traffic_class, String unbilledamtpaymresp_customerid, String unbilled_amount_amount,
			String unbilled_amount_currency, String unbilled_amount_gross_ind,

			String unbilled_amount_tax, String uplink_volume_umcode, String uplink_volume_volume,
			String vpn_info_vpn_call_type, String vpn_number_address, String vpn_number_carrier_code,

			String vpn_number_clir, String vpn_number_dynamic_address, String vpn_number_int_access_code,
			String vpn_number_local_prefix_len, String vpn_number_modification_ind,

			String vpn_number_network_code, String vpn_number_numbering_plan, String vpn_number_type_of_number,
			String vpn_number_user_profile_id) {

		this.lzlist = lzlist;

		this.mc_info_code = mc_info_code;

		this.mc_info_ind = mc_info_ind;

		this.mc_info_micro_cell_information = mc_info_micro_cell_information;

		this.mc_scalefactor = mc_scalefactor;

		this.messages_umcode = messages_umcode;

		this.messages_volume = messages_volume;

		this.micro_cell_imcscalefactortype = micro_cell_imcscalefactortype;

		this.micro_cell_mc_code = micro_cell_mc_code;

		this.micro_cell_mc_pkey = micro_cell_mc_pkey;

		this.micro_cell_mc_type = micro_cell_mc_type;

		this.micro_cell_scalefactor = micro_cell_scalefactor;

		this.network_init_context_ind = network_init_context_ind;

		this.net_element_home_bid_id = net_element_home_bid_id;

		this.net_element_network_code = net_element_network_code;

		this.net_element_netw_element_id = net_element_netw_element_id;

		this.net_element_user_profile_id = net_element_user_profile_id;

		this.normed_net_elem_address = normed_net_elem_address;

		this.normed_net_elem_int_acc_code = normed_net_elem_int_acc_code;

		this.normed_net_elem_number_plan = normed_net_elem_number_plan;

		this.normed_rtd_num_address = normed_rtd_num_address;

		this.normed_rtd_num_int_acc_code = normed_rtd_num_int_acc_code;

		this.normed_rtd_num_number_plan = normed_rtd_num_number_plan;

		this.normtrkgrp_in_address = normtrkgrp_in_address;

		this.normtrkgrp_in_numberingplan = normtrkgrp_in_numberingplan;

		this.normtrkgrp_out_address = normtrkgrp_out_address;

		this.normtrkgrp_out_numberingplan = normtrkgrp_out_numberingplan;

		this.number_of_rejections = number_of_rejections;

		this.offer_offer_seqno = offer_offer_seqno;

		this.offer_offer_sncode = offer_offer_sncode;

		this.origin_field_id = origin_field_id;

		this.orig_entry_date_timestamp = orig_entry_date_timestamp;

		this.orig_entry_date_timezone_id = orig_entry_date_timezone_id;

		this.orig_entry_date_timezone_pkey = orig_entry_date_timezone_pkey;

		this.orig_entry_date_time_offset = orig_entry_date_time_offset;

		this.or_flag = or_flag;

		this.o_p_normed_num_address = o_p_normed_num_address;

		this.o_p_normed_num_int_acc_code = o_p_normed_num_int_acc_code;

		this.o_p_normed_num_number_plan = o_p_normed_num_number_plan;

		this.o_p_number_address = o_p_number_address;

		this.o_p_number_backup_address = o_p_number_backup_address;

		this.o_p_number_carrier_code = o_p_number_carrier_code;

		this.o_p_number_clir = o_p_number_clir;

		this.o_p_number_numbering_plan = o_p_number_numbering_plan;

		this.o_p_number_other_location = o_p_number_other_location;

		this.o_p_number_type_of_number = o_p_number_type_of_number;

		this.o_p_number_user_profile_id = o_p_number_user_profile_id;

		this.o_p_pubid_address = o_p_pubid_address;

		this.o_p_pubid_numbering_plan = o_p_pubid_numbering_plan;

		this.o_p_pubid_type_of_number = o_p_pubid_type_of_number;

		this.price_plan_info_chrgplanid = price_plan_info_chrgplanid;

		this.price_plan_info_evalquantity = price_plan_info_evalquantity;

		this.price_plan_info_threshold = price_plan_info_threshold;

		this.promo_info_b_number_cat = promo_info_b_number_cat;

		this.qos_negot_delay = qos_negot_delay;

		this.qos_negot_mean_throughput = qos_negot_mean_throughput;

		this.qos_negot_peak_throughput = qos_negot_peak_throughput;

		this.qos_negot_precedence = qos_negot_precedence;

		this.qos_negot_reliability = qos_negot_reliability;

		this.qos_profile = qos_profile;

		this.qos_req_delay = qos_req_delay;

		this.qos_req_mean_throughput = qos_req_mean_throughput;

		this.qos_req_peak_throughput = qos_req_peak_throughput;

		this.qos_req_precedence = qos_req_precedence;

		this.qos_req_reliability = qos_req_reliability;

		this.rated_clicks_umcode = rated_clicks_umcode;

		this.rated_clicks_volume = rated_clicks_volume;

		this.rated_flat_amnt_gross_ind_nrpc = rated_flat_amnt_gross_ind_nrpc;

		this.rated_flat_amnt_orig_currency = rated_flat_amnt_orig_currency;

		this.rated_flat_amnt_orig_gross_ind = rated_flat_amnt_orig_gross_ind;

		this.rated_flat_amnt_tax_nrpc = rated_flat_amnt_tax_nrpc;

		this.rated_flat_amount = rated_flat_amount;

		this.rated_flat_amount_currency = rated_flat_amount_currency;

		this.rated_flat_amount_gross_ind = rated_flat_amount_gross_ind;

		this.rated_flat_amount_non_rpc = rated_flat_amount_non_rpc;

		this.rated_flat_amount_non_rpc_curr = rated_flat_amount_non_rpc_curr;

		this.rated_flat_amount_orig_amount = rated_flat_amount_orig_amount;

		this.rated_flat_amount_orig_tax = rated_flat_amount_orig_tax;

		this.rated_flat_amount_tax = rated_flat_amount_tax;

		this.rated_volume = rated_volume;

		this.rated_volume_umcode = rated_volume_umcode;

		this.recipient_net_address = recipient_net_address;

		this.recipient_net_numbering_plan = recipient_net_numbering_plan;

		this.record_id_call_id = record_id_call_id;

		this.record_id_cdr_id = record_id_cdr_id;

		this.record_id_cdr_sub_id = record_id_cdr_sub_id;

		this.record_id_event_ref = record_id_event_ref;

		this.record_id_orig_cdr_id = record_id_orig_cdr_id;

		this.record_id_rap_sequence_num = record_id_rap_sequence_num;

		this.record_id_rerate_seqno = record_id_rerate_seqno;

		this.record_id_shaacc_unique_id = record_id_shaacc_unique_id;

		this.record_id_tap_sequence_num = record_id_tap_sequence_num;

		this.record_id_udr_file_id = record_id_udr_file_id;

		this.record_type_record_category = record_type_record_category;

		this.record_type_summary_ind = record_type_summary_ind;

		this.refer_contr_contract_id = refer_contr_contract_id;

		this.refer_contr_reference_type = refer_contr_reference_type;

		this.rejected_base_part = rejected_base_part;

		this.reject_reason_code = reject_reason_code;

		this.remark = remark;

		this.rerate_info_rerate_reason_id = rerate_info_rerate_reason_id;

		this.rerate_info_rerate_record_type = rerate_info_rerate_record_type;

		this.rerate_info_rerate_request_id = rerate_info_rerate_request_id;

		this.rerate_info_urh_id = rerate_info_urh_id;

		this.rounded_volume = rounded_volume;

		this.rounded_volume_umcode = rounded_volume_umcode;

		this.routing_network_code = routing_network_code;

		this.routing_number_backup_address = routing_number_backup_address;

		this.routing_user_profile_id = routing_user_profile_id;

		this.scu_id_address = scu_id_address;

		this.scu_id_user_profile_id = scu_id_user_profile_id;

		this.scu_info_priority_code = scu_info_priority_code;

		this.service_action_code = service_action_code;

		this.service_guaranteed_bit_rate = service_guaranteed_bit_rate;

		this.service_hscsd_ind = service_hscsd_ind;

		this.service_ims_signalling_context = service_ims_signalling_context;

		this.service_logic_code = service_logic_code;

		this.service_max_bit_rate = service_max_bit_rate;

		this.service_service_type = service_service_type;

		this.service_used_service = service_used_service;

		this.service_user_protocol_ind = service_user_protocol_ind;

		this.service_vas_code = service_vas_code;

		this.serv_pdp_addr_apn_split_ind = serv_pdp_addr_apn_split_ind;

		this.sgsn_addresses = sgsn_addresses;

		this.spec_num_info_apply_free_units = spec_num_info_apply_free_units;

		this.start_time_charge_offset = start_time_charge_offset;

		this.start_time_charge_timestamp = start_time_charge_timestamp;

		this.start_time_offset = start_time_offset;

		this.start_time_timestamp = start_time_timestamp;

		this.sum_reference_single_id = sum_reference_single_id;

		this.s_pdp_address = s_pdp_address;

		this.s_pdp_carrier_code = s_pdp_carrier_code;

		this.s_pdp_clir = s_pdp_clir;

		this.s_pdp_intern_access_code = s_pdp_intern_access_code;

		this.s_pdp_modification_ind = s_pdp_modification_ind;

		this.s_pdp_network_code = s_pdp_network_code;

		this.s_pdp_numbering_plan = s_pdp_numbering_plan;

		this.s_pdp_type_of_number = s_pdp_type_of_number;

		this.s_pdp_user_profile_id = s_pdp_user_profile_id;

		this.s_p_equipment_class_mark = s_p_equipment_class_mark;

		this.s_p_equipment_number = s_p_equipment_number;

		this.s_p_home_id_description = s_p_home_id_description;

		this.s_p_home_id_home_bid_id = s_p_home_id_home_bid_id;

		this.s_p_home_id_name = s_p_home_id_name;

		this.s_p_home_id_network = s_p_home_id_network;

		this.s_p_home_loc_address = s_p_home_loc_address;

		this.s_p_home_loc_numbering_plan = s_p_home_loc_numbering_plan;

		this.s_p_location_address = s_p_location_address;

		this.s_p_location_numbering_plan = s_p_location_numbering_plan;

		this.s_p_loc_serving_bid_id = s_p_loc_serving_bid_id;

		this.s_p_loc_serving_location = s_p_loc_serving_location;

		this.s_p_number_address = s_p_number_address;

		this.s_p_number_home_bid_id = s_p_number_home_bid_id;

		this.s_p_number_network_code = s_p_number_network_code;

		this.s_p_number_numbering_plan = s_p_number_numbering_plan;

		this.s_p_number_user_profile_id = s_p_number_user_profile_id;

		this.s_p_port_address = s_p_port_address;

		this.s_p_port_numbering_plan = s_p_port_numbering_plan;

		this.s_p_port_user_profile_id = s_p_port_user_profile_id;

		this.tariff_detail_chgbl_quantity = tariff_detail_chgbl_quantity;

		this.tariff_detail_ext_chrg_udmcode = tariff_detail_ext_chrg_udmcode;

		this.tariff_detail_interconnect_ind = tariff_detail_interconnect_ind;

		this.tariff_detail_rate_type_id = tariff_detail_rate_type_id;

		this.tariff_detail_rtx_charge_type = tariff_detail_rtx_charge_type;

		this.tariff_detail_ttcode = tariff_detail_ttcode;

		this.tariff_info_catalogue_id = tariff_info_catalogue_id;

		this.tariff_info_catalogue_vers = tariff_info_catalogue_vers;

		this.tariff_info_ctlg_elm_id = tariff_info_ctlg_elm_id;

		this.tariff_info_egcode = tariff_info_egcode;

		this.tariff_info_egversion = tariff_info_egversion;

		this.tariff_info_gvcode = tariff_info_gvcode;

		this.tariff_info_pricelist_id = tariff_info_pricelist_id;

		this.tariff_info_pricelist_pkey = tariff_info_pricelist_pkey;

		this.tariff_info_pricelist_vers = tariff_info_pricelist_vers;

		this.tariff_info_price_def_vers = tariff_info_price_def_vers;

		this.tariff_info_rpcode = tariff_info_rpcode;

		this.tariff_info_rpversion = tariff_info_rpversion;

		this.tariff_info_sncode = tariff_info_sncode;

		this.tariff_info_spcode = tariff_info_spcode;

		this.tariff_info_time_band_code = tariff_info_time_band_code;

		this.tariff_info_tmcode = tariff_info_tmcode;

		this.tariff_info_tmversion = tariff_info_tmversion;

		this.tariff_info_tm_used_type = tariff_info_tm_used_type;

		this.tariff_info_twcode = tariff_info_twcode;

		this.tariff_info_usage_ind = tariff_info_usage_ind;

		this.tariff_info_zncode = tariff_info_zncode;

		this.tariff_info_zpcode = tariff_info_zpcode;

		this.tariff_info_zpcode_day_catcode = tariff_info_zpcode_day_catcode;

		this.tax_info_serv_cat = tax_info_serv_cat;

		this.tax_info_serv_code = tax_info_serv_code;

		this.tax_info_serv_type = tax_info_serv_type;

		this.techn_info_fixed_mobile_ind = techn_info_fixed_mobile_ind;

		this.techn_info_home_terminated_ind = techn_info_home_terminated_ind;

		this.techn_info_prepay_ind = techn_info_prepay_ind;

		this.techn_info_pre_rated_ind = techn_info_pre_rated_ind;

		this.techn_info_rev_charging_ind = techn_info_rev_charging_ind;

		this.techn_info_sccode = techn_info_sccode;

		this.techn_info_termination_ind = techn_info_termination_ind;

		this.trunk_group_in_address = trunk_group_in_address;

		this.trunk_group_in_numberingplan = trunk_group_in_numberingplan;

		this.trunk_group_in_typeofnumber = trunk_group_in_typeofnumber;

		this.trunk_group_out_address = trunk_group_out_address;

		this.trunk_group_out_numberingplan = trunk_group_out_numberingplan;

		this.trunk_group_out_typeofnumber = trunk_group_out_typeofnumber;

		this.t_p_number_user_profile_id = t_p_number_user_profile_id;

		this.udr_basepart_id = udr_basepart_id;

		this.udr_chargepart_id = udr_chargepart_id;

		this.uds_base_part_id = uds_base_part_id;

		this.uds_charge_part_id = uds_charge_part_id;

		this.uds_free_unit_part_id = uds_free_unit_part_id;

		this.uds_promotion_part_id = uds_promotion_part_id;

		this.uds_record_id = uds_record_id;

		this.uds_stream_id = uds_stream_id;

		this.umts_qos_negot_allc_retn_prior = umts_qos_negot_allc_retn_prior;

		this.umts_qos_negot_delay = umts_qos_negot_delay;

		this.umts_qos_negot_delivery_order = umts_qos_negot_delivery_order;

		this.umts_qos_negot_erroneous_sdus = umts_qos_negot_erroneous_sdus;

		this.umts_qos_negot_handl_priority = umts_qos_negot_handl_priority;

		this.umts_qos_negot_max_size_sdu = umts_qos_negot_max_size_sdu;

		this.umts_qos_negot_rate_downlink = umts_qos_negot_rate_downlink;

		this.umts_qos_negot_rate_uplink = umts_qos_negot_rate_uplink;

		this.umts_qos_negot_residual_ber = umts_qos_negot_residual_ber;

		this.umts_qos_negot_sdu_err_ratio = umts_qos_negot_sdu_err_ratio;

		this.umts_qos_negot_traffic_class = umts_qos_negot_traffic_class;

		this.umts_qos_req_allc_retn_prior = umts_qos_req_allc_retn_prior;

		this.umts_qos_req_delay = umts_qos_req_delay;

		this.umts_qos_req_delivery_order = umts_qos_req_delivery_order;

		this.umts_qos_req_erroneous_sdus = umts_qos_req_erroneous_sdus;

		this.umts_qos_req_handl_priority = umts_qos_req_handl_priority;

		this.umts_qos_req_max_size_sdu = umts_qos_req_max_size_sdu;

		this.umts_qos_req_rate_downlink = umts_qos_req_rate_downlink;

		this.umts_qos_req_rate_uplink = umts_qos_req_rate_uplink;

		this.umts_qos_req_residual_ber = umts_qos_req_residual_ber;

		this.umts_qos_req_sdu_error_ratio = umts_qos_req_sdu_error_ratio;

		this.umts_qos_req_traffic_class = umts_qos_req_traffic_class;

		this.unbilledamtpaymresp_customerid = unbilledamtpaymresp_customerid;

		this.unbilled_amount_amount = unbilled_amount_amount;

		this.unbilled_amount_currency = unbilled_amount_currency;

		this.unbilled_amount_gross_ind = unbilled_amount_gross_ind;

		this.unbilled_amount_tax = unbilled_amount_tax;

		this.uplink_volume_umcode = uplink_volume_umcode;

		this.uplink_volume_volume = uplink_volume_volume;

		this.vpn_info_vpn_call_type = vpn_info_vpn_call_type;

		this.vpn_number_address = vpn_number_address;

		this.vpn_number_carrier_code = vpn_number_carrier_code;

		this.vpn_number_clir = vpn_number_clir;

		this.vpn_number_dynamic_address = vpn_number_dynamic_address;

		this.vpn_number_int_access_code = vpn_number_int_access_code;

		this.vpn_number_local_prefix_len = vpn_number_local_prefix_len;

		this.vpn_number_modification_ind = vpn_number_modification_ind;

		this.vpn_number_network_code = vpn_number_network_code;

		this.vpn_number_numbering_plan = vpn_number_numbering_plan;

		this.vpn_number_type_of_number = vpn_number_type_of_number;

		this.vpn_number_user_profile_id = vpn_number_user_profile_id;

	}

	public void setTraftarBscs9_part3(String xfile_base_charge_amount, String xfile_base_charge_currency,
			String xfile_base_charge_gross_ind, String xfile_base_charge_tax, String xfile_call_type,

			String xfile_charge_amount, String xfile_charge_currency, String xfile_charge_gross_ind,
			String xfile_charge_tax, String xfile_day_category_code, String xfile_discount_amount,

			String xfile_discount_currency, String xfile_ic_charge_amount, String xfile_ic_charge_currency,
			String xfile_ic_charge_gross_ind, String xfile_ic_charge_tax, String xfile_ind,

			String xfile_time_band_code, String zero_rated_volume_umcode, String zero_rated_volume_volume,
			String zero_rounded_volume_umcode, String zero_rounded_volume_volume,

			String bal_audit_dat_valid_from, String bal_audit_dat_valid_to, String chrgaggrinfo_request_id,
			String cust_info_customer_group, String cust_info_parent_contract_id,

			String imp_party1_parent_contract_id, String imp_party2_parent_contract_id,
			String imp_party3_parent_contract_id, String net_element_address, String net_element_numbering_plan,

			String net_element_type_of_number, String rated_flat_amnt_orig_disc_amnt,
			String rated_flat_amount_disc_amount, String reject_filter_id, String routing_address,

			String routing_numbering_plan, String routing_type_of_number, String tariff_detail_pricgalternpkey,
			String tariff_detail_pricingalternid, String t_p_number_address,

			String t_p_number_numbering_plan, String t_p_number_type_of_number, String unbilled_amount_billing_acc,
			String unbilled_amount_compl_cond_id, String entry_date_sim_offset,

			String entry_date_sim_timestamp, String fu_pack_id_clone, String micro_cell_mc_shdes,
			String o_p_number_anonym_ind, String o_p_subs_address, String o_p_subs_carrier_code,

			String o_p_subs_clir, String o_p_subs_dynamic_address, String o_p_subs_iac,
			String o_p_subs_local_prefix_len, String o_p_subs_modification_ind, String o_p_subs_network_code,

			String o_p_subs_numbering_plan, String o_p_subs_type_of_number, String record_id_ext_call_id,
			String record_id_ext_file_id, String redirected_address, String redirected_carrier_code,

			String redirected_clir, String redirected_dynamic_address, String redirected_iac,
			String redirected_local_prefix_len, String redirected_modification_ind, String redirected_network_code,

			String redirected_numbering_plan, String redirected_type_of_number, String srvcode,
			String start_time_original_offset, String start_time_original_time, String s_p_location_area_code,

			String tariff_info_zodes, String tariff_info_zpdes, String techn_info_call_nature,
			String techn_info_charged_party, String techn_info_lng_dist_carrier_cd, String translated_address,

			String translated_carrier_code, String translated_clir, String translated_dynamic_address,
			String translated_iac, String translated_local_prefix_len, String translated_modification_ind,

			String translated_network_code, String translated_numbering_plan, String translated_type_of_number,
			String valid_from_smart_bberry, String valid_from_smart_dsl,

			String valid_from_smart_sms, String valid_from_smart_web, String xfile_charge_roam_scenario_id,
			String xfile_charge_umcode, String xfile_charge_volume, String late_call_config_id,

			String late_call_expiration_date, String late_call_grace_time, String mcprincing_value, String mc_balance,
			String mc_fup_indicator, String mc_limited, String mc_original_amount,

			String mc_pricing_mech, String mc_used_units, String load_date_offset, String load_date_timestamp,
			String record_id_uct_ctrl, String cob_type2_a_party_type, String cob_type2_b_party_type,

			String cob_type2_callnature, String cob_type2_cnl_a_party, String cob_type2_cnl_b_party,
			String cob_type2_eot_a, String cob_type2_eot_b, String cob_type2_onnet_ind,

			String cob_type2_originidentification, String cob_type2_recordtype, String cob_type2_tfi,
			String imp2_valid_from_smart_bberry, String imp2_valid_from_smart_dsl,

			String imp2_valid_from_smart_sms, String imp2_valid_from_smart_web, String imp_party1_comm_name_1,
			String imp_party1_comm_spec_rate_1, String imp_party1_comm_spec_rate_2,

			String imp_party2_comm_name_1, String imp_party2_comm_spec_rate_1, String imp_party2_comm_spec_rate_2,
			String rated_flat_amnt_orig_mc_amnt, String s_p_number_translated_address,

			String row_id, String loteid, String arquivo, String arquivots, String currentdate) {

		this.xfile_base_charge_amount = xfile_base_charge_amount;

		this.xfile_base_charge_currency = xfile_base_charge_currency;

		this.xfile_base_charge_gross_ind = xfile_base_charge_gross_ind;

		this.xfile_base_charge_tax = xfile_base_charge_tax;

		this.xfile_call_type = xfile_call_type;

		this.xfile_charge_amount = xfile_charge_amount;

		this.xfile_charge_currency = xfile_charge_currency;

		this.xfile_charge_gross_ind = xfile_charge_gross_ind;

		this.xfile_charge_tax = xfile_charge_tax;

		this.xfile_day_category_code = xfile_day_category_code;

		this.xfile_discount_amount = xfile_discount_amount;

		this.xfile_discount_currency = xfile_discount_currency;

		this.xfile_ic_charge_amount = xfile_ic_charge_amount;

		this.xfile_ic_charge_currency = xfile_ic_charge_currency;

		this.xfile_ic_charge_gross_ind = xfile_ic_charge_gross_ind;

		this.xfile_ic_charge_tax = xfile_ic_charge_tax;

		this.xfile_ind = xfile_ind;

		this.xfile_time_band_code = xfile_time_band_code;

		this.zero_rated_volume_umcode = zero_rated_volume_umcode;

		this.zero_rated_volume_volume = zero_rated_volume_volume;

		this.zero_rounded_volume_umcode = zero_rounded_volume_umcode;

		this.zero_rounded_volume_volume = zero_rounded_volume_volume;

		this.bal_audit_dat_valid_from = bal_audit_dat_valid_from;

		this.bal_audit_dat_valid_to = bal_audit_dat_valid_to;

		this.chrgaggrinfo_request_id = chrgaggrinfo_request_id;

		this.cust_info_customer_group = cust_info_customer_group;

		this.cust_info_parent_contract_id = cust_info_parent_contract_id;

		this.imp_party1_parent_contract_id = imp_party1_parent_contract_id;

		this.imp_party2_parent_contract_id = imp_party2_parent_contract_id;

		this.imp_party3_parent_contract_id = imp_party3_parent_contract_id;

		this.net_element_address = net_element_address;

		this.net_element_numbering_plan = net_element_numbering_plan;

		this.net_element_type_of_number = net_element_type_of_number;

		this.rated_flat_amnt_orig_disc_amnt = rated_flat_amnt_orig_disc_amnt;

		this.rated_flat_amount_disc_amount = rated_flat_amount_disc_amount;

		this.reject_filter_id = reject_filter_id;

		this.routing_address = routing_address;

		this.routing_numbering_plan = routing_numbering_plan;

		this.routing_type_of_number = routing_type_of_number;

		this.tariff_detail_pricgalternpkey = tariff_detail_pricgalternpkey;

		this.tariff_detail_pricingalternid = tariff_detail_pricingalternid;

		this.t_p_number_address = t_p_number_address;

		this.t_p_number_numbering_plan = t_p_number_numbering_plan;

		this.t_p_number_type_of_number = t_p_number_type_of_number;

		this.unbilled_amount_billing_acc = unbilled_amount_billing_acc;

		this.unbilled_amount_compl_cond_id = unbilled_amount_compl_cond_id;

		this.entry_date_sim_offset = entry_date_sim_offset;

		this.entry_date_sim_timestamp = entry_date_sim_timestamp;

		this.fu_pack_id_clone = fu_pack_id_clone;

		this.micro_cell_mc_shdes = micro_cell_mc_shdes;

		this.o_p_number_anonym_ind = o_p_number_anonym_ind;

		this.o_p_subs_address = o_p_subs_address;

		this.o_p_subs_carrier_code = o_p_subs_carrier_code;

		this.o_p_subs_clir = o_p_subs_clir;

		this.o_p_subs_dynamic_address = o_p_subs_dynamic_address;

		this.o_p_subs_iac = o_p_subs_iac;

		this.o_p_subs_local_prefix_len = o_p_subs_local_prefix_len;

		this.o_p_subs_modification_ind = o_p_subs_modification_ind;

		this.o_p_subs_network_code = o_p_subs_network_code;

		this.o_p_subs_numbering_plan = o_p_subs_numbering_plan;

		this.o_p_subs_type_of_number = o_p_subs_type_of_number;

		this.record_id_ext_call_id = record_id_ext_call_id;

		this.record_id_ext_file_id = record_id_ext_file_id;

		this.redirected_address = redirected_address;

		this.redirected_carrier_code = redirected_carrier_code;

		this.redirected_clir = redirected_clir;

		this.redirected_dynamic_address = redirected_dynamic_address;

		this.redirected_iac = redirected_iac;

		this.redirected_local_prefix_len = redirected_local_prefix_len;

		this.redirected_modification_ind = redirected_modification_ind;

		this.redirected_network_code = redirected_network_code;

		this.redirected_numbering_plan = redirected_numbering_plan;

		this.redirected_type_of_number = redirected_type_of_number;

		this.srvcode = srvcode;

		this.start_time_original_offset = start_time_original_offset;

		this.start_time_original_time = start_time_original_time;

		this.s_p_location_area_code = s_p_location_area_code;

		this.tariff_info_zodes = tariff_info_zodes;

		this.tariff_info_zpdes = tariff_info_zpdes;

		this.techn_info_call_nature = techn_info_call_nature;

		this.techn_info_charged_party = techn_info_charged_party;

		this.techn_info_lng_dist_carrier_cd = techn_info_lng_dist_carrier_cd;

		this.translated_address = translated_address;

		this.translated_carrier_code = translated_carrier_code;

		this.translated_clir = translated_clir;

		this.translated_dynamic_address = translated_dynamic_address;

		this.translated_iac = translated_iac;

		this.translated_local_prefix_len = translated_local_prefix_len;

		this.translated_modification_ind = translated_modification_ind;

		this.translated_network_code = translated_network_code;

		this.translated_numbering_plan = translated_numbering_plan;

		this.translated_type_of_number = translated_type_of_number;

		this.valid_from_smart_bberry = valid_from_smart_bberry;

		this.valid_from_smart_dsl = valid_from_smart_dsl;

		this.valid_from_smart_sms = valid_from_smart_sms;

		this.valid_from_smart_web = valid_from_smart_web;

		this.xfile_charge_roam_scenario_id = xfile_charge_roam_scenario_id;

		this.xfile_charge_umcode = xfile_charge_umcode;

		this.xfile_charge_volume = xfile_charge_volume;

		this.late_call_config_id = late_call_config_id;

		this.late_call_expiration_date = late_call_expiration_date;

		this.late_call_grace_time = late_call_grace_time;

		this.mcprincing_value = mcprincing_value;

		this.mc_balance = mc_balance;

		this.mc_fup_indicator = mc_fup_indicator;

		this.mc_limited = mc_limited;

		this.mc_original_amount = mc_original_amount;

		this.mc_pricing_mech = mc_pricing_mech;

		this.mc_used_units = mc_used_units;

		this.load_date_offset = load_date_offset;

		this.load_date_timestamp = load_date_timestamp;

		this.record_id_uct_ctrl = record_id_uct_ctrl;

		this.cob_type2_a_party_type = cob_type2_a_party_type;

		this.cob_type2_b_party_type = cob_type2_b_party_type;

		this.cob_type2_callnature = cob_type2_callnature;

		this.cob_type2_cnl_a_party = cob_type2_cnl_a_party;

		this.cob_type2_cnl_b_party = cob_type2_cnl_b_party;

		this.cob_type2_eot_a = cob_type2_eot_a;

		this.cob_type2_eot_b = cob_type2_eot_b;

		this.cob_type2_onnet_ind = cob_type2_onnet_ind;

		this.cob_type2_originidentification = cob_type2_originidentification;

		this.cob_type2_recordtype = cob_type2_recordtype;

		this.cob_type2_tfi = cob_type2_tfi;

		this.imp2_valid_from_smart_bberry = imp2_valid_from_smart_bberry;

		this.imp2_valid_from_smart_dsl = imp2_valid_from_smart_dsl;

		this.imp2_valid_from_smart_sms = imp2_valid_from_smart_sms;

		this.imp2_valid_from_smart_web = imp2_valid_from_smart_web;

		this.imp_party1_comm_name_1 = imp_party1_comm_name_1;

		this.imp_party1_comm_spec_rate_1 = imp_party1_comm_spec_rate_1;

		this.imp_party1_comm_spec_rate_2 = imp_party1_comm_spec_rate_2;

		this.imp_party2_comm_name_1 = imp_party2_comm_name_1;

		this.imp_party2_comm_spec_rate_1 = imp_party2_comm_spec_rate_1;

		this.imp_party2_comm_spec_rate_2 = imp_party2_comm_spec_rate_2;

		this.rated_flat_amnt_orig_mc_amnt = rated_flat_amnt_orig_mc_amnt;

		this.s_p_number_translated_address = s_p_number_translated_address;

		this.row_id = row_id;

		this.loteid = loteid;

		this.arquivo = arquivo;

		this.arquivots = arquivots;

		this.currentdate = currentdate;

	}

	public boolean parseFromText(String textString) {

		if (textString != null && !textString.trim().isEmpty()) {

			textString = textString.replaceAll("\"|<*NULL>*", "");

			String[] cols = textString.split(CommonsConstants.FILE_SPLIT_REGEX, 1);

			if (cols.length != 648)

				return false;

			int i = 0;

			this.setTraftarBscs9_part1(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

			this.setTraftarBscs9_part2(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

			this.setTraftarBscs9_part3(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

			return true;

		}

		return false;

	}

	@Override
	public void readFields(DataInput in) throws IOException {

		this.num_rowid_ogg = in.readUTF();

		this.cod_ogg = in.readUTF();

		this.tpo_operacao_ogg = in.readUTF();

		this.dat_ogg = in.readUTF();

		this.nom_sistema_ogg = in.readUTF();

		this.nom_interface_ogg = in.readUTF();

		this.aggreg_info_aggreg_purpose = in.readUTF();

		this.aggreg_info_agg_trans_id = in.readUTF();

		this.aggreg_info_applied_pack_id = in.readUTF();

		this.aggreg_info_rec_counter = in.readUTF();

		this.aggreg_info_summary_id = in.readUTF();

		this.alt_rated_amount = in.readUTF();

		this.alt_rated_currency = in.readUTF();

		this.alt_tariff_clicks_volume = in.readUTF();

		this.alt_tmcode = in.readUTF();

		this.an_pack_an_package_id_list = in.readUTF();

		this.an_pack_orig_an_pack_id_list = in.readUTF();

		this.bal_audit_data_account_id = in.readUTF();

		this.bal_audit_data_account_type = in.readUTF();

		this.bal_audit_data_account_type_id = in.readUTF();

		this.bal_audit_dat_balance_accum = in.readUTF();

		this.bal_audit_dat_balance_prod_id = in.readUTF();

		this.bal_audit_dat_balance_type = in.readUTF();

		this.bal_audit_dat_bal_after_chg = in.readUTF();

		this.bal_audit_dat_bal_before_chg = in.readUTF();

		this.bal_audit_dat_bundl_prod_id = in.readUTF();

		this.bal_audit_dat_contract_id = in.readUTF();

		this.bal_audit_dat_offer_seqno = in.readUTF();

		this.bal_audit_dat_offer_sncode = in.readUTF();

		this.bal_audit_dat_prep_credit_ind = in.readUTF();

		this.bal_audit_dat_purchase_seq_no = in.readUTF();

		this.bal_audit_dat_shacc_packid = in.readUTF();

		this.bal_audit_dat_user_profile_id = in.readUTF();

		this.bop_info_bop_package_id = in.readUTF();

		this.bop_info_bop_package_pkey = in.readUTF();

		this.bop_info_bop_package_version = in.readUTF();

		this.bop_info_detail_billed_ind = in.readUTF();

		this.bop_info_detail_bop_altern_ind = in.readUTF();

		this.bop_info_detail_contracted_ind = in.readUTF();

		this.bop_info_detail_sequence_rp = in.readUTF();

		this.bop_info_detail_sequence_sp = in.readUTF();

		this.bop_tariff_info_day_catcode = in.readUTF();

		this.bop_tariff_info_egcode = in.readUTF();

		this.bop_tariff_info_egversion = in.readUTF();

		this.bop_tariff_info_gvcode = in.readUTF();

		this.bop_tariff_info_rpcode = in.readUTF();

		this.bop_tariff_info_rpversion = in.readUTF();

		this.bop_tariff_info_sncode = in.readUTF();

		this.bop_tariff_info_spcode = in.readUTF();

		this.bop_tariff_info_time_band_code = in.readUTF();

		this.bop_tariff_info_tmcode = in.readUTF();

		this.bop_tariff_info_tmversion = in.readUTF();

		this.bop_tariff_info_tm_used_type = in.readUTF();

		this.bop_tariff_info_twcode = in.readUTF();

		this.bop_tariff_info_usage_ind = in.readUTF();

		this.bop_tariff_info_zncode = in.readUTF();

		this.bop_tariff_info_zpcode = in.readUTF();

		this.bpartn_sum_info_time_slice_lb = in.readUTF();

		this.bpartn_sum_info_time_slice_rb = in.readUTF();

		this.bundle_info_bundle_purchase_id = in.readUTF();

		this.bundle_info_bundle_purch_ind = in.readUTF();

		this.bundle_info_contract_id = in.readUTF();

		this.bundle_info_purchase_seq_no = in.readUTF();

		this.bundle_info_sequence_number = in.readUTF();

		this.bundle_info_sncode = in.readUTF();

		this.bundle_info_state = in.readUTF();

		this.bundle_info_termination = in.readUTF();

		this.bundle_info_user_profile_id = in.readUTF();

		this.bundle_info_valid_from = in.readUTF();

		this.bundle_info_valid_to = in.readUTF();

		this.bundle_info_version = in.readUTF();

		this.bundle_usg_bundle_covered_usg = in.readUTF();

		this.business_info_bs_id = in.readUTF();

		this.business_info_bs_version = in.readUTF();

		this.business_info_charge_item_id = in.readUTF();

		this.business_info_charge_party_id = in.readUTF();

		this.business_info_c_p_field_ref = in.readUTF();

		this.business_info_o_p_field_ref = in.readUTF();

		this.business_info_pre_bs_id = in.readUTF();

		this.business_info_pre_bs_version = in.readUTF();

		this.bus_partner_info_tax_mode = in.readUTF();

		this.call_dest = in.readUTF();

		this.call_type = in.readUTF();

		this.camel_dest_addr_user_prof_id = in.readUTF();

		this.camel_msc_address = in.readUTF();

		this.camel_msc_addr_user_prof_id = in.readUTF();

		this.camel_reference_number = in.readUTF();

		this.camel_srv_addr_user_prof_id = in.readUTF();

		this.charge_info_cash_flow_direct = in.readUTF();

		this.charge_info_disable_tax = in.readUTF();

		this.charging_characteristics = in.readUTF();

		this.consumer_info_address = in.readUTF();

		this.consumer_info_contract_id = in.readUTF();

		this.consumer_info_numbering_plan = in.readUTF();

		this.content_advised_charge_ind = in.readUTF();

		this.content_authorisation_code = in.readUTF();

		this.content_content_charging_point = in.readUTF();

		this.content_contract_pkey = in.readUTF();

		this.content_desc_suppress = in.readUTF();

		this.content_paid_ind = in.readUTF();

		this.content_payment_method = in.readUTF();

		this.content_provider_address = in.readUTF();

		this.content_provider_carrier_code = in.readUTF();

		this.content_provider_clir = in.readUTF();

		this.content_provider_iac = in.readUTF();

		this.content_provider_modif_ind = in.readUTF();

		this.content_provider_network_code = in.readUTF();

		this.content_provid_dynamic_address = in.readUTF();

		this.content_provid_local_pref_len = in.readUTF();

		this.content_provid_numbering_plan = in.readUTF();

		this.content_provid_other_location = in.readUTF();

		this.content_provid_type_of_number = in.readUTF();

		this.content_provid_user_profile_id = in.readUTF();

		this.content_refund_ind = in.readUTF();

		this.content_short_desc = in.readUTF();

		this.content_transaction_id = in.readUTF();

		this.control_data_record_age = in.readUTF();

		this.cug_info_cug_id = in.readUTF();

		this.cug_info_cug_index = in.readUTF();

		this.customer_info_contract_type_id = in.readUTF();

		this.customer_info_contraggrpack_id = in.readUTF();

		this.customer_info_reco_ind = in.readUTF();

		this.cust_info_address = in.readUTF();

		this.cust_info_alternate_tmcode = in.readUTF();

		this.cust_info_an_package_id_list = in.readUTF();

		this.cust_info_bill_cycle = in.readUTF();

		this.cust_info_bu_address = in.readUTF();

		this.cust_info_bu_numbering_plan = in.readUTF();

		this.cust_info_charging_engine = in.readUTF();

		this.cust_info_contract_id = in.readUTF();

		this.cust_info_customer_id = in.readUTF();

		this.cust_info_delete_after_billing = in.readUTF();

		this.cust_info_dn_id = in.readUTF();

		this.cust_info_main_msisdn = in.readUTF();

		this.cust_info_numbering_plan = in.readUTF();

		this.cust_info_port_id = in.readUTF();

		this.cust_info_serv_bid_id = in.readUTF();

		this.cust_info_sim_number = in.readUTF();

		this.cust_info_sim_sernumber = in.readUTF();

		this.cust_info_subs_code = in.readUTF();

		this.cust_info_subs_tag = in.readUTF();

		this.cust_info_user_profile_id = in.readUTF();

		this.data_volume = in.readUTF();

		this.data_volume_umcode = in.readUTF();

		this.desc_prod_usage_long_desc = in.readUTF();

		this.destination_field_id = in.readUTF();

		this.downlink_volume_umcode = in.readUTF();

		this.downlink_volume_volume = in.readUTF();

		this.duration_umcode = in.readUTF();

		this.duration_volume = in.readUTF();

		this.entry_date_offset = in.readUTF();

		this.entry_date_timestamp = in.readUTF();

		this.event_info_event_type = in.readUTF();

		this.event_status_info_message_id = in.readUTF();

		this.event_umcode = in.readUTF();

		this.event_volume = in.readUTF();

		this.export_file = in.readUTF();

		this.ext_balance_amnt_amount = in.readUTF();

		this.follow_up_call_type = in.readUTF();

		this.for_amount_amount = in.readUTF();

		this.for_amount_currency = in.readUTF();

		this.for_amount_gross_ind = in.readUTF();

		this.for_amount_tax = in.readUTF();

		this.for_freechrg_amount = in.readUTF();

		this.for_freechrg_currency = in.readUTF();

		this.for_freechrg_gross_ind = in.readUTF();

		this.for_freechrg_tax = in.readUTF();

		this.free_charge_amount = in.readUTF();

		this.free_charge_amount_non_rpc = in.readUTF();

		this.free_charge_currency = in.readUTF();

		this.free_charge_curr_non_rpc = in.readUTF();

		this.free_charge_gross_ind = in.readUTF();

		this.free_charge_gross_ind_nrpc = in.readUTF();

		this.free_charge_tax = in.readUTF();

		this.free_charge_tax_nrpc = in.readUTF();

		this.free_clicks_umcode = in.readUTF();

		this.free_clicks_volume = in.readUTF();

		this.free_rated_volume_umcode = in.readUTF();

		this.free_rated_volume_volume = in.readUTF();

		this.free_rounded_volume_umcode = in.readUTF();

		this.free_rounded_volume_volume = in.readUTF();

		this.free_units_info_account_key = in.readUTF();

		this.free_units_info_account_origin = in.readUTF();

		this.free_units_info_acc_hist_id = in.readUTF();

		this.free_units_info_appl_method = in.readUTF();

		this.free_units_info_chg_red_quota = in.readUTF();

		this.free_units_info_discount_rate = in.readUTF();

		this.free_units_info_discount_type = in.readUTF();

		this.free_units_info_freeunitoption = in.readUTF();

		this.free_units_info_fup_seq = in.readUTF();

		this.free_units_info_fu_pack_id = in.readUTF();

		this.free_units_info_part_creator = in.readUTF();

		this.free_units_info_previous_seqno = in.readUTF();

		this.free_units_info_seqno = in.readUTF();

		this.free_units_info_version = in.readUTF();

		this.home_network_code = in.readUTF();

		this.hscsd_info_aiur = in.readUTF();

		this.hscsd_info_channels_max = in.readUTF();

		this.hscsd_info_channels_used = in.readUTF();

		this.hscsd_info_coding_acc = in.readUTF();

		this.hscsd_info_coding_used = in.readUTF();

		this.hscsd_info_fnur = in.readUTF();

		this.hscsd_info_init_party = in.readUTF();

		this.imp_party1_address = in.readUTF();

		this.imp_party1_alternate_tmcode = in.readUTF();

		this.imp_party1_an_package_id_list = in.readUTF();

		this.imp_party1_bill_cycle = in.readUTF();

		this.imp_party1_numbering_plan = in.readUTF();

		this.imp_party1_user_profile_id = in.readUTF();

		this.imp_party2_address = in.readUTF();

		this.imp_party2_alternate_tmcode = in.readUTF();

		this.imp_party2_an_package_id_list = in.readUTF();

		this.imp_party2_bill_cycle = in.readUTF();

		this.imp_party2_numbering_plan = in.readUTF();

		this.imp_party2_user_profile_id = in.readUTF();

		this.imp_party3_address = in.readUTF();

		this.imp_party3_alternate_tmcode = in.readUTF();

		this.imp_party3_an_package_id_list = in.readUTF();

		this.imp_party3_bill_cycle = in.readUTF();

		this.imp_party3_numbering_plan = in.readUTF();

		this.imp_party3_user_profile_id = in.readUTF();

		this.imp_party4_address = in.readUTF();

		this.imp_party4_alternate_tmcode = in.readUTF();

		this.imp_party4_an_package_id_list = in.readUTF();

		this.imp_party4_bill_cycle = in.readUTF();

		this.imp_party4_numbering_plan = in.readUTF();

		this.imp_party4_parent_contract_id = in.readUTF();

		this.imp_party4_user_profile_id = in.readUTF();

		this.imp_party5_address = in.readUTF();

		this.imp_party5_alternate_tmcode = in.readUTF();

		this.imp_party5_an_package_id_list = in.readUTF();

		this.imp_party5_bill_cycle = in.readUTF();

		this.imp_party5_numbering_plan = in.readUTF();

		this.imp_party5_parent_contract_id = in.readUTF();

		this.imp_party5_user_profile_id = in.readUTF();

		this.initial_start_time_timestamp = in.readUTF();

		this.initial_start_time_time_offset = in.readUTF();

		this.lcs_qos_deliv_horizontal_accur = in.readUTF();

		this.lcs_qos_deliv_tracking_frequen = in.readUTF();

		this.lcs_qos_deliv_tracking_period = in.readUTF();

		this.lcs_qos_deliv_vertical_accur = in.readUTF();

		this.lcs_qos_info_age_of_location = in.readUTF();

		this.lcs_qos_info_position_method = in.readUTF();

		this.lcs_qos_info_response_time = in.readUTF();

		this.lcs_qos_info_response_time_cat = in.readUTF();

		this.lcs_qos_req_horizontal_accur = in.readUTF();

		this.lcs_qos_req_tracking_frequency = in.readUTF();

		this.lcs_qos_req_tracking_period = in.readUTF();

		this.lcs_qos_req_vertical_accur = in.readUTF();

		this.ldc_info_carrier_code = in.readUTF();

		this.ldc_info_contract_pkey = in.readUTF();

		this.ldc_info_home_net_ind = in.readUTF();

		this.lec_info_contract_pkey = in.readUTF();

		this.lec_info_home_net_ind = in.readUTF();

		this.lzlist = in.readUTF();

		this.mc_info_code = in.readUTF();

		this.mc_info_ind = in.readUTF();

		this.mc_info_micro_cell_information = in.readUTF();

		this.mc_scalefactor = in.readUTF();

		this.messages_umcode = in.readUTF();

		this.messages_volume = in.readUTF();

		this.micro_cell_imcscalefactortype = in.readUTF();

		this.micro_cell_mc_code = in.readUTF();

		this.micro_cell_mc_pkey = in.readUTF();

		this.micro_cell_mc_type = in.readUTF();

		this.micro_cell_scalefactor = in.readUTF();

		this.network_init_context_ind = in.readUTF();

		this.net_element_home_bid_id = in.readUTF();

		this.net_element_network_code = in.readUTF();

		this.net_element_netw_element_id = in.readUTF();

		this.net_element_user_profile_id = in.readUTF();

		this.normed_net_elem_address = in.readUTF();

		this.normed_net_elem_int_acc_code = in.readUTF();

		this.normed_net_elem_number_plan = in.readUTF();

		this.normed_rtd_num_address = in.readUTF();

		this.normed_rtd_num_int_acc_code = in.readUTF();

		this.normed_rtd_num_number_plan = in.readUTF();

		this.normtrkgrp_in_address = in.readUTF();

		this.normtrkgrp_in_numberingplan = in.readUTF();

		this.normtrkgrp_out_address = in.readUTF();

		this.normtrkgrp_out_numberingplan = in.readUTF();

		this.number_of_rejections = in.readUTF();

		this.offer_offer_seqno = in.readUTF();

		this.offer_offer_sncode = in.readUTF();

		this.origin_field_id = in.readUTF();

		this.orig_entry_date_timestamp = in.readUTF();

		this.orig_entry_date_timezone_id = in.readUTF();

		this.orig_entry_date_timezone_pkey = in.readUTF();

		this.orig_entry_date_time_offset = in.readUTF();

		this.or_flag = in.readUTF();

		this.o_p_normed_num_address = in.readUTF();

		this.o_p_normed_num_int_acc_code = in.readUTF();

		this.o_p_normed_num_number_plan = in.readUTF();

		this.o_p_number_address = in.readUTF();

		this.o_p_number_backup_address = in.readUTF();

		this.o_p_number_carrier_code = in.readUTF();

		this.o_p_number_clir = in.readUTF();

		this.o_p_number_numbering_plan = in.readUTF();

		this.o_p_number_other_location = in.readUTF();

		this.o_p_number_type_of_number = in.readUTF();

		this.o_p_number_user_profile_id = in.readUTF();

		this.o_p_pubid_address = in.readUTF();

		this.o_p_pubid_numbering_plan = in.readUTF();

		this.o_p_pubid_type_of_number = in.readUTF();

		this.price_plan_info_chrgplanid = in.readUTF();

		this.price_plan_info_evalquantity = in.readUTF();

		this.price_plan_info_threshold = in.readUTF();

		this.promo_info_b_number_cat = in.readUTF();

		this.qos_negot_delay = in.readUTF();

		this.qos_negot_mean_throughput = in.readUTF();

		this.qos_negot_peak_throughput = in.readUTF();

		this.qos_negot_precedence = in.readUTF();

		this.qos_negot_reliability = in.readUTF();

		this.qos_profile = in.readUTF();

		this.qos_req_delay = in.readUTF();

		this.qos_req_mean_throughput = in.readUTF();

		this.qos_req_peak_throughput = in.readUTF();

		this.qos_req_precedence = in.readUTF();

		this.qos_req_reliability = in.readUTF();

		this.rated_clicks_umcode = in.readUTF();

		this.rated_clicks_volume = in.readUTF();

		this.rated_flat_amnt_gross_ind_nrpc = in.readUTF();

		this.rated_flat_amnt_orig_currency = in.readUTF();

		this.rated_flat_amnt_orig_gross_ind = in.readUTF();

		this.rated_flat_amnt_tax_nrpc = in.readUTF();

		this.rated_flat_amount = in.readUTF();

		this.rated_flat_amount_currency = in.readUTF();

		this.rated_flat_amount_gross_ind = in.readUTF();

		this.rated_flat_amount_non_rpc = in.readUTF();

		this.rated_flat_amount_non_rpc_curr = in.readUTF();

		this.rated_flat_amount_orig_amount = in.readUTF();

		this.rated_flat_amount_orig_tax = in.readUTF();

		this.rated_flat_amount_tax = in.readUTF();

		this.rated_volume = in.readUTF();

		this.rated_volume_umcode = in.readUTF();

		this.recipient_net_address = in.readUTF();

		this.recipient_net_numbering_plan = in.readUTF();

		this.record_id_call_id = in.readUTF();

		this.record_id_cdr_id = in.readUTF();

		this.record_id_cdr_sub_id = in.readUTF();

		this.record_id_event_ref = in.readUTF();

		this.record_id_orig_cdr_id = in.readUTF();

		this.record_id_rap_sequence_num = in.readUTF();

		this.record_id_rerate_seqno = in.readUTF();

		this.record_id_shaacc_unique_id = in.readUTF();

		this.record_id_tap_sequence_num = in.readUTF();

		this.record_id_udr_file_id = in.readUTF();

		this.record_type_record_category = in.readUTF();

		this.record_type_summary_ind = in.readUTF();

		this.refer_contr_contract_id = in.readUTF();

		this.refer_contr_reference_type = in.readUTF();

		this.rejected_base_part = in.readUTF();

		this.reject_reason_code = in.readUTF();

		this.remark = in.readUTF();

		this.rerate_info_rerate_reason_id = in.readUTF();

		this.rerate_info_rerate_record_type = in.readUTF();

		this.rerate_info_rerate_request_id = in.readUTF();

		this.rerate_info_urh_id = in.readUTF();

		this.rounded_volume = in.readUTF();

		this.rounded_volume_umcode = in.readUTF();

		this.routing_network_code = in.readUTF();

		this.routing_number_backup_address = in.readUTF();

		this.routing_user_profile_id = in.readUTF();

		this.scu_id_address = in.readUTF();

		this.scu_id_user_profile_id = in.readUTF();

		this.scu_info_priority_code = in.readUTF();

		this.service_action_code = in.readUTF();

		this.service_guaranteed_bit_rate = in.readUTF();

		this.service_hscsd_ind = in.readUTF();

		this.service_ims_signalling_context = in.readUTF();

		this.service_logic_code = in.readUTF();

		this.service_max_bit_rate = in.readUTF();

		this.service_service_type = in.readUTF();

		this.service_used_service = in.readUTF();

		this.service_user_protocol_ind = in.readUTF();

		this.service_vas_code = in.readUTF();

		this.serv_pdp_addr_apn_split_ind = in.readUTF();

		this.sgsn_addresses = in.readUTF();

		this.spec_num_info_apply_free_units = in.readUTF();

		this.start_time_charge_offset = in.readUTF();

		this.start_time_charge_timestamp = in.readUTF();

		this.start_time_offset = in.readUTF();

		this.start_time_timestamp = in.readUTF();

		this.sum_reference_single_id = in.readUTF();

		this.s_pdp_address = in.readUTF();

		this.s_pdp_carrier_code = in.readUTF();

		this.s_pdp_clir = in.readUTF();

		this.s_pdp_intern_access_code = in.readUTF();

		this.s_pdp_modification_ind = in.readUTF();

		this.s_pdp_network_code = in.readUTF();

		this.s_pdp_numbering_plan = in.readUTF();

		this.s_pdp_type_of_number = in.readUTF();

		this.s_pdp_user_profile_id = in.readUTF();

		this.s_p_equipment_class_mark = in.readUTF();

		this.s_p_equipment_number = in.readUTF();

		this.s_p_home_id_description = in.readUTF();

		this.s_p_home_id_home_bid_id = in.readUTF();

		this.s_p_home_id_name = in.readUTF();

		this.s_p_home_id_network = in.readUTF();

		this.s_p_home_loc_address = in.readUTF();

		this.s_p_home_loc_numbering_plan = in.readUTF();

		this.s_p_location_address = in.readUTF();

		this.s_p_location_numbering_plan = in.readUTF();

		this.s_p_loc_serving_bid_id = in.readUTF();

		this.s_p_loc_serving_location = in.readUTF();

		this.s_p_number_address = in.readUTF();

		this.s_p_number_home_bid_id = in.readUTF();

		this.s_p_number_network_code = in.readUTF();

		this.s_p_number_numbering_plan = in.readUTF();

		this.s_p_number_user_profile_id = in.readUTF();

		this.s_p_port_address = in.readUTF();

		this.s_p_port_numbering_plan = in.readUTF();

		this.s_p_port_user_profile_id = in.readUTF();

		this.tariff_detail_chgbl_quantity = in.readUTF();

		this.tariff_detail_ext_chrg_udmcode = in.readUTF();

		this.tariff_detail_interconnect_ind = in.readUTF();

		this.tariff_detail_rate_type_id = in.readUTF();

		this.tariff_detail_rtx_charge_type = in.readUTF();

		this.tariff_detail_ttcode = in.readUTF();

		this.tariff_info_catalogue_id = in.readUTF();

		this.tariff_info_catalogue_vers = in.readUTF();

		this.tariff_info_ctlg_elm_id = in.readUTF();

		this.tariff_info_egcode = in.readUTF();

		this.tariff_info_egversion = in.readUTF();

		this.tariff_info_gvcode = in.readUTF();

		this.tariff_info_pricelist_id = in.readUTF();

		this.tariff_info_pricelist_pkey = in.readUTF();

		this.tariff_info_pricelist_vers = in.readUTF();

		this.tariff_info_price_def_vers = in.readUTF();

		this.tariff_info_rpcode = in.readUTF();

		this.tariff_info_rpversion = in.readUTF();

		this.tariff_info_sncode = in.readUTF();

		this.tariff_info_spcode = in.readUTF();

		this.tariff_info_time_band_code = in.readUTF();

		this.tariff_info_tmcode = in.readUTF();

		this.tariff_info_tmversion = in.readUTF();

		this.tariff_info_tm_used_type = in.readUTF();

		this.tariff_info_twcode = in.readUTF();

		this.tariff_info_usage_ind = in.readUTF();

		this.tariff_info_zncode = in.readUTF();

		this.tariff_info_zpcode = in.readUTF();

		this.tariff_info_zpcode_day_catcode = in.readUTF();

		this.tax_info_serv_cat = in.readUTF();

		this.tax_info_serv_code = in.readUTF();

		this.tax_info_serv_type = in.readUTF();

		this.techn_info_fixed_mobile_ind = in.readUTF();

		this.techn_info_home_terminated_ind = in.readUTF();

		this.techn_info_prepay_ind = in.readUTF();

		this.techn_info_pre_rated_ind = in.readUTF();

		this.techn_info_rev_charging_ind = in.readUTF();

		this.techn_info_sccode = in.readUTF();

		this.techn_info_termination_ind = in.readUTF();

		this.trunk_group_in_address = in.readUTF();

		this.trunk_group_in_numberingplan = in.readUTF();

		this.trunk_group_in_typeofnumber = in.readUTF();

		this.trunk_group_out_address = in.readUTF();

		this.trunk_group_out_numberingplan = in.readUTF();

		this.trunk_group_out_typeofnumber = in.readUTF();

		this.t_p_number_user_profile_id = in.readUTF();

		this.udr_basepart_id = in.readUTF();

		this.udr_chargepart_id = in.readUTF();

		this.uds_base_part_id = in.readUTF();

		this.uds_charge_part_id = in.readUTF();

		this.uds_free_unit_part_id = in.readUTF();

		this.uds_promotion_part_id = in.readUTF();

		this.uds_record_id = in.readUTF();

		this.uds_stream_id = in.readUTF();

		this.umts_qos_negot_allc_retn_prior = in.readUTF();

		this.umts_qos_negot_delay = in.readUTF();

		this.umts_qos_negot_delivery_order = in.readUTF();

		this.umts_qos_negot_erroneous_sdus = in.readUTF();

		this.umts_qos_negot_handl_priority = in.readUTF();

		this.umts_qos_negot_max_size_sdu = in.readUTF();

		this.umts_qos_negot_rate_downlink = in.readUTF();

		this.umts_qos_negot_rate_uplink = in.readUTF();

		this.umts_qos_negot_residual_ber = in.readUTF();

		this.umts_qos_negot_sdu_err_ratio = in.readUTF();

		this.umts_qos_negot_traffic_class = in.readUTF();

		this.umts_qos_req_allc_retn_prior = in.readUTF();

		this.umts_qos_req_delay = in.readUTF();

		this.umts_qos_req_delivery_order = in.readUTF();

		this.umts_qos_req_erroneous_sdus = in.readUTF();

		this.umts_qos_req_handl_priority = in.readUTF();

		this.umts_qos_req_max_size_sdu = in.readUTF();

		this.umts_qos_req_rate_downlink = in.readUTF();

		this.umts_qos_req_rate_uplink = in.readUTF();

		this.umts_qos_req_residual_ber = in.readUTF();

		this.umts_qos_req_sdu_error_ratio = in.readUTF();

		this.umts_qos_req_traffic_class = in.readUTF();

		this.unbilledamtpaymresp_customerid = in.readUTF();

		this.unbilled_amount_amount = in.readUTF();

		this.unbilled_amount_currency = in.readUTF();

		this.unbilled_amount_gross_ind = in.readUTF();

		this.unbilled_amount_tax = in.readUTF();

		this.uplink_volume_umcode = in.readUTF();

		this.uplink_volume_volume = in.readUTF();

		this.vpn_info_vpn_call_type = in.readUTF();

		this.vpn_number_address = in.readUTF();

		this.vpn_number_carrier_code = in.readUTF();

		this.vpn_number_clir = in.readUTF();

		this.vpn_number_dynamic_address = in.readUTF();

		this.vpn_number_int_access_code = in.readUTF();

		this.vpn_number_local_prefix_len = in.readUTF();

		this.vpn_number_modification_ind = in.readUTF();

		this.vpn_number_network_code = in.readUTF();

		this.vpn_number_numbering_plan = in.readUTF();

		this.vpn_number_type_of_number = in.readUTF();

		this.vpn_number_user_profile_id = in.readUTF();

		this.xfile_base_charge_amount = in.readUTF();

		this.xfile_base_charge_currency = in.readUTF();

		this.xfile_base_charge_gross_ind = in.readUTF();

		this.xfile_base_charge_tax = in.readUTF();

		this.xfile_call_type = in.readUTF();

		this.xfile_charge_amount = in.readUTF();

		this.xfile_charge_currency = in.readUTF();

		this.xfile_charge_gross_ind = in.readUTF();

		this.xfile_charge_tax = in.readUTF();

		this.xfile_day_category_code = in.readUTF();

		this.xfile_discount_amount = in.readUTF();

		this.xfile_discount_currency = in.readUTF();

		this.xfile_ic_charge_amount = in.readUTF();

		this.xfile_ic_charge_currency = in.readUTF();

		this.xfile_ic_charge_gross_ind = in.readUTF();

		this.xfile_ic_charge_tax = in.readUTF();

		this.xfile_ind = in.readUTF();

		this.xfile_time_band_code = in.readUTF();

		this.zero_rated_volume_umcode = in.readUTF();

		this.zero_rated_volume_volume = in.readUTF();

		this.zero_rounded_volume_umcode = in.readUTF();

		this.zero_rounded_volume_volume = in.readUTF();

		this.bal_audit_dat_valid_from = in.readUTF();

		this.bal_audit_dat_valid_to = in.readUTF();

		this.chrgaggrinfo_request_id = in.readUTF();

		this.cust_info_customer_group = in.readUTF();

		this.cust_info_parent_contract_id = in.readUTF();

		this.imp_party1_parent_contract_id = in.readUTF();

		this.imp_party2_parent_contract_id = in.readUTF();

		this.imp_party3_parent_contract_id = in.readUTF();

		this.net_element_address = in.readUTF();

		this.net_element_numbering_plan = in.readUTF();

		this.net_element_type_of_number = in.readUTF();

		this.rated_flat_amnt_orig_disc_amnt = in.readUTF();

		this.rated_flat_amount_disc_amount = in.readUTF();

		this.reject_filter_id = in.readUTF();

		this.routing_address = in.readUTF();

		this.routing_numbering_plan = in.readUTF();

		this.routing_type_of_number = in.readUTF();

		this.tariff_detail_pricgalternpkey = in.readUTF();

		this.tariff_detail_pricingalternid = in.readUTF();

		this.t_p_number_address = in.readUTF();

		this.t_p_number_numbering_plan = in.readUTF();

		this.t_p_number_type_of_number = in.readUTF();

		this.unbilled_amount_billing_acc = in.readUTF();

		this.unbilled_amount_compl_cond_id = in.readUTF();

		this.entry_date_sim_offset = in.readUTF();

		this.entry_date_sim_timestamp = in.readUTF();

		this.fu_pack_id_clone = in.readUTF();

		this.micro_cell_mc_shdes = in.readUTF();

		this.o_p_number_anonym_ind = in.readUTF();

		this.o_p_subs_address = in.readUTF();

		this.o_p_subs_carrier_code = in.readUTF();

		this.o_p_subs_clir = in.readUTF();

		this.o_p_subs_dynamic_address = in.readUTF();

		this.o_p_subs_iac = in.readUTF();

		this.o_p_subs_local_prefix_len = in.readUTF();

		this.o_p_subs_modification_ind = in.readUTF();

		this.o_p_subs_network_code = in.readUTF();

		this.o_p_subs_numbering_plan = in.readUTF();

		this.o_p_subs_type_of_number = in.readUTF();

		this.record_id_ext_call_id = in.readUTF();

		this.record_id_ext_file_id = in.readUTF();

		this.redirected_address = in.readUTF();

		this.redirected_carrier_code = in.readUTF();

		this.redirected_clir = in.readUTF();

		this.redirected_dynamic_address = in.readUTF();

		this.redirected_iac = in.readUTF();

		this.redirected_local_prefix_len = in.readUTF();

		this.redirected_modification_ind = in.readUTF();

		this.redirected_network_code = in.readUTF();

		this.redirected_numbering_plan = in.readUTF();

		this.redirected_type_of_number = in.readUTF();

		this.srvcode = in.readUTF();

		this.start_time_original_offset = in.readUTF();

		this.start_time_original_time = in.readUTF();

		this.s_p_location_area_code = in.readUTF();

		this.tariff_info_zodes = in.readUTF();

		this.tariff_info_zpdes = in.readUTF();

		this.techn_info_call_nature = in.readUTF();

		this.techn_info_charged_party = in.readUTF();

		this.techn_info_lng_dist_carrier_cd = in.readUTF();

		this.translated_address = in.readUTF();

		this.translated_carrier_code = in.readUTF();

		this.translated_clir = in.readUTF();

		this.translated_dynamic_address = in.readUTF();

		this.translated_iac = in.readUTF();

		this.translated_local_prefix_len = in.readUTF();

		this.translated_modification_ind = in.readUTF();

		this.translated_network_code = in.readUTF();

		this.translated_numbering_plan = in.readUTF();

		this.translated_type_of_number = in.readUTF();

		this.valid_from_smart_bberry = in.readUTF();

		this.valid_from_smart_dsl = in.readUTF();

		this.valid_from_smart_sms = in.readUTF();

		this.valid_from_smart_web = in.readUTF();

		this.xfile_charge_roam_scenario_id = in.readUTF();

		this.xfile_charge_umcode = in.readUTF();

		this.xfile_charge_volume = in.readUTF();

		this.late_call_config_id = in.readUTF();

		this.late_call_expiration_date = in.readUTF();

		this.late_call_grace_time = in.readUTF();

		this.mcprincing_value = in.readUTF();

		this.mc_balance = in.readUTF();

		this.mc_fup_indicator = in.readUTF();

		this.mc_limited = in.readUTF();

		this.mc_original_amount = in.readUTF();

		this.mc_pricing_mech = in.readUTF();

		this.mc_used_units = in.readUTF();

		this.load_date_offset = in.readUTF();

		this.load_date_timestamp = in.readUTF();

		this.record_id_uct_ctrl = in.readUTF();

		this.cob_type2_a_party_type = in.readUTF();

		this.cob_type2_b_party_type = in.readUTF();

		this.cob_type2_callnature = in.readUTF();

		this.cob_type2_cnl_a_party = in.readUTF();

		this.cob_type2_cnl_b_party = in.readUTF();

		this.cob_type2_eot_a = in.readUTF();

		this.cob_type2_eot_b = in.readUTF();

		this.cob_type2_onnet_ind = in.readUTF();

		this.cob_type2_originidentification = in.readUTF();

		this.cob_type2_recordtype = in.readUTF();

		this.cob_type2_tfi = in.readUTF();

		this.imp2_valid_from_smart_bberry = in.readUTF();

		this.imp2_valid_from_smart_dsl = in.readUTF();

		this.imp2_valid_from_smart_sms = in.readUTF();

		this.imp2_valid_from_smart_web = in.readUTF();

		this.imp_party1_comm_name_1 = in.readUTF();

		this.imp_party1_comm_spec_rate_1 = in.readUTF();

		this.imp_party1_comm_spec_rate_2 = in.readUTF();

		this.imp_party2_comm_name_1 = in.readUTF();

		this.imp_party2_comm_spec_rate_1 = in.readUTF();

		this.imp_party2_comm_spec_rate_2 = in.readUTF();

		this.rated_flat_amnt_orig_mc_amnt = in.readUTF();

		this.s_p_number_translated_address = in.readUTF();

		this.row_id = in.readUTF();

		this.loteid = in.readUTF();

		this.arquivo = in.readUTF();

		this.arquivots = in.readUTF();

		this.currentdate = in.readUTF();

	}

	@Override

	public void write(DataOutput out) throws IOException {

		out.writeUTF(this.num_rowid_ogg);

		out.writeUTF(this.cod_ogg);

		out.writeUTF(this.tpo_operacao_ogg);

		out.writeUTF(this.dat_ogg);

		out.writeUTF(this.nom_sistema_ogg);

		out.writeUTF(this.nom_interface_ogg);

		out.writeUTF(this.aggreg_info_aggreg_purpose);

		out.writeUTF(this.aggreg_info_agg_trans_id);

		out.writeUTF(this.aggreg_info_applied_pack_id);

		out.writeUTF(this.aggreg_info_rec_counter);

		out.writeUTF(this.aggreg_info_summary_id);

		out.writeUTF(this.alt_rated_amount);

		out.writeUTF(this.alt_rated_currency);

		out.writeUTF(this.alt_tariff_clicks_volume);

		out.writeUTF(this.alt_tmcode);

		out.writeUTF(this.an_pack_an_package_id_list);

		out.writeUTF(this.an_pack_orig_an_pack_id_list);

		out.writeUTF(this.bal_audit_data_account_id);

		out.writeUTF(this.bal_audit_data_account_type);

		out.writeUTF(this.bal_audit_data_account_type_id);

		out.writeUTF(this.bal_audit_dat_balance_accum);

		out.writeUTF(this.bal_audit_dat_balance_prod_id);

		out.writeUTF(this.bal_audit_dat_balance_type);

		out.writeUTF(this.bal_audit_dat_bal_after_chg);

		out.writeUTF(this.bal_audit_dat_bal_before_chg);

		out.writeUTF(this.bal_audit_dat_bundl_prod_id);

		out.writeUTF(this.bal_audit_dat_contract_id);

		out.writeUTF(this.bal_audit_dat_offer_seqno);

		out.writeUTF(this.bal_audit_dat_offer_sncode);

		out.writeUTF(this.bal_audit_dat_prep_credit_ind);

		out.writeUTF(this.bal_audit_dat_purchase_seq_no);

		out.writeUTF(this.bal_audit_dat_shacc_packid);

		out.writeUTF(this.bal_audit_dat_user_profile_id);

		out.writeUTF(this.bop_info_bop_package_id);

		out.writeUTF(this.bop_info_bop_package_pkey);

		out.writeUTF(this.bop_info_bop_package_version);

		out.writeUTF(this.bop_info_detail_billed_ind);

		out.writeUTF(this.bop_info_detail_bop_altern_ind);

		out.writeUTF(this.bop_info_detail_contracted_ind);

		out.writeUTF(this.bop_info_detail_sequence_rp);

		out.writeUTF(this.bop_info_detail_sequence_sp);

		out.writeUTF(this.bop_tariff_info_day_catcode);

		out.writeUTF(this.bop_tariff_info_egcode);

		out.writeUTF(this.bop_tariff_info_egversion);

		out.writeUTF(this.bop_tariff_info_gvcode);

		out.writeUTF(this.bop_tariff_info_rpcode);

		out.writeUTF(this.bop_tariff_info_rpversion);

		out.writeUTF(this.bop_tariff_info_sncode);

		out.writeUTF(this.bop_tariff_info_spcode);

		out.writeUTF(this.bop_tariff_info_time_band_code);

		out.writeUTF(this.bop_tariff_info_tmcode);

		out.writeUTF(this.bop_tariff_info_tmversion);

		out.writeUTF(this.bop_tariff_info_tm_used_type);

		out.writeUTF(this.bop_tariff_info_twcode);

		out.writeUTF(this.bop_tariff_info_usage_ind);

		out.writeUTF(this.bop_tariff_info_zncode);

		out.writeUTF(this.bop_tariff_info_zpcode);

		out.writeUTF(this.bpartn_sum_info_time_slice_lb);

		out.writeUTF(this.bpartn_sum_info_time_slice_rb);

		out.writeUTF(this.bundle_info_bundle_purchase_id);

		out.writeUTF(this.bundle_info_bundle_purch_ind);

		out.writeUTF(this.bundle_info_contract_id);

		out.writeUTF(this.bundle_info_purchase_seq_no);

		out.writeUTF(this.bundle_info_sequence_number);

		out.writeUTF(this.bundle_info_sncode);

		out.writeUTF(this.bundle_info_state);

		out.writeUTF(this.bundle_info_termination);

		out.writeUTF(this.bundle_info_user_profile_id);

		out.writeUTF(this.bundle_info_valid_from);

		out.writeUTF(this.bundle_info_valid_to);

		out.writeUTF(this.bundle_info_version);

		out.writeUTF(this.bundle_usg_bundle_covered_usg);

		out.writeUTF(this.business_info_bs_id);

		out.writeUTF(this.business_info_bs_version);

		out.writeUTF(this.business_info_charge_item_id);

		out.writeUTF(this.business_info_charge_party_id);

		out.writeUTF(this.business_info_c_p_field_ref);

		out.writeUTF(this.business_info_o_p_field_ref);

		out.writeUTF(this.business_info_pre_bs_id);

		out.writeUTF(this.business_info_pre_bs_version);

		out.writeUTF(this.bus_partner_info_tax_mode);

		out.writeUTF(this.call_dest);

		out.writeUTF(this.call_type);

		out.writeUTF(this.camel_dest_addr_user_prof_id);

		out.writeUTF(this.camel_msc_address);

		out.writeUTF(this.camel_msc_addr_user_prof_id);

		out.writeUTF(this.camel_reference_number);

		out.writeUTF(this.camel_srv_addr_user_prof_id);

		out.writeUTF(this.charge_info_cash_flow_direct);

		out.writeUTF(this.charge_info_disable_tax);

		out.writeUTF(this.charging_characteristics);

		out.writeUTF(this.consumer_info_address);

		out.writeUTF(this.consumer_info_contract_id);

		out.writeUTF(this.consumer_info_numbering_plan);

		out.writeUTF(this.content_advised_charge_ind);

		out.writeUTF(this.content_authorisation_code);

		out.writeUTF(this.content_content_charging_point);

		out.writeUTF(this.content_contract_pkey);

		out.writeUTF(this.content_desc_suppress);

		out.writeUTF(this.content_paid_ind);

		out.writeUTF(this.content_payment_method);

		out.writeUTF(this.content_provider_address);

		out.writeUTF(this.content_provider_carrier_code);

		out.writeUTF(this.content_provider_clir);

		out.writeUTF(this.content_provider_iac);

		out.writeUTF(this.content_provider_modif_ind);

		out.writeUTF(this.content_provider_network_code);

		out.writeUTF(this.content_provid_dynamic_address);

		out.writeUTF(this.content_provid_local_pref_len);

		out.writeUTF(this.content_provid_numbering_plan);

		out.writeUTF(this.content_provid_other_location);

		out.writeUTF(this.content_provid_type_of_number);

		out.writeUTF(this.content_provid_user_profile_id);

		out.writeUTF(this.content_refund_ind);

		out.writeUTF(this.content_short_desc);

		out.writeUTF(this.content_transaction_id);

		out.writeUTF(this.control_data_record_age);

		out.writeUTF(this.cug_info_cug_id);

		out.writeUTF(this.cug_info_cug_index);

		out.writeUTF(this.customer_info_contract_type_id);

		out.writeUTF(this.customer_info_contraggrpack_id);

		out.writeUTF(this.customer_info_reco_ind);

		out.writeUTF(this.cust_info_address);

		out.writeUTF(this.cust_info_alternate_tmcode);

		out.writeUTF(this.cust_info_an_package_id_list);

		out.writeUTF(this.cust_info_bill_cycle);

		out.writeUTF(this.cust_info_bu_address);

		out.writeUTF(this.cust_info_bu_numbering_plan);

		out.writeUTF(this.cust_info_charging_engine);

		out.writeUTF(this.cust_info_contract_id);

		out.writeUTF(this.cust_info_customer_id);

		out.writeUTF(this.cust_info_delete_after_billing);

		out.writeUTF(this.cust_info_dn_id);

		out.writeUTF(this.cust_info_main_msisdn);

		out.writeUTF(this.cust_info_numbering_plan);

		out.writeUTF(this.cust_info_port_id);

		out.writeUTF(this.cust_info_serv_bid_id);

		out.writeUTF(this.cust_info_sim_number);

		out.writeUTF(this.cust_info_sim_sernumber);

		out.writeUTF(this.cust_info_subs_code);

		out.writeUTF(this.cust_info_subs_tag);

		out.writeUTF(this.cust_info_user_profile_id);

		out.writeUTF(this.data_volume);

		out.writeUTF(this.data_volume_umcode);

		out.writeUTF(this.desc_prod_usage_long_desc);

		out.writeUTF(this.destination_field_id);

		out.writeUTF(this.downlink_volume_umcode);

		out.writeUTF(this.downlink_volume_volume);

		out.writeUTF(this.duration_umcode);

		out.writeUTF(this.duration_volume);

		out.writeUTF(this.entry_date_offset);

		out.writeUTF(this.entry_date_timestamp);

		out.writeUTF(this.event_info_event_type);

		out.writeUTF(this.event_status_info_message_id);

		out.writeUTF(this.event_umcode);

		out.writeUTF(this.event_volume);

		out.writeUTF(this.export_file);

		out.writeUTF(this.ext_balance_amnt_amount);

		out.writeUTF(this.follow_up_call_type);

		out.writeUTF(this.for_amount_amount);

		out.writeUTF(this.for_amount_currency);

		out.writeUTF(this.for_amount_gross_ind);

		out.writeUTF(this.for_amount_tax);

		out.writeUTF(this.for_freechrg_amount);

		out.writeUTF(this.for_freechrg_currency);

		out.writeUTF(this.for_freechrg_gross_ind);

		out.writeUTF(this.for_freechrg_tax);

		out.writeUTF(this.free_charge_amount);

		out.writeUTF(this.free_charge_amount_non_rpc);

		out.writeUTF(this.free_charge_currency);

		out.writeUTF(this.free_charge_curr_non_rpc);

		out.writeUTF(this.free_charge_gross_ind);

		out.writeUTF(this.free_charge_gross_ind_nrpc);

		out.writeUTF(this.free_charge_tax);

		out.writeUTF(this.free_charge_tax_nrpc);

		out.writeUTF(this.free_clicks_umcode);

		out.writeUTF(this.free_clicks_volume);

		out.writeUTF(this.free_rated_volume_umcode);

		out.writeUTF(this.free_rated_volume_volume);

		out.writeUTF(this.free_rounded_volume_umcode);

		out.writeUTF(this.free_rounded_volume_volume);

		out.writeUTF(this.free_units_info_account_key);

		out.writeUTF(this.free_units_info_account_origin);

		out.writeUTF(this.free_units_info_acc_hist_id);

		out.writeUTF(this.free_units_info_appl_method);

		out.writeUTF(this.free_units_info_chg_red_quota);

		out.writeUTF(this.free_units_info_discount_rate);

		out.writeUTF(this.free_units_info_discount_type);

		out.writeUTF(this.free_units_info_freeunitoption);

		out.writeUTF(this.free_units_info_fup_seq);

		out.writeUTF(this.free_units_info_fu_pack_id);

		out.writeUTF(this.free_units_info_part_creator);

		out.writeUTF(this.free_units_info_previous_seqno);

		out.writeUTF(this.free_units_info_seqno);

		out.writeUTF(this.free_units_info_version);

		out.writeUTF(this.home_network_code);

		out.writeUTF(this.hscsd_info_aiur);

		out.writeUTF(this.hscsd_info_channels_max);

		out.writeUTF(this.hscsd_info_channels_used);

		out.writeUTF(this.hscsd_info_coding_acc);

		out.writeUTF(this.hscsd_info_coding_used);

		out.writeUTF(this.hscsd_info_fnur);

		out.writeUTF(this.hscsd_info_init_party);

		out.writeUTF(this.imp_party1_address);

		out.writeUTF(this.imp_party1_alternate_tmcode);

		out.writeUTF(this.imp_party1_an_package_id_list);

		out.writeUTF(this.imp_party1_bill_cycle);

		out.writeUTF(this.imp_party1_numbering_plan);

		out.writeUTF(this.imp_party1_user_profile_id);

		out.writeUTF(this.imp_party2_address);

		out.writeUTF(this.imp_party2_alternate_tmcode);

		out.writeUTF(this.imp_party2_an_package_id_list);

		out.writeUTF(this.imp_party2_bill_cycle);

		out.writeUTF(this.imp_party2_numbering_plan);

		out.writeUTF(this.imp_party2_user_profile_id);

		out.writeUTF(this.imp_party3_address);

		out.writeUTF(this.imp_party3_alternate_tmcode);

		out.writeUTF(this.imp_party3_an_package_id_list);

		out.writeUTF(this.imp_party3_bill_cycle);

		out.writeUTF(this.imp_party3_numbering_plan);

		out.writeUTF(this.imp_party3_user_profile_id);

		out.writeUTF(this.imp_party4_address);

		out.writeUTF(this.imp_party4_alternate_tmcode);

		out.writeUTF(this.imp_party4_an_package_id_list);

		out.writeUTF(this.imp_party4_bill_cycle);

		out.writeUTF(this.imp_party4_numbering_plan);

		out.writeUTF(this.imp_party4_parent_contract_id);

		out.writeUTF(this.imp_party4_user_profile_id);

		out.writeUTF(this.imp_party5_address);

		out.writeUTF(this.imp_party5_alternate_tmcode);

		out.writeUTF(this.imp_party5_an_package_id_list);

		out.writeUTF(this.imp_party5_bill_cycle);

		out.writeUTF(this.imp_party5_numbering_plan);

		out.writeUTF(this.imp_party5_parent_contract_id);

		out.writeUTF(this.imp_party5_user_profile_id);

		out.writeUTF(this.initial_start_time_timestamp);

		out.writeUTF(this.initial_start_time_time_offset);

		out.writeUTF(this.lcs_qos_deliv_horizontal_accur);

		out.writeUTF(this.lcs_qos_deliv_tracking_frequen);

		out.writeUTF(this.lcs_qos_deliv_tracking_period);

		out.writeUTF(this.lcs_qos_deliv_vertical_accur);

		out.writeUTF(this.lcs_qos_info_age_of_location);

		out.writeUTF(this.lcs_qos_info_position_method);

		out.writeUTF(this.lcs_qos_info_response_time);

		out.writeUTF(this.lcs_qos_info_response_time_cat);

		out.writeUTF(this.lcs_qos_req_horizontal_accur);

		out.writeUTF(this.lcs_qos_req_tracking_frequency);

		out.writeUTF(this.lcs_qos_req_tracking_period);

		out.writeUTF(this.lcs_qos_req_vertical_accur);

		out.writeUTF(this.ldc_info_carrier_code);

		out.writeUTF(this.ldc_info_contract_pkey);

		out.writeUTF(this.ldc_info_home_net_ind);

		out.writeUTF(this.lec_info_contract_pkey);

		out.writeUTF(this.lec_info_home_net_ind);

		out.writeUTF(this.lzlist);

		out.writeUTF(this.mc_info_code);

		out.writeUTF(this.mc_info_ind);

		out.writeUTF(this.mc_info_micro_cell_information);

		out.writeUTF(this.mc_scalefactor);

		out.writeUTF(this.messages_umcode);

		out.writeUTF(this.messages_volume);

		out.writeUTF(this.micro_cell_imcscalefactortype);

		out.writeUTF(this.micro_cell_mc_code);

		out.writeUTF(this.micro_cell_mc_pkey);

		out.writeUTF(this.micro_cell_mc_type);

		out.writeUTF(this.micro_cell_scalefactor);

		out.writeUTF(this.network_init_context_ind);

		out.writeUTF(this.net_element_home_bid_id);

		out.writeUTF(this.net_element_network_code);

		out.writeUTF(this.net_element_netw_element_id);

		out.writeUTF(this.net_element_user_profile_id);

		out.writeUTF(this.normed_net_elem_address);

		out.writeUTF(this.normed_net_elem_int_acc_code);

		out.writeUTF(this.normed_net_elem_number_plan);

		out.writeUTF(this.normed_rtd_num_address);

		out.writeUTF(this.normed_rtd_num_int_acc_code);

		out.writeUTF(this.normed_rtd_num_number_plan);

		out.writeUTF(this.normtrkgrp_in_address);

		out.writeUTF(this.normtrkgrp_in_numberingplan);

		out.writeUTF(this.normtrkgrp_out_address);

		out.writeUTF(this.normtrkgrp_out_numberingplan);

		out.writeUTF(this.number_of_rejections);

		out.writeUTF(this.offer_offer_seqno);

		out.writeUTF(this.offer_offer_sncode);

		out.writeUTF(this.origin_field_id);

		out.writeUTF(this.orig_entry_date_timestamp);

		out.writeUTF(this.orig_entry_date_timezone_id);

		out.writeUTF(this.orig_entry_date_timezone_pkey);

		out.writeUTF(this.orig_entry_date_time_offset);

		out.writeUTF(this.or_flag);

		out.writeUTF(this.o_p_normed_num_address);

		out.writeUTF(this.o_p_normed_num_int_acc_code);

		out.writeUTF(this.o_p_normed_num_number_plan);

		out.writeUTF(this.o_p_number_address);

		out.writeUTF(this.o_p_number_backup_address);

		out.writeUTF(this.o_p_number_carrier_code);

		out.writeUTF(this.o_p_number_clir);

		out.writeUTF(this.o_p_number_numbering_plan);

		out.writeUTF(this.o_p_number_other_location);

		out.writeUTF(this.o_p_number_type_of_number);

		out.writeUTF(this.o_p_number_user_profile_id);

		out.writeUTF(this.o_p_pubid_address);

		out.writeUTF(this.o_p_pubid_numbering_plan);

		out.writeUTF(this.o_p_pubid_type_of_number);

		out.writeUTF(this.price_plan_info_chrgplanid);

		out.writeUTF(this.price_plan_info_evalquantity);

		out.writeUTF(this.price_plan_info_threshold);

		out.writeUTF(this.promo_info_b_number_cat);

		out.writeUTF(this.qos_negot_delay);

		out.writeUTF(this.qos_negot_mean_throughput);

		out.writeUTF(this.qos_negot_peak_throughput);

		out.writeUTF(this.qos_negot_precedence);

		out.writeUTF(this.qos_negot_reliability);

		out.writeUTF(this.qos_profile);

		out.writeUTF(this.qos_req_delay);

		out.writeUTF(this.qos_req_mean_throughput);

		out.writeUTF(this.qos_req_peak_throughput);

		out.writeUTF(this.qos_req_precedence);

		out.writeUTF(this.qos_req_reliability);

		out.writeUTF(this.rated_clicks_umcode);

		out.writeUTF(this.rated_clicks_volume);

		out.writeUTF(this.rated_flat_amnt_gross_ind_nrpc);

		out.writeUTF(this.rated_flat_amnt_orig_currency);

		out.writeUTF(this.rated_flat_amnt_orig_gross_ind);

		out.writeUTF(this.rated_flat_amnt_tax_nrpc);

		out.writeUTF(this.rated_flat_amount);

		out.writeUTF(this.rated_flat_amount_currency);

		out.writeUTF(this.rated_flat_amount_gross_ind);

		out.writeUTF(this.rated_flat_amount_non_rpc);

		out.writeUTF(this.rated_flat_amount_non_rpc_curr);

		out.writeUTF(this.rated_flat_amount_orig_amount);

		out.writeUTF(this.rated_flat_amount_orig_tax);

		out.writeUTF(this.rated_flat_amount_tax);

		out.writeUTF(this.rated_volume);

		out.writeUTF(this.rated_volume_umcode);

		out.writeUTF(this.recipient_net_address);

		out.writeUTF(this.recipient_net_numbering_plan);

		out.writeUTF(this.record_id_call_id);

		out.writeUTF(this.record_id_cdr_id);

		out.writeUTF(this.record_id_cdr_sub_id);

		out.writeUTF(this.record_id_event_ref);

		out.writeUTF(this.record_id_orig_cdr_id);

		out.writeUTF(this.record_id_rap_sequence_num);

		out.writeUTF(this.record_id_rerate_seqno);

		out.writeUTF(this.record_id_shaacc_unique_id);

		out.writeUTF(this.record_id_tap_sequence_num);

		out.writeUTF(this.record_id_udr_file_id);

		out.writeUTF(this.record_type_record_category);

		out.writeUTF(this.record_type_summary_ind);

		out.writeUTF(this.refer_contr_contract_id);

		out.writeUTF(this.refer_contr_reference_type);

		out.writeUTF(this.rejected_base_part);

		out.writeUTF(this.reject_reason_code);

		out.writeUTF(this.remark);

		out.writeUTF(this.rerate_info_rerate_reason_id);

		out.writeUTF(this.rerate_info_rerate_record_type);

		out.writeUTF(this.rerate_info_rerate_request_id);

		out.writeUTF(this.rerate_info_urh_id);

		out.writeUTF(this.rounded_volume);

		out.writeUTF(this.rounded_volume_umcode);

		out.writeUTF(this.routing_network_code);

		out.writeUTF(this.routing_number_backup_address);

		out.writeUTF(this.routing_user_profile_id);

		out.writeUTF(this.scu_id_address);

		out.writeUTF(this.scu_id_user_profile_id);

		out.writeUTF(this.scu_info_priority_code);

		out.writeUTF(this.service_action_code);

		out.writeUTF(this.service_guaranteed_bit_rate);

		out.writeUTF(this.service_hscsd_ind);

		out.writeUTF(this.service_ims_signalling_context);

		out.writeUTF(this.service_logic_code);

		out.writeUTF(this.service_max_bit_rate);

		out.writeUTF(this.service_service_type);

		out.writeUTF(this.service_used_service);

		out.writeUTF(this.service_user_protocol_ind);

		out.writeUTF(this.service_vas_code);

		out.writeUTF(this.serv_pdp_addr_apn_split_ind);

		out.writeUTF(this.sgsn_addresses);

		out.writeUTF(this.spec_num_info_apply_free_units);

		out.writeUTF(this.start_time_charge_offset);

		out.writeUTF(this.start_time_charge_timestamp);

		out.writeUTF(this.start_time_offset);

		out.writeUTF(this.start_time_timestamp);

		out.writeUTF(this.sum_reference_single_id);

		out.writeUTF(this.s_pdp_address);

		out.writeUTF(this.s_pdp_carrier_code);

		out.writeUTF(this.s_pdp_clir);

		out.writeUTF(this.s_pdp_intern_access_code);

		out.writeUTF(this.s_pdp_modification_ind);

		out.writeUTF(this.s_pdp_network_code);

		out.writeUTF(this.s_pdp_numbering_plan);

		out.writeUTF(this.s_pdp_type_of_number);

		out.writeUTF(this.s_pdp_user_profile_id);

		out.writeUTF(this.s_p_equipment_class_mark);

		out.writeUTF(this.s_p_equipment_number);

		out.writeUTF(this.s_p_home_id_description);

		out.writeUTF(this.s_p_home_id_home_bid_id);

		out.writeUTF(this.s_p_home_id_name);

		out.writeUTF(this.s_p_home_id_network);

		out.writeUTF(this.s_p_home_loc_address);

		out.writeUTF(this.s_p_home_loc_numbering_plan);

		out.writeUTF(this.s_p_location_address);

		out.writeUTF(this.s_p_location_numbering_plan);

		out.writeUTF(this.s_p_loc_serving_bid_id);

		out.writeUTF(this.s_p_loc_serving_location);

		out.writeUTF(this.s_p_number_address);

		out.writeUTF(this.s_p_number_home_bid_id);

		out.writeUTF(this.s_p_number_network_code);

		out.writeUTF(this.s_p_number_numbering_plan);

		out.writeUTF(this.s_p_number_user_profile_id);

		out.writeUTF(this.s_p_port_address);

		out.writeUTF(this.s_p_port_numbering_plan);

		out.writeUTF(this.s_p_port_user_profile_id);

		out.writeUTF(this.tariff_detail_chgbl_quantity);

		out.writeUTF(this.tariff_detail_ext_chrg_udmcode);

		out.writeUTF(this.tariff_detail_interconnect_ind);

		out.writeUTF(this.tariff_detail_rate_type_id);

		out.writeUTF(this.tariff_detail_rtx_charge_type);

		out.writeUTF(this.tariff_detail_ttcode);

		out.writeUTF(this.tariff_info_catalogue_id);

		out.writeUTF(this.tariff_info_catalogue_vers);

		out.writeUTF(this.tariff_info_ctlg_elm_id);

		out.writeUTF(this.tariff_info_egcode);

		out.writeUTF(this.tariff_info_egversion);

		out.writeUTF(this.tariff_info_gvcode);

		out.writeUTF(this.tariff_info_pricelist_id);

		out.writeUTF(this.tariff_info_pricelist_pkey);

		out.writeUTF(this.tariff_info_pricelist_vers);

		out.writeUTF(this.tariff_info_price_def_vers);

		out.writeUTF(this.tariff_info_rpcode);

		out.writeUTF(this.tariff_info_rpversion);

		out.writeUTF(this.tariff_info_sncode);

		out.writeUTF(this.tariff_info_spcode);

		out.writeUTF(this.tariff_info_time_band_code);

		out.writeUTF(this.tariff_info_tmcode);

		out.writeUTF(this.tariff_info_tmversion);

		out.writeUTF(this.tariff_info_tm_used_type);

		out.writeUTF(this.tariff_info_twcode);

		out.writeUTF(this.tariff_info_usage_ind);

		out.writeUTF(this.tariff_info_zncode);

		out.writeUTF(this.tariff_info_zpcode);

		out.writeUTF(this.tariff_info_zpcode_day_catcode);

		out.writeUTF(this.tax_info_serv_cat);

		out.writeUTF(this.tax_info_serv_code);

		out.writeUTF(this.tax_info_serv_type);

		out.writeUTF(this.techn_info_fixed_mobile_ind);

		out.writeUTF(this.techn_info_home_terminated_ind);

		out.writeUTF(this.techn_info_prepay_ind);

		out.writeUTF(this.techn_info_pre_rated_ind);

		out.writeUTF(this.techn_info_rev_charging_ind);

		out.writeUTF(this.techn_info_sccode);

		out.writeUTF(this.techn_info_termination_ind);

		out.writeUTF(this.trunk_group_in_address);

		out.writeUTF(this.trunk_group_in_numberingplan);

		out.writeUTF(this.trunk_group_in_typeofnumber);

		out.writeUTF(this.trunk_group_out_address);

		out.writeUTF(this.trunk_group_out_numberingplan);

		out.writeUTF(this.trunk_group_out_typeofnumber);

		out.writeUTF(this.t_p_number_user_profile_id);

		out.writeUTF(this.udr_basepart_id);

		out.writeUTF(this.udr_chargepart_id);

		out.writeUTF(this.uds_base_part_id);

		out.writeUTF(this.uds_charge_part_id);

		out.writeUTF(this.uds_free_unit_part_id);

		out.writeUTF(this.uds_promotion_part_id);

		out.writeUTF(this.uds_record_id);

		out.writeUTF(this.uds_stream_id);

		out.writeUTF(this.umts_qos_negot_allc_retn_prior);

		out.writeUTF(this.umts_qos_negot_delay);

		out.writeUTF(this.umts_qos_negot_delivery_order);

		out.writeUTF(this.umts_qos_negot_erroneous_sdus);

		out.writeUTF(this.umts_qos_negot_handl_priority);

		out.writeUTF(this.umts_qos_negot_max_size_sdu);

		out.writeUTF(this.umts_qos_negot_rate_downlink);

		out.writeUTF(this.umts_qos_negot_rate_uplink);

		out.writeUTF(this.umts_qos_negot_residual_ber);

		out.writeUTF(this.umts_qos_negot_sdu_err_ratio);

		out.writeUTF(this.umts_qos_negot_traffic_class);

		out.writeUTF(this.umts_qos_req_allc_retn_prior);

		out.writeUTF(this.umts_qos_req_delay);

		out.writeUTF(this.umts_qos_req_delivery_order);

		out.writeUTF(this.umts_qos_req_erroneous_sdus);

		out.writeUTF(this.umts_qos_req_handl_priority);

		out.writeUTF(this.umts_qos_req_max_size_sdu);

		out.writeUTF(this.umts_qos_req_rate_downlink);

		out.writeUTF(this.umts_qos_req_rate_uplink);

		out.writeUTF(this.umts_qos_req_residual_ber);

		out.writeUTF(this.umts_qos_req_sdu_error_ratio);

		out.writeUTF(this.umts_qos_req_traffic_class);

		out.writeUTF(this.unbilledamtpaymresp_customerid);

		out.writeUTF(this.unbilled_amount_amount);

		out.writeUTF(this.unbilled_amount_currency);

		out.writeUTF(this.unbilled_amount_gross_ind);

		out.writeUTF(this.unbilled_amount_tax);

		out.writeUTF(this.uplink_volume_umcode);

		out.writeUTF(this.uplink_volume_volume);

		out.writeUTF(this.vpn_info_vpn_call_type);

		out.writeUTF(this.vpn_number_address);

		out.writeUTF(this.vpn_number_carrier_code);

		out.writeUTF(this.vpn_number_clir);

		out.writeUTF(this.vpn_number_dynamic_address);

		out.writeUTF(this.vpn_number_int_access_code);

		out.writeUTF(this.vpn_number_local_prefix_len);

		out.writeUTF(this.vpn_number_modification_ind);

		out.writeUTF(this.vpn_number_network_code);

		out.writeUTF(this.vpn_number_numbering_plan);

		out.writeUTF(this.vpn_number_type_of_number);

		out.writeUTF(this.vpn_number_user_profile_id);

		out.writeUTF(this.xfile_base_charge_amount);

		out.writeUTF(this.xfile_base_charge_currency);

		out.writeUTF(this.xfile_base_charge_gross_ind);

		out.writeUTF(this.xfile_base_charge_tax);

		out.writeUTF(this.xfile_call_type);

		out.writeUTF(this.xfile_charge_amount);

		out.writeUTF(this.xfile_charge_currency);

		out.writeUTF(this.xfile_charge_gross_ind);

		out.writeUTF(this.xfile_charge_tax);

		out.writeUTF(this.xfile_day_category_code);

		out.writeUTF(this.xfile_discount_amount);

		out.writeUTF(this.xfile_discount_currency);

		out.writeUTF(this.xfile_ic_charge_amount);

		out.writeUTF(this.xfile_ic_charge_currency);

		out.writeUTF(this.xfile_ic_charge_gross_ind);

		out.writeUTF(this.xfile_ic_charge_tax);

		out.writeUTF(this.xfile_ind);

		out.writeUTF(this.xfile_time_band_code);

		out.writeUTF(this.zero_rated_volume_umcode);

		out.writeUTF(this.zero_rated_volume_volume);

		out.writeUTF(this.zero_rounded_volume_umcode);

		out.writeUTF(this.zero_rounded_volume_volume);

		out.writeUTF(this.bal_audit_dat_valid_from);

		out.writeUTF(this.bal_audit_dat_valid_to);

		out.writeUTF(this.chrgaggrinfo_request_id);

		out.writeUTF(this.cust_info_customer_group);

		out.writeUTF(this.cust_info_parent_contract_id);

		out.writeUTF(this.imp_party1_parent_contract_id);

		out.writeUTF(this.imp_party2_parent_contract_id);

		out.writeUTF(this.imp_party3_parent_contract_id);

		out.writeUTF(this.net_element_address);

		out.writeUTF(this.net_element_numbering_plan);

		out.writeUTF(this.net_element_type_of_number);

		out.writeUTF(this.rated_flat_amnt_orig_disc_amnt);

		out.writeUTF(this.rated_flat_amount_disc_amount);

		out.writeUTF(this.reject_filter_id);

		out.writeUTF(this.routing_address);

		out.writeUTF(this.routing_numbering_plan);

		out.writeUTF(this.routing_type_of_number);

		out.writeUTF(this.tariff_detail_pricgalternpkey);

		out.writeUTF(this.tariff_detail_pricingalternid);

		out.writeUTF(this.t_p_number_address);

		out.writeUTF(this.t_p_number_numbering_plan);

		out.writeUTF(this.t_p_number_type_of_number);

		out.writeUTF(this.unbilled_amount_billing_acc);

		out.writeUTF(this.unbilled_amount_compl_cond_id);

		out.writeUTF(this.entry_date_sim_offset);

		out.writeUTF(this.entry_date_sim_timestamp);

		out.writeUTF(this.fu_pack_id_clone);

		out.writeUTF(this.micro_cell_mc_shdes);

		out.writeUTF(this.o_p_number_anonym_ind);

		out.writeUTF(this.o_p_subs_address);

		out.writeUTF(this.o_p_subs_carrier_code);

		out.writeUTF(this.o_p_subs_clir);

		out.writeUTF(this.o_p_subs_dynamic_address);

		out.writeUTF(this.o_p_subs_iac);

		out.writeUTF(this.o_p_subs_local_prefix_len);

		out.writeUTF(this.o_p_subs_modification_ind);

		out.writeUTF(this.o_p_subs_network_code);

		out.writeUTF(this.o_p_subs_numbering_plan);

		out.writeUTF(this.o_p_subs_type_of_number);

		out.writeUTF(this.record_id_ext_call_id);

		out.writeUTF(this.record_id_ext_file_id);

		out.writeUTF(this.redirected_address);

		out.writeUTF(this.redirected_carrier_code);

		out.writeUTF(this.redirected_clir);

		out.writeUTF(this.redirected_dynamic_address);

		out.writeUTF(this.redirected_iac);

		out.writeUTF(this.redirected_local_prefix_len);

		out.writeUTF(this.redirected_modification_ind);

		out.writeUTF(this.redirected_network_code);

		out.writeUTF(this.redirected_numbering_plan);

		out.writeUTF(this.redirected_type_of_number);

		out.writeUTF(this.srvcode);

		out.writeUTF(this.start_time_original_offset);

		out.writeUTF(this.start_time_original_time);

		out.writeUTF(this.s_p_location_area_code);

		out.writeUTF(this.tariff_info_zodes);

		out.writeUTF(this.tariff_info_zpdes);

		out.writeUTF(this.techn_info_call_nature);

		out.writeUTF(this.techn_info_charged_party);

		out.writeUTF(this.techn_info_lng_dist_carrier_cd);

		out.writeUTF(this.translated_address);

		out.writeUTF(this.translated_carrier_code);

		out.writeUTF(this.translated_clir);

		out.writeUTF(this.translated_dynamic_address);

		out.writeUTF(this.translated_iac);

		out.writeUTF(this.translated_local_prefix_len);

		out.writeUTF(this.translated_modification_ind);

		out.writeUTF(this.translated_network_code);

		out.writeUTF(this.translated_numbering_plan);

		out.writeUTF(this.translated_type_of_number);

		out.writeUTF(this.valid_from_smart_bberry);

		out.writeUTF(this.valid_from_smart_dsl);

		out.writeUTF(this.valid_from_smart_sms);

		out.writeUTF(this.valid_from_smart_web);

		out.writeUTF(this.xfile_charge_roam_scenario_id);

		out.writeUTF(this.xfile_charge_umcode);

		out.writeUTF(this.xfile_charge_volume);

		out.writeUTF(this.late_call_config_id);

		out.writeUTF(this.late_call_expiration_date);

		out.writeUTF(this.late_call_grace_time);

		out.writeUTF(this.mcprincing_value);

		out.writeUTF(this.mc_balance);

		out.writeUTF(this.mc_fup_indicator);

		out.writeUTF(this.mc_limited);

		out.writeUTF(this.mc_original_amount);

		out.writeUTF(this.mc_pricing_mech);

		out.writeUTF(this.mc_used_units);

		out.writeUTF(this.load_date_offset);

		out.writeUTF(this.load_date_timestamp);

		out.writeUTF(this.record_id_uct_ctrl);

		out.writeUTF(this.cob_type2_a_party_type);

		out.writeUTF(this.cob_type2_b_party_type);

		out.writeUTF(this.cob_type2_callnature);

		out.writeUTF(this.cob_type2_cnl_a_party);

		out.writeUTF(this.cob_type2_cnl_b_party);

		out.writeUTF(this.cob_type2_eot_a);

		out.writeUTF(this.cob_type2_eot_b);

		out.writeUTF(this.cob_type2_onnet_ind);

		out.writeUTF(this.cob_type2_originidentification);

		out.writeUTF(this.cob_type2_recordtype);

		out.writeUTF(this.cob_type2_tfi);

		out.writeUTF(this.imp2_valid_from_smart_bberry);

		out.writeUTF(this.imp2_valid_from_smart_dsl);

		out.writeUTF(this.imp2_valid_from_smart_sms);

		out.writeUTF(this.imp2_valid_from_smart_web);

		out.writeUTF(this.imp_party1_comm_name_1);

		out.writeUTF(this.imp_party1_comm_spec_rate_1);

		out.writeUTF(this.imp_party1_comm_spec_rate_2);

		out.writeUTF(this.imp_party2_comm_name_1);

		out.writeUTF(this.imp_party2_comm_spec_rate_1);

		out.writeUTF(this.imp_party2_comm_spec_rate_2);

		out.writeUTF(this.rated_flat_amnt_orig_mc_amnt);

		out.writeUTF(this.s_p_number_translated_address);

		out.writeUTF(this.row_id);

		out.writeUTF(this.loteid);

		out.writeUTF(this.arquivo);

		out.writeUTF(this.arquivots);

		out.writeUTF(this.currentdate);

	}

	@Override

	public String getSPNumberAddress() {

		return this.s_p_number_address;

	}

	@Override

	public String getSPLocationAddress() {

		return this.s_p_location_address;

	}

	@Override

	public String getOPNormedNumAddress() {

		return this.o_p_normed_num_address;

	}

	@Override

	public String getOPNumberAddress() {

		return this.o_p_number_address;

	}

	@Override

	public String getNetElementAddress() {

		return this.net_element_address;

	}

	@Override

	public String getNumFollowUpCallType() {

		return this.follow_up_call_type;

	}

	@Override

	public String getNumTariffInfoSncode() {

		return this.tariff_info_sncode;

	}

	@Override

	public String getNumTariffInfoZncode() {

		return this.tariff_info_zncode;

	}

	@Override

	public String getNumTechnInfoLngDistCarrierCd() {

		return this.techn_info_lng_dist_carrier_cd;

	}

	@Override

	public String getLdcInfoCarrierCode() {

		return this.ldc_info_carrier_code;

	}

	@Override

	public String getNumTariffInfoTmcode() {

		return this.tariff_info_tmcode;

	}

	@Override

	public String getNumCustInfoContractId() {

		return this.cust_info_contract_id;

	}

	@Override

	public String getNumFreeUnitsInfoFuPackId() {

		return this.free_units_info_fu_pack_id;

	}

	@Override

	public String getSPLocationAreaCode() {

		return this.s_p_location_area_code;

	}

	@Override

	public String serialize() {

		sb.setLength(0);

		sb.append(num_rowid_ogg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cod_ogg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tpo_operacao_ogg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(dat_ogg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(nom_sistema_ogg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(nom_interface_ogg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(aggreg_info_aggreg_purpose).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(aggreg_info_agg_trans_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(aggreg_info_applied_pack_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(aggreg_info_rec_counter).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(aggreg_info_summary_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(alt_rated_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(alt_rated_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(alt_tariff_clicks_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(alt_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(an_pack_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(an_pack_orig_an_pack_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_data_account_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_data_account_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_data_account_type_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_balance_accum).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_balance_prod_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_balance_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_bal_after_chg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_bal_before_chg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_bundl_prod_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_offer_seqno).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_offer_sncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_prep_credit_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_purchase_seq_no).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_shacc_packid).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_bop_package_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_bop_package_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_bop_package_version).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_detail_billed_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_detail_bop_altern_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_detail_contracted_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_detail_sequence_rp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_info_detail_sequence_sp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_day_catcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_egcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_egversion).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_gvcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_rpcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_rpversion).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_sncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_spcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_time_band_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_tmversion).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_tm_used_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_twcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_usage_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_zncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bop_tariff_info_zpcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bpartn_sum_info_time_slice_lb).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bpartn_sum_info_time_slice_rb).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_bundle_purchase_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_bundle_purch_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_purchase_seq_no).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_sequence_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_sncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_state).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_termination).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_valid_from).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_valid_to).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_info_version).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bundle_usg_bundle_covered_usg).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_bs_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_bs_version).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_charge_item_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_charge_party_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_c_p_field_ref).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_o_p_field_ref).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_pre_bs_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(business_info_pre_bs_version).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bus_partner_info_tax_mode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(call_dest).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(call_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(camel_dest_addr_user_prof_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(camel_msc_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(camel_msc_addr_user_prof_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(camel_reference_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(camel_srv_addr_user_prof_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(charge_info_cash_flow_direct).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(charge_info_disable_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(charging_characteristics).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(consumer_info_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(consumer_info_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(consumer_info_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_advised_charge_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_authorisation_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_content_charging_point).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_contract_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_desc_suppress).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_paid_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_payment_method).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provider_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provider_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provider_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provider_iac).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provider_modif_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provider_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provid_dynamic_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provid_local_pref_len).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provid_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provid_other_location).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provid_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_provid_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_refund_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_short_desc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(content_transaction_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(control_data_record_age).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cug_info_cug_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cug_info_cug_index).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(customer_info_contract_type_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(customer_info_contraggrpack_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(customer_info_reco_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_alternate_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_bill_cycle).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_bu_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_bu_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_charging_engine).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_customer_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_delete_after_billing).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_dn_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_main_msisdn).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_port_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_serv_bid_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_sim_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_sim_sernumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_subs_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_subs_tag).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(data_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(data_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(desc_prod_usage_long_desc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(destination_field_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(downlink_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(downlink_volume_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(duration_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(duration_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(entry_date_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(entry_date_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(event_info_event_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(event_status_info_message_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(event_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(event_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(export_file).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(ext_balance_amnt_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(follow_up_call_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_amount_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_amount_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_amount_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_amount_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_freechrg_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_freechrg_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_freechrg_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(for_freechrg_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_amount_non_rpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_curr_non_rpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_gross_ind_nrpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_charge_tax_nrpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_clicks_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_clicks_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_rated_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_rated_volume_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_rounded_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_rounded_volume_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_account_key).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_account_origin).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_acc_hist_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_appl_method).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_chg_red_quota).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_discount_rate).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_discount_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_freeunitoption).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_fup_seq).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_fu_pack_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_part_creator).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_previous_seqno).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_seqno).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(free_units_info_version).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(home_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_aiur).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_channels_max).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_channels_used).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_coding_acc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_coding_used).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_fnur).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(hscsd_info_init_party).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_alternate_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_bill_cycle).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_alternate_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_bill_cycle).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_alternate_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_bill_cycle).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_alternate_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_bill_cycle).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_parent_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party4_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_alternate_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_an_package_id_list).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_bill_cycle).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_parent_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party5_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(initial_start_time_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(initial_start_time_time_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_deliv_horizontal_accur).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_deliv_tracking_frequen).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_deliv_tracking_period).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_deliv_vertical_accur).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_info_age_of_location).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_info_position_method).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_info_response_time).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_info_response_time_cat).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_req_horizontal_accur).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_req_tracking_frequency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_req_tracking_period).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lcs_qos_req_vertical_accur).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(ldc_info_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(ldc_info_contract_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(ldc_info_home_net_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lec_info_contract_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lec_info_home_net_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(lzlist).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_info_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_info_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_info_micro_cell_information).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_scalefactor).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(messages_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(messages_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(micro_cell_imcscalefactortype).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(micro_cell_mc_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(micro_cell_mc_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(micro_cell_mc_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(micro_cell_scalefactor).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(network_init_context_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_home_bid_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_netw_element_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normed_net_elem_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normed_net_elem_int_acc_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normed_net_elem_number_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normed_rtd_num_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normed_rtd_num_int_acc_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normed_rtd_num_number_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normtrkgrp_in_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normtrkgrp_in_numberingplan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normtrkgrp_out_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(normtrkgrp_out_numberingplan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(number_of_rejections).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(offer_offer_seqno).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(offer_offer_sncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(origin_field_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(orig_entry_date_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(orig_entry_date_timezone_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(orig_entry_date_timezone_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(orig_entry_date_time_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(or_flag).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_normed_num_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_normed_num_int_acc_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_normed_num_number_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_backup_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_other_location).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_pubid_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_pubid_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_pubid_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(price_plan_info_chrgplanid).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(price_plan_info_evalquantity).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(price_plan_info_threshold).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(promo_info_b_number_cat).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_negot_delay).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_negot_mean_throughput).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_negot_peak_throughput).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_negot_precedence).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_negot_reliability).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_profile).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_req_delay).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_req_mean_throughput).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_req_peak_throughput).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_req_precedence).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(qos_req_reliability).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_clicks_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_clicks_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amnt_gross_ind_nrpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amnt_orig_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amnt_orig_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amnt_tax_nrpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_non_rpc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_non_rpc_curr).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_orig_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_orig_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(recipient_net_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(recipient_net_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_call_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_cdr_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_cdr_sub_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_event_ref).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_orig_cdr_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_rap_sequence_num).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_rerate_seqno).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_shaacc_unique_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_tap_sequence_num).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_udr_file_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_type_record_category).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_type_summary_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(refer_contr_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(refer_contr_reference_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rejected_base_part).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(reject_reason_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(remark).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rerate_info_rerate_reason_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rerate_info_rerate_record_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rerate_info_rerate_request_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rerate_info_urh_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rounded_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rounded_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(routing_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(routing_number_backup_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(routing_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(scu_id_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(scu_id_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(scu_info_priority_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_action_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_guaranteed_bit_rate).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_hscsd_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_ims_signalling_context).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_logic_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_max_bit_rate).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_service_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_used_service).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_user_protocol_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(service_vas_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(serv_pdp_addr_apn_split_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(sgsn_addresses).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(spec_num_info_apply_free_units).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(start_time_charge_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(start_time_charge_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(start_time_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(start_time_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(sum_reference_single_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_intern_access_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_modification_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_pdp_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_equipment_class_mark).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_equipment_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_home_id_description).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_home_id_home_bid_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_home_id_name).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_home_id_network).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_home_loc_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_home_loc_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_location_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_location_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_loc_serving_bid_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_loc_serving_location).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_number_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_number_home_bid_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_number_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_number_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_number_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_port_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_port_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_port_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_chgbl_quantity).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_ext_chrg_udmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_interconnect_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_rate_type_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_rtx_charge_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_ttcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_catalogue_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_catalogue_vers).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_ctlg_elm_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_egcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_egversion).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_gvcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_pricelist_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_pricelist_pkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_pricelist_vers).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_price_def_vers).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_rpcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_rpversion).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_sncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_spcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_time_band_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_tmcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_tmversion).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_tm_used_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_twcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_usage_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_zncode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_zpcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_zpcode_day_catcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tax_info_serv_cat).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tax_info_serv_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tax_info_serv_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_fixed_mobile_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_home_terminated_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_prepay_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_pre_rated_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_rev_charging_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_sccode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_termination_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(trunk_group_in_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(trunk_group_in_numberingplan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(trunk_group_in_typeofnumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(trunk_group_out_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(trunk_group_out_numberingplan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(trunk_group_out_typeofnumber).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(t_p_number_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(udr_basepart_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(udr_chargepart_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uds_base_part_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uds_charge_part_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uds_free_unit_part_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uds_promotion_part_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uds_record_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uds_stream_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_allc_retn_prior).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_delay).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_delivery_order).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_erroneous_sdus).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_handl_priority).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_max_size_sdu).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_rate_downlink).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_rate_uplink).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_residual_ber).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_sdu_err_ratio).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_negot_traffic_class).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_allc_retn_prior).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_delay).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_delivery_order).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_erroneous_sdus).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_handl_priority).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_max_size_sdu).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_rate_downlink).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_rate_uplink).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_residual_ber).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_sdu_error_ratio).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(umts_qos_req_traffic_class).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilledamtpaymresp_customerid).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilled_amount_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilled_amount_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilled_amount_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilled_amount_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uplink_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(uplink_volume_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_info_vpn_call_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_dynamic_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_int_access_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_local_prefix_len).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_modification_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(vpn_number_user_profile_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_base_charge_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_base_charge_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_base_charge_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_base_charge_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_call_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_day_category_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_discount_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_discount_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_ic_charge_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_ic_charge_currency).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_ic_charge_gross_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_ic_charge_tax).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_time_band_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(zero_rated_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(zero_rated_volume_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(zero_rounded_volume_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(zero_rounded_volume_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_valid_from).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(bal_audit_dat_valid_to).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(chrgaggrinfo_request_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_customer_group).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cust_info_parent_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_parent_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_parent_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party3_parent_contract_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(net_element_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amnt_orig_disc_amnt).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amount_disc_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(reject_filter_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(routing_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(routing_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(routing_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_pricgalternpkey).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_detail_pricingalternid).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(t_p_number_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(t_p_number_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(t_p_number_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilled_amount_billing_acc).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(unbilled_amount_compl_cond_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(entry_date_sim_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(entry_date_sim_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(fu_pack_id_clone).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(micro_cell_mc_shdes).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_number_anonym_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_dynamic_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_iac).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_local_prefix_len).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_modification_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(o_p_subs_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_ext_call_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_ext_file_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_dynamic_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_iac).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_local_prefix_len).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_modification_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(redirected_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(srvcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(start_time_original_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(start_time_original_time).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_location_area_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_zodes).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(tariff_info_zpdes).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_call_nature).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_charged_party).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(techn_info_lng_dist_carrier_cd).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_carrier_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_clir).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_dynamic_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_iac).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_local_prefix_len).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_modification_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_network_code).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_numbering_plan).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(translated_type_of_number).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(valid_from_smart_bberry).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(valid_from_smart_dsl).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(valid_from_smart_sms).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(valid_from_smart_web).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_roam_scenario_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_umcode).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(xfile_charge_volume).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(late_call_config_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(late_call_expiration_date).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(late_call_grace_time).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mcprincing_value).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_balance).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_fup_indicator).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_limited).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_original_amount).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_pricing_mech).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(mc_used_units).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(load_date_offset).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(load_date_timestamp).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(record_id_uct_ctrl).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_a_party_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_b_party_type).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_callnature).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_cnl_a_party).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_cnl_b_party).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_eot_a).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_eot_b).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_onnet_ind).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_originidentification).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_recordtype).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(cob_type2_tfi).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp2_valid_from_smart_bberry).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp2_valid_from_smart_dsl).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp2_valid_from_smart_sms).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp2_valid_from_smart_web).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_comm_name_1).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_comm_spec_rate_1).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party1_comm_spec_rate_2).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_comm_name_1).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_comm_spec_rate_1).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(imp_party2_comm_spec_rate_2).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(rated_flat_amnt_orig_mc_amnt).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(s_p_number_translated_address).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(row_id).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(loteid).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(arquivo).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(arquivots).append(CommonsConstants.FILE_FIELD_SEPARATOR);

		sb.append(currentdate);

		return sb.toString();

	}

	@Override

	public Date getTrafTarDate() throws ParseException {

		// Nome do arquivo de entrada no procarq segue o padrão:

		// xxpump_SYSADM_UDR_LT_yyyyMMdd_HHmmss... etc

		return TraftarPosBscs9Constants.SDF_yyyy_MM_dd.parse(arquivo.substring(22, 32));

	}

	@Override

	public String toString() {

		return this.serialize();

	}

	/**
	 * 
	 * 
	 * O layout do começo do arquivo enviado pelo GG foi alterado. Foram removidas 3
	 * colunas e outras 2 trocaram de ordem. Ajuste para especializar o mapper de
	 * leitura do diretório ao
	 * 
	 * 
	 * invês de alterar todo o restante (mappers, entradas e saídas, tabelas no hive
	 * e no gpdb e impactos em outros projetos que utilizam a fonte).
	 * 
	 * 
	 */

	public boolean parseFromDirectoryText(String textString) {

		if (textString != null && !textString.trim().isEmpty()) {

			textString = textString.replaceAll("\"|<*NULL>*", "");

			String[] cols = textString.split(CommonsConstants.FILE_SPLIT_REGEX, 1);

			if (cols.length != 645)

				return false;

			int i = 0;

			this.setTraftarBscs9_part1_fromDirectory(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

			this.setTraftarBscs9_part2(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

			this.setTraftarBscs9_part3(cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],

					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++], cols[i++],
					cols[i++], cols[i++], cols[i++], cols[i++], cols[i++]);

			return true;

		}

		return false;

	}
}