package br.com.tim.mapreduce.joinbdo_b;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import br.com.tim.mapreduce.joinbdo.model.TraftarPosBscs9JoinBdoBKey;

public class TraftarPosBscs9JoinBdoBSortComparator extends WritableComparator {

	public TraftarPosBscs9JoinBdoBSortComparator() {
        super(TraftarPosBscs9JoinBdoBKey.class, true);
    }
	
	@SuppressWarnings("rawtypes")
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		TraftarPosBscs9JoinBdoBKey key1 = (TraftarPosBscs9JoinBdoBKey) a;
		TraftarPosBscs9JoinBdoBKey key2 = (TraftarPosBscs9JoinBdoBKey) b;
		
		int result = key1.compareTo(key2);
		
		if ( 0 == result )
			result = Long.compare(key1.getOrdem(), key2.getOrdem());

        return result;
	}

}
